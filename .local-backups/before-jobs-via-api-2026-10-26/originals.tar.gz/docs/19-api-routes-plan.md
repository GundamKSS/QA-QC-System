# 19 — แผนย้ายการเขียนข้อมูลจาก Server Actions ไปเป็น API routes (`app/api/...`)

> 26 ต.ค. 2026 · ผู้ใช้ขอให้โครงเหมือนโปรเจกต์ log-book (ทุกอย่างที่ต่อ DB อยู่ใน `app/api/<ฟีเจอร์>/<ย่อย>/route.ts`) และ OK แผนนี้ → **ครบทุกขั้น (0–7) แล้ว** (ทดสอบด้วยเทสต์, ยิงจริงทุก endpoint และลองในเบราว์เซอร์โหมดสาธิต — ดู §8; **ยังไม่ได้ลองกับ SQL Server/ระบบกลางจริง**) · ทำทีละขั้น หยุดรอผู้ใช้ confirm ก่อนทุกขั้น
> สำรองก่อนเริ่ม: `.local-backups/before-api-routes-2026-10-26/originals.tar.gz` (โปรเจกต์นี้ไม่มี git)

## 1. หลักการ

1. **`lib/` ไม่แตะ** — route แต่ละตัวเป็นตัวห่อบาง ๆ ที่เรียก service เดิม (`openPlan`, `createMaster`, `changeOwnPin` …) กติกาธุรกิจ audit SQL และเทสต์เดิมใช้ต่อ
2. **ตัวช่วยกลาง `lib/api/`** เขียนครั้งเดียว: ตรวจ same-origin + session + สิทธิ์ตามหน้า, อ่าน body, ตอบ JSON, แปลง DB error
3. **ฟอร์มแก้น้อย** — ยังใช้ `<form action>` กับ `useActionState` (ผ่าน `useApiAction`) จึงได้ปุ่ม pending และการล้างช่องหลังตอบเหมือนเดิม; รูปแบบ state (`error` / `fieldErrors` / `at` …) คงเดิม ข้อความที่ผู้ใช้เห็นไม่เปลี่ยน
4. **หลังบันทึก** route ส่ง `redirectTo` ให้เบราว์เซอร์พาไปหน้าที่ action เดิมเคย `redirect()` ไป; ถ้าอยู่หน้าเดิมจะ `router.refresh()` (`revalidatePath` ใน route ไม่ล้าง router cache ฝั่งเบราว์เซอร์เอง)
5. **การอ่าน** หน้า server component ยังอ่านผ่าน `lib/` ตรง ๆ (ไม่ยิง API ของตัวเอง) — มี GET ใน API เฉพาะจุดที่ client ต้องเรียก หรือรายงาน/ส่งออกที่จะเพิ่มทีหลัง

## 2. สัญญา API

| เรื่อง | กติกา |
|---|---|
| Body เข้า | JSON (ฟอร์มส่งเป็น JSON — ช่องชื่อซ้ำเป็น array) หรือ form ธรรมดา (`urlencoded` / `multipart`) ก็อ่านได้ → ทดสอบด้วย Postman/curl ได้ body ที่อ่านไม่ออกถือเป็นช่องว่าง ให้กติกา "ต้องกรอก" ตอบเอง |
| Body ออก | JSON ที่มี `status` เสมอ: `done` / `error` / สถานะเฉพาะฟอร์ม (เช่น `duplicate`) — ตรงกับ state ที่หน้าจอเดิมใช้; `error` มี `message` ภาษาไทยพร้อมแสดง; อาจมี `redirectTo` (เฉพาะ path ในเว็บเรา) |
| Header ออก | `Cache-Control: private, no-store` + `Vary: Cookie` ทุกคำตอบ |
| ไม่ได้ล็อกอิน | `401` + `redirectTo: /login?next=…` (ไม่ redirect เอง) |
| ค้างเปลี่ยน PIN | `403` + `redirectTo: /change-password` (ยกเว้น endpoint เปลี่ยน PIN เอง) |
| ไม่มีสิทธิ์ตามหน้า | `403` (ใช้ตาราง `PAGE_ACCESS` ตัวเดียวกับเมนูและหน้า) |
| ส่งข้ามเว็บ | `403` สำหรับ POST/PUT/PATCH/DELETE ที่ไม่ใช่ same-origin (แทนการตรวจ CSRF ที่ Server Actions เคยทำให้) |
| ข้อมูลผิดที่แก้ได้ | `422` (เช่น PIN รูปแบบผิด) · ไม่พบ `404` · ล็อก `423` · ซ้ำ/สถานะเปลี่ยน `409` |
| DB ล่ม | `503` + ข้อความเดิมจาก `dbProblemMessages` (ไม่โชว์ error ดิบ) |
| บั๊กจริง | โยนต่อเป็น `500` (ไม่กลืน) |

## 3. แผนที่ API และสถานะ

| ขั้น | Method และ path | แทน action เดิม | สถานะ |
|---|---|---|---|
| 1 | `POST /api/auth/change-pin` | `changePinAction` | ✅ |
| 2 | `POST /api/admin/users` (201) · `PATCH /api/admin/users/[id]` · `POST …/[id]/reset-pin` · `…/unlock-pin` · `…/active` | `create/update/resetPin/unlockPin/setActive` | ✅ |
| 3 | `POST /api/master/[table]` (201) · `PATCH /api/master/[table]/[id]` · `POST …/[id]/active` | `saveMasterAction` (สร้าง/แก้), `setMasterActiveAction` | ✅ |
| 4 | `POST /api/plans` (201) · `GET /api/plans/lookup-doc` · `POST /api/plans/[id]/cancel` · `…/waiting-goods` · `PATCH …/vendor` | `openPlanAction`, `lookupReceiptDocAction`, `cancelPlanAction`, `setWaitingGoodsAction`, `setPlanVendorAction` | ✅ |
| 5 | `POST /api/plans/[id]/work-orders` (201) · `PUT …/work-orders/[woId]/assignees` · `POST …/[woId]/cancel` | `openWorkOrderAction`, `setWorkOrderAssigneesAction`, `cancelWorkOrderAction` | ✅ (ลบ `plans/actions.ts` ทั้งไฟล์แล้ว) |
| 6 | `POST /api/auth/login` · `POST /api/auth/logout` (ย้ายจาก `/auth/logout`) | `login`, route ออกจากระบบเดิม | ✅ เลือกทาง A (รอ hydrate) — ดู §6 · ลบ `login/actions.ts` แล้ว: **ไม่เหลือ Server Action ในโปรเจกต์** |
| 7 | เก็บกวาด: README/docs/คอมเมนต์ให้ตรงกับของจริง, ตรวจลิงก์เอกสาร, ตรวจรวมสุดท้าย (§8) | | ✅ |

`/api/notifications` (GET) มีอยู่ก่อนแล้ว คงเดิม · ขั้น 0 = โครงกลาง `lib/api/` (✅)

## 4. ตัวช่วยกลาง `lib/api/`

| ไฟล์ | หน้าที่ |
|---|---|
| `guard.ts` | `guardApi(request, { page?, returnTo?, allowPasswordChange? })` → `{ user }` หรือ `{ response }` (ด่านแรกของทุก route) |
| `body.ts` | `readFields(request)` → `get` / `text` / `all` อ่านได้ทั้ง JSON และ form (ตัวแยกฟอร์มเดิมที่รับ `get(key)` ใช้ต่อได้เลย) |
| `response.ts` | `apiJson(body, status)` · `apiError(status, message, extra?)` + header ไม่ cache |
| `db.ts` | `dbFailure(error, label)` ใน `catch` ของ route ที่แตะ DB: DB error → 503, อย่างอื่นโยนต่อ |
| `messages.ts` | ข้อความไทยกลาง (ไม่มีสิทธิ์ เซสชันหมด เครือข่ายล่ม ฯลฯ) |
| `call.ts` | `callApi(url, method, formData, failed)` ฝั่งเบราว์เซอร์: ส่งฟอร์มเป็น JSON, แยก `redirectTo` (ตัดที่ออกนอกเว็บทิ้ง) และ `refresh` ออกจาก state, ถ้าเครือข่ายล่ม/ตอบไม่ใช่ JSON ให้ใช้ error state ของหน้านั้น (ส่งฟอร์มที่ผู้ใช้พิมพ์ให้ด้วย จะได้เก็บค่าไว้) |
| `client.ts` | `useApiAction(url, initial, failed, method?)` แทน `useActionState(serverAction, initial)` · `useApiCall(url, failed)` สำหรับปุ่มที่ไม่ใช่ฟอร์ม (ช่องติ๊ก) — ทั้งคู่คง `pending` ไว้จนกว่าหน้าจะรีเฟรช/เปลี่ยนหน้าเสร็จ |
| `lib/plans/api.ts` | ของกลางของ route แผน: `actorIdOf` (users.id สำหรับคอลัมน์ผู้ทำ), `planIdOf`, `revalidatePlan`, ข้อความ `CANCEL_MESSAGES` + `CANCEL_STATUS`, `NO_ACCOUNT` |
| `lib/plans/state.ts` | ชนิด state ของฟอร์มแผนและใบงาน (`OpenPlanFormState`, `PlanActionState`, `WorkOrderFormState`, `WorkOrderFormValues`) ที่เคยอยู่ใน `actions.ts` |
| `lib/plans/lookup-client.ts` | ฝั่งเบราว์เซอร์ของ `GET /api/plans/lookup-doc` (ไม่ throw: ล้มเหลวทุกแบบเป็น `{ kind: "error", message }` ให้กล่องสถานะเอกสาร) |
| `lib/master/api.ts` | ของกลางของ route ข้อมูลหลัก: `masterContext` (ด่าน `master-edit` + หา table จาก registry; ยังไม่ล็อกอินได้ 401 ก่อนเสมอ จึงเดาชื่อ table ไม่ได้), `rowIdOf`, `masterWriteFailure` (ซ้ำ `409` · ผิดเงื่อนไข DB `422` · DB ล่ม `503` พร้อมค่าที่พิมพ์) |
| `lib/auth/admin-api.ts` | ของกลางของ route จัดการผู้ใช้ (และ PIN): `adminContext` (ด่าน `users` + pepper + store), `adminFailure(error)` แปลง `AdminError` เป็นข้อความไทย + status (`422` แก้แล้วส่งใหม่ได้ · `403` · `404` · `423` ล็อก), `profileFields`, `userIdOf` |

## 5. สูตรเพิ่ม endpoint (ใช้ทุกขั้นถัดไป)

```ts
// app/api/plans/route.ts
export async function POST(request: Request) {
  const guard = await guardApi(request, { page: "plan-open", returnTo: "/plans/new" });
  if ("response" in guard) return guard.response;
  const fields = await readFields(request);
  try {
    // … เรียก service ใน lib/ แล้ว audit เหมือนเดิม …
    return apiJson({ status: "done", redirectTo: "/plans/new?opened=12" });
  } catch (error) {
    return dbFailure(error, "open plan");
  }
}
```

ฟอร์ม: `const [state, action, pending] = useApiAction("/api/plans", idle, failed);` — `failed(message)` สร้าง error state ของฟอร์มนั้นเอง (ใช้เมื่อเครือข่ายล่มหรือตอบไม่ใช่ JSON) · ชนิดของ state ย้ายจาก `actions.ts` ไปไว้ที่ `lib/<โมดูล>/` ข้างบริการที่ใช้

## 6. สิ่งที่ต่างจากเดิม / ความเสี่ยง

- **ฟอร์มต้องรอหน้า hydrate ก่อน** — Server Action เดิมส่งฟอร์มได้แม้ JavaScript ยังไม่ทำงาน; แบบ `fetch` ไม่ได้ (React กันไม่ให้ฟอร์มถูกส่งแบบเปล่า ๆ: ตัวฟอร์มมี `action="javascript:throw …"` จึงไม่ส่งและไม่มีรหัสผ่านต่อท้าย URL)
- **ตัดสินใจ login (ขั้น 6): ทาง A — รอ hydrate + กันกดเร็วเกินไป** เทียบกับทาง B (route รับ form POST ธรรมดาตอบ `303`, ส่งสถานะผ่าน URL) และทาง C (คง Server Action): JS ที่ต้องโหลดเพื่อ hydrate `/login` ~184 KB gzip (framework ~168 + หน้า ~16) ส่วนฉาก 3D ~279 KB โหลดทีหลังตอนเบราว์เซอร์ว่าง ไม่ขวางฟอร์ม (ค่าประมาณจากไฟล์ build ยังไม่ได้วัดบนมือถือจริง) · หลังขั้น 1–5 ทุกการเขียนในแอปต้องใช้ JS อยู่แล้ว ประโยชน์ของ login ที่ไม่ต้องใช้ JS จึงน้อย แต่ทาง B เพิ่มพื้นผิวเสี่ยงที่ endpoint ละเอียดอ่อนสุด
  - ปุ่มเข้าสู่ระบบ `disabled` + "กำลังเตรียม…" จนหน้าพร้อม (ปุ่มหลักที่ปิดกัน Enter ส่งก่อนเวลา) · ข้อความที่พิมพ์ระหว่างรอไม่หาย (React ไม่เขียนทับ `value` ตอน hydrate — ดู `initInput` ใน react-dom) · `<noscript>` บอกให้เปิด JavaScript · แก้คำอธิบายใน docs/07 §9 แล้ว
  - **ตัด Referer fallback ของ `next` ออก**: เดิมมีไว้ให้การส่งก่อน hydrate (ช่อง `next` ยังว่าง) ย้อนไปอ่าน `?next=` จากหน้าเดิม ตอนนี้ฟอร์มส่งได้หลัง hydrate เท่านั้น ช่อง `next` จึงมีค่าเสมอ
  - **สถานะใหม่ `unreachable`** (สร้างโดยฟอร์มเอง ไม่ใช่เซิร์ฟเวอร์): เครือข่ายหลุด/เซิร์ฟเวอร์รีสตาร์ท/ได้หน้า crash กลับมา → แสดง "เชื่อมต่อเซิร์ฟเวอร์ไม่สำเร็จ ลองใหม่อีกครั้ง" ในฟอร์มแทนหน้า error เต็มจอ (เก็บรหัสพนักงานที่พิมพ์ไว้) · `login/error.tsx` เหลือเป็นตาข่ายสุดท้ายตอนหน้า login พังตอน render
  - สถานะ HTTP: ผิด `401` · ช่องว่าง/รหัสผ่านยาวเกิน `422` · ล็อก/PIN ล็อก `423` · ปิดใช้งาน/ไม่มีสิทธิ์/ส่งข้ามเว็บ `403` · ระบบกลางล่ม `503` · `busy` (ยิงขนานเป็นสคริปต์) ตอบเหมือน "ผิด" ทุกประการ (`401`) ผู้โจมตีจึงแยกไม่ออก · สำเร็จตอบ `status: "success"` + `next` **ไม่ใช้ `redirectTo`** เพราะฟอร์มต้องเล่นอนิเมชันต้อนรับก่อนแล้ว `window.location.replace(next)` (โหลดทั้งหน้าเพื่อล้างข้อมูลผู้ใช้คนก่อนบนเครื่องส่วนกลาง) เหมือนเดิม
  - ขนาด body จำกัด 16 KB ที่ login (Server Action เดิมถูก Next จำกัด 1 MB ให้เอง) และ `readFields` มีเพดานเริ่มต้น 1 MB กับทุก route (ดู Content-Length ที่ประกาศ — proxy ยังต้องจำกัด chunked upload เอง)
  - `/api` ถูกเพิ่มใน `authOnlyPaths` กัน `?next=/api/...` กลายเป็นหน้าปลายทางหลัง login
- **เปลี่ยน PIN ตอนนี้จับ DB ล่มเป็นข้อความได้** (เดิม action ไม่ดัก ทำให้หน้าพัง) — เป็นการปรับปรุงเล็ก ๆ ที่มากับการย้าย
- **`id` ของผู้ใช้ย้ายจากช่องซ่อนในฟอร์มไปอยู่ใน path** (`/api/admin/users/[id]/…`) และรับเฉพาะ `[A-Za-z0-9_-]` ยาวไม่เกิน 40 ตัว ไม่ตรงตอบ `404` · `active` รับ `"1"` หรือ `"true"` เพื่อเปิด ค่าอื่นคือปิด (ค่าเริ่มต้นปลอดภัย)
- **ข้อมูลหลัก:** `slug` และ `id` ย้ายจากช่องซ่อนในฟอร์มไปอยู่ใน path (`/api/master/brands/3`) · ฟอร์มสร้าง/แก้ยังได้ค่าที่พิมพ์คืนเมื่อถูกปฏิเสธ (`values` + `at`) และเมื่อเครือข่ายล่มก็อ่านค่าที่พิมพ์กลับจากฟอร์มที่ส่ง (`failed(message, formData)`) · บันทึกสำเร็จตอบ `redirectTo: /master/<slug>?saved=<id>` เหมือน `redirect()` เดิม · `active` ตีความเหมือนผู้ใช้หน้างาน
- **แผน:** `planId` ย้ายจากช่องซ่อนไปอยู่ใน path · เปิดแผนซ้ำ Invoice/PO + Model (BR-01) ตอบ `409` พร้อม `status: "duplicate"`, `planId`, `planNo` (ฟอร์มยังโชว์ลิงก์ไปแผนเดิม) · ยกเลิกแผนถูกปฏิเสธ: ไม่พบ `404` · ต้องกรอกเหตุผล/ยาวเกิน `422` · สถานะเปลี่ยน/ยกเลิกไม่ได้ในสถานะนี้ `409` · มีผลตรวจแล้วต้องให้ Head `403` · Vendor ไม่มี/ปิดใช้งาน `422`, แผนถูกยกเลิก `409`
- **`GET /api/plans/lookup-doc`** ตอบ `{ status: "done", result: DocLookup }` (ห่อไว้เพื่อให้ทุกคำตอบมี `status`) · DB ล่มเป็น `503` แทน `{kind:"error"}` เดิม ฝั่งเบราว์เซอร์แปลงกลับเอง
- **ช่อง "รอของ"** แสดงค่าใหม่ทันทีที่ติ๊กและคงไว้จนหน้ารีเฟรชเสร็จ ถ้าเซิร์ฟเวอร์ปฏิเสธจะกลับเป็นค่าเดิมพร้อมข้อความ · ปุ่มในทุกฟอร์มยังถูกล็อกจนกว่าหน้าใหม่จะแสดง (ก่อนหน้านี้ขั้น 1–3 รีเฟรชแต่ไม่ล็อกปุ่ม)
- **ใบงาน:** `planId` และ `woId` ย้ายจากช่องซ่อนไปอยู่ใน path · ผู้ตรวจยังส่งเป็นช่อง `assignee1…assignee5` ตามลำดับช่อง (ตัวเลือกลากวางไม่เปลี่ยน) · ใบงานใน path เป็นตัวตัดสินว่าแก้ใบงานไหน (เหมือนเดิม) ส่วนแผนใน path ใช้เป็นที่กลับไปหลังล็อกอินและตรวจสิทธิ์ · เปิดใบงานสำเร็จตอบ `redirectTo: /plans/<id>?tab=work&opened=<woNo>`
- **คำตอบมี `refresh: true` ได้** (เพิ่มในขั้น 5): ใช้เมื่อถูกปฏิเสธเพราะข้อมูลที่หน้าแสดงอยู่เก่าไปแล้ว — กรณีเดียวตอนนี้คือเปิดใบงานแล้วพบว่ามีผู้ตรวจถูกปิดใช้งานระหว่างนั้น (`unavailable`) เบราว์เซอร์จะโหลดหน้าใหม่ให้รายชื่อตัดคนนั้นออก (Server Action เดิมทำสิ่งนี้ผ่าน `revalidatePath` ซึ่ง route ทำแทนไม่ได้)
- **ผู้ตรวจที่ถูกปิดใช้งาน:** เปิดใบงาน `422` + `unavailable` + `refresh` · เปลี่ยนผู้ตรวจ `422` (เหมือนเดิม ไม่รีเฟรชอัตโนมัติ) · ใบงานล็อก (ส่งแล้ว/ปิด/ยกเลิก/มีผลตรวจแล้ว) `409`
- **PIN ชั่วคราวอยู่ในคำตอบครั้งเดียว** (`no-store`) ไม่เข้า audit/log — มีเทสต์ยืนยันทุก route ที่ออก PIN
- **ใช้ DB ตัวเดียวกับของเดิม** ไม่มีการเปลี่ยน schema ใด ๆ ในแผนนี้
- **ออกจากระบบย้ายเป็น `/api/auth/logout`** ตรรกะเหมือนเดิมทุกอย่าง (ฟอร์ม POST ธรรมดา ตอบ `303` ไป `/login` แบบ relative ไม่ต้องใช้ JS) แก้ `authPolicy.logoutPath` (ปุ่ม `SignOutButton` อ่านจากที่นี่) · ไม่มี Server Action เหลืออยู่ในโปรเจกต์แล้ว

## 7. การตรวจ

ทุกขั้นต้องผ่าน typecheck, lint, vitest และ `next build` · เทสต์ของ `lib/api/*` ครอบคลุม guard, body, response, DB error, ฝั่งเบราว์เซอร์ (`callApi`) · แต่ละกลุ่ม route มีไฟล์ `tests/api-*.test.ts` ของตัวเอง (ไม่ล็อกอิน / ข้ามเว็บ / ไม่มีสิทธิ์ / ข้อมูลผิด / DB ล่ม / สำเร็จ + audit)

**ลองมือขั้น 1** (ต้องใช้ผู้ใช้หน้างาน LOCAL ที่ถูกสร้างหรือรีเซ็ต PIN ไว้): เข้าด้วย PIN ชั่วคราวจนถึง `/change-password` → กรอก PIN ปัจจุบัน/ใหม่/ยืนยัน แล้วกดบันทึก ควรไป `/home` · ทดสอบกรณีผิด: PIN ปัจจุบันผิด, PIN ใหม่สองช่องไม่ตรง, PIN ใหม่ซ้ำเดิม, PIN ง่ายเกินไป (111111) ควรเห็นข้อความสีแดงเดิมและช่องถูกล้าง

**ตรวจขั้น 6 ในเบราว์เซอร์แล้ว (26 ต.ค. 2026)** ด้วยสำเนาโปรเจกต์ที่แยกต่างหาก (ไม่มี `.env.local` และไม่ต่อ DB) รันโหมดบัญชีสาธิต `QCHECK_AUTH=mock DB_SERVER=` — ผ่านทั้งหมด: HTML ก่อน JS (ปุ่ม `disabled` เขียน "กำลังเตรียม…", มี `<noscript>`, ไม่มีช่อง `enhanced`, `action="javascript:throw …"`) · เข้าสู่ระบบสำเร็จ (อนิเมชันต้อนรับแล้วไป `/home`) · รหัสผิด `401` พร้อมข้อความและโฟกัสช่องรหัสผ่าน · ผิด 5 ครั้งได้ `423` + นับถอยหลัง "ลองใหม่ได้ในอีก 14:59" · เครือข่ายหลุด (จำลองให้ `fetch` ล้มเหลว) ได้ข้อความในฟอร์มและรหัสพนักงานยังอยู่ · `?next=/more` ไปถูกหน้า, `?next=//evil.example` ถูกตีเป็น `/home` · ออกจากระบบแล้วเข้า `/home` ถูกส่งกลับ `/login?next=%2Fhome` · body ผิดรูป/ว่าง `422` ไม่มีการเรียกระบบกลาง

**ที่ยังต้องให้คนลองกด (เพราะต้องใช้บัญชีจริง):** เข้าด้วยบัญชีระบบกลางจริง (ตรวจว่า `syncUserOnLogin` เขียน DB ได้) · ผู้ใช้หน้างาน F-code + PIN ที่ค้างเปลี่ยน PIN ต้องถูกพาไป `/change-password` · มือถือจริงบน Wi-Fi โรงงาน (ช่วงที่ปุ่ม "กำลังเตรียม…" ค้างนานแค่ไหน) · password manager (Keychain/Chrome) ยังเสนอบันทึกรหัสผ่านหลังเข้าสำเร็จ

## 8. สรุปผลรวม (ขั้น 7 — จบแผน 26 ต.ค. 2026)

**ผลลัพธ์**
- ย้าย **19 endpoints** จาก Server Actions เป็น route handlers + `/api/notifications` ที่มีอยู่เดิม = **20 ไฟล์ `route.ts`** ใน `app/api/` · **ไม่เหลือ Server Action ในโปรเจกต์** (ค้น `"use server"` แล้วไม่พบ)
- `lib/` ส่วนกติกาธุรกิจ/SQL/audit ไม่ถูกแก้ — เพิ่มเฉพาะตัวช่วย: `lib/api/` · `lib/plans/{api,state,lookup-client}.ts` · `lib/master/api.ts` · `lib/auth/admin-api.ts` และชนิด state ที่ย้ายมาจาก `actions.ts`
- เทสต์ 456 → **858** (เพิ่มราว 400 ตัวของ API: ไม่ล็อกอิน · ข้ามเว็บ · สิทธิ์ · ข้อมูลผิด · DB ล่ม · audit · ไม่มีความลับรั่วใน audit/คำตอบ) · lint, `tsc`, `next build` ผ่าน · ลิงก์เอกสารสัมพัทธ์ทั้ง 22 ไฟล์ไม่เสีย (แก้ 2 ลิงก์ wireframe ที่เสียตอนย้ายโฟลเดอร์)
- ยิงจริงทุก handler (20 ตัว) บน dev server: ไม่ล็อกอิน `401` (login `422` เพราะส่งช่องว่าง, logout `303`) · ข้ามเว็บ `403` · method ที่ไม่รองรับ `405` ผ่านครบ

**ตรวจในเบราว์เซอร์ (โหมดสาธิต: สำเนาโปรเจกต์ที่ไม่มี `.env.local`/DB, `QCHECK_AUTH=mock`, store ในหน่วยความจำ)** — ผ่าน: login/logout · เปิดแผน (`201`) + ตรวจเอกสารตอนออกจากช่อง + แผนซ้ำ `409` + ข้อมูลผิด `422` · ติ๊ก "รอของ" (ค่าใหม่ขึ้นทันที ช่องล็อกจนหน้ารีเฟรชเสร็จ ค่าคงอยู่หลังโหลดใหม่) · แก้ Vendor (กล่องปิดเอง ชื่อใหม่ขึ้น) · เปิดใบงาน (ไปแท็บใบงานพร้อมแถบแจ้ง) · แก้ผู้ตรวจ (กล่องปิดเอง) · ยกเลิกใบงาน (ยอดเรียกเข้าคืนล็อต) · ยกเลิกแผน (หน้าเปลี่ยนเป็น "ยกเลิก" พร้อมเหตุผล) · สร้างผู้ใช้หน้างาน (PIN ชั่วคราวแสดงครั้งเดียว รายการอัปเดต) · ออก PIN ใหม่ · ปิด/เปิดใช้งาน · แก้ไขข้อมูล/บทบาท · ผู้ใช้หน้างานเข้าด้วย PIN ชั่วคราว → ถูกพาไป `/change-password` → ปฏิเสธ 3 แบบ (PIN เดิมผิด `403`, สองช่องไม่ตรง `422`, PIN อ่อน `422`) → สำเร็จ `200` ไป `/home` · PIN ผิด 5 ครั้งล็อก `423` → Admin ปลดล็อก `200` · audit ฝั่งเซิร์ฟเวอร์ครบทุกการกระทำและไม่มี PIN

**ยังไม่ได้ตรวจกับของจริง (ต้องใช้ระบบจริง)**
1. **Master data** ทั้ง 3 endpoints — หน้านี้ต้องใช้ SQL Server จริง (โหมดสาธิตไม่มี) ครอบคลุมด้วยเทสต์เท่านั้น
2. การเขียน SQL Server จริงของทุกฟีเจอร์ (เทสต์ใช้ store จำลอง/ในหน่วยความจำ) · `npm run db:migrate` ไม่ได้รันใหม่ ไม่มี migration ใหม่ในแผนนี้
3. Login ด้วยบัญชีระบบกลางจริง (รวมการบันทึกผู้ใช้ลง DB) และมือถือจริงบน Wi-Fi โรงงาน

**ข้อสังเกตจากการทดสอบ**
- ฟอร์มใน `<Suspense>` ของ `/change-password` (และหน้าอื่นที่ใช้โครงเดียวกัน) ยังไม่ hydrate จนกว่าจะมีการโต้ตอบ (คลิก/โฟกัส) ในเบราว์เซอร์ทดสอบที่ถูกซ่อนอยู่ — เป็นลำดับความสำคัญต่ำของ React ต่อ Suspense boundary ที่ยังไม่ hydrate และเป็นโครงหน้าเดิม ไม่ได้มาจากการย้าย API · ผู้ใช้จริงต้องแตะช่องก่อนพิมพ์อยู่แล้วจึงไม่น่ากระทบ แต่ถ้ารู้สึกว่าฟอร์ม PIN ตอบสนองช้าบนเครื่องจริงให้แจ้ง
- ข้อความ error ของช่อง Model ตอนเปิดแผนอ่านว่า "กรุณากรอกModel" (ไม่มีเว้นวรรค) — มาจาก `fieldErrorMessage` เดิม ไม่ได้แก้ในแผนนี้
- ช่อง `code` (รหัสพนักงานเป้าหมายของ audit ตอนแก้ผู้ใช้) ยังรับจากฟอร์มเหมือนเดิม — เปลี่ยนให้ดึงจาก DB ได้ถ้าต้องการ (ต้องแก้ `updateLocalUser` ให้คืนรหัสด้วย)

**ตอนขึ้น production ต้องจำ**
- ด่าน same-origin เทียบ `Origin` กับ `Host`/`X-Forwarded-Host` — reverse proxy ต้องส่ง header ให้ตรงกับ host ที่เบราว์เซอร์ใช้ ไม่งั้นทุกการเขียนจะได้ `403` · เพดานขนาด body ดูจาก `Content-Length` (login 16 KB, อื่น ๆ 1 MB) proxy ยังต้องจำกัด chunked upload เอง
- เพิ่ม endpoint ใหม่ตามสูตร §5 และเพิ่มแถวใน §3 ทุกครั้ง · ย้อนกลับ/เทียบ: `.local-backups/before-api-routes-2026-10-26/originals.tar.gz` (ก่อนย้าย API) และ `.local-backups/before-log-book-structure-2026-10-26/originals.tar.gz` (ก่อนย้ายโครงสร้าง)

**กติกาถาวรหลังจบแผน (26 ต.ค. 2026):** ผู้ใช้สั่งให้ทำตามสไตล์ log-book ตลอดไป — รวมกติกาไว้ใน [`CLAUDE.md`](../CLAUDE.md) ที่ root: หน้า/ฟีเจอร์ใหม่อ่านข้อมูลผ่าน `GET /api/<ฟีเจอร์>` (10 หน้าเดิมที่อ่านผ่าน `lib/` คงไว้จนกว่าจะสั่งย้าย) และเทสต์ทั้งหมดย้ายไป `tests/` แล้ว (`tests/api-*.test.ts` ฯลฯ)

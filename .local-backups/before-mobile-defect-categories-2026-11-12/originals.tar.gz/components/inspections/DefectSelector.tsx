"use client";

import { useMemo, useState } from "react";
import { DISPOSITION_LABELS, SEVERITY_LABELS } from "@/lib/inspections/rules";
import type { Disposition, SelectedDefect } from "@/lib/inspections/types";

type Props = {
  availableDefects: readonly SelectedDefect[];
  selectedDefects: readonly SelectedDefect[];
  onChange: (defects: SelectedDefect[]) => void;
};

/**
 * Common Standard Defects fallback/shared pool so any checklist item (including newly added items)
 * always has an easy-to-tap common list of defects on mobile.
 */
export const COMMON_STANDARD_DEFECTS: readonly SelectedDefect[] = [
  {
    defectId: 5,
    code: "DEF00003",
    nameTh: "สีถลอก / รอยขีดข่วนภายนอก",
    part: "ตัวถัง/ภายนอก",
    severity: "MINOR",
    disposition: "CONCESSION",
  },
  {
    defectId: 10,
    code: "DEF00008",
    nameTh: "น็อตยึดหรือชิ้นส่วนประกอบหลวม",
    part: "จุดยึดประกอบ",
    severity: "MAJOR",
    disposition: "REWORK",
  },
  {
    defectId: 8,
    code: "DEF00006",
    nameTh: "พบการรั่วซึม (ลม / น้ำมัน)",
    part: "ข้อต่อ/ซีล",
    severity: "MAJOR",
    disposition: "REWORK",
  },
  {
    defectId: 120,
    code: "DEF00118",
    nameTh: "เสียงดังผิดปกติ / สั่นสะเทือนเกินเกณฑ์",
    part: "ชุดขับเคลื่อน",
    severity: "MAJOR",
    disposition: "CHOOSE",
  },
  {
    defectId: 3,
    code: "DEF00001",
    nameTh: "ชิ้นส่วนชำรุด แตกหัก หรือผิดสเปก",
    part: "โครงสร้างหลัก",
    severity: "CRITICAL",
    disposition: "REJECT",
  },
];

export const QUICK_LOCATION_PRESETS = [
  "ด้านหน้า",
  "ด้านหลัง",
  "ซ้าย",
  "ขวา",
  "หัวปั๊ม",
  "ถังลม",
  "มอเตอร์",
  "ข้อต่อ/วาล์ว",
] as const;

export function parseLocationTokens(note?: string | null): string[] {
  if (!note) return [];
  return note
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export function isLocationChipActive(note: string | null | undefined, chip: string): boolean {
  return parseLocationTokens(note).includes(chip);
}

export function toggleLocationChip(note: string | null | undefined, chip: string): string {
  const tokens = parseLocationTokens(note);
  const exists = tokens.includes(chip);
  const next = exists ? tokens.filter((t) => t !== chip) : [...tokens, chip];
  return next.join(", ");
}

function defectMatches(a: SelectedDefect, b: SelectedDefect): boolean {
  if (a.itemDefectId && b.itemDefectId) return a.itemDefectId === b.itemDefectId;
  return a.defectId === b.defectId && (a.part ?? "") === (b.part ?? "");
}

function defectKey(d: SelectedDefect, idx: number): string {
  if (d.itemDefectId) return `item-defect-${d.itemDefectId}`;
  return `defect-${d.defectId}-${d.part ?? ""}-${idx}`;
}

/**
 * Screen S06 Common Defect Selector:
 * Mobile-friendly one-tap defect cards (compact grid) with part filters,
 * quick location chips, and common defect fallback.
 */
export function DefectSelector({
  availableDefects,
  selectedDefects,
  onChange,
}: Props) {
  const [showCommonPool, setShowCommonPool] = useState(availableDefects.length === 0);
  const [partFilter, setPartFilter] = useState<string>("ALL");

  const combinedDefects = useMemo(() => {
    if (availableDefects.length === 0) return COMMON_STANDARD_DEFECTS;
    if (!showCommonPool) return availableDefects;
    const extras = COMMON_STANDARD_DEFECTS.filter(
      (c) => !availableDefects.some((a) => defectMatches(a, c)),
    );
    return [...availableDefects, ...extras];
  }, [availableDefects, showCommonPool]);

  const parts = useMemo(() => {
    const set = new Set<string>();
    for (const d of combinedDefects) {
      if (d.part) set.add(d.part);
    }
    return Array.from(set);
  }, [combinedDefects]);

  const visibleDefects = useMemo(() => {
    if (partFilter === "ALL") return combinedDefects;
    return combinedDefects.filter((d) => (d.part ?? "") === partFilter);
  }, [combinedDefects, partFilter]);

  function isSelected(target: SelectedDefect) {
    return selectedDefects.some((d) => defectMatches(d, target));
  }

  function handleToggleDefect(templateDefect: SelectedDefect) {
    if (isSelected(templateDefect)) {
      onChange(selectedDefects.filter((d) => !defectMatches(d, templateDefect)));
    } else {
      const initialDisposition: Disposition =
        templateDefect.disposition === "CHOOSE" ? "REWORK" : templateDefect.disposition;

      onChange([
        ...selectedDefects,
        {
          ...templateDefect,
          disposition: initialDisposition,
        },
      ]);
    }
  }

  function handleDispositionChange(target: SelectedDefect, disposition: Disposition) {
    onChange(
      selectedDefects.map((d) =>
        defectMatches(d, target) ? { ...d, disposition } : d,
      ),
    );
  }

  function handleLocationNoteChange(target: SelectedDefect, note: string) {
    onChange(
      selectedDefects.map((d) =>
        defectMatches(d, target) ? { ...d, locationNote: note } : d,
      ),
    );
  }

  function handleToggleLocationPreset(target: SelectedDefect, chip: string) {
    const current = selectedDefects.find((d) => defectMatches(d, target))?.locationNote;
    const nextNote = toggleLocationChip(current, chip);
    handleLocationNoteChange(target, nextNote);
  }

  return (
    <div className="rounded-2xl border border-fail/30 bg-fail/5 p-3 sm:p-4 space-y-2.5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <h3 className="text-xs sm:text-sm font-semibold text-fail">
            อาการที่พบ <span className="text-fail">*</span>
          </h3>
          <span className="text-[11px] text-ti-400">
            (แตะการ์ดเพื่อเลือก)
          </span>
        </div>
        <span className="rounded-full bg-fail/15 border border-fail/35 px-2.5 py-0.5 text-xs font-mono font-semibold text-fail">
          เลือก {selectedDefects.length}
        </span>
      </div>

      {/* Common Part Quick Filter Chips */}
      {parts.length > 1 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          <button
            type="button"
            onClick={() => setPartFilter("ALL")}
            className={`shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
              partFilter === "ALL"
                ? "border-ember-500 bg-ember-500 text-white font-semibold shadow-xs"
                : "border-carbon-600 bg-carbon-900 text-ti-200 hover:border-carbon-500"
            }`}
          >
            ทั้งหมด ({combinedDefects.length})
          </button>
          {parts.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPartFilter(p)}
              className={`shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                partFilter === p
                  ? "border-ember-500 bg-ember-500 text-white font-semibold shadow-xs"
                  : "border-carbon-600 bg-carbon-900 text-ti-200 hover:border-carbon-500"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {/* 1-Tap Compact Defect Grid */}
      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {visibleDefects.map((defect, idx) => {
          const checked = isSelected(defect);
          const activeFinding = selectedDefects.find((d) => defectMatches(d, defect));
          const isSeverityCritical = defect.severity === "CRITICAL";

          return (
            <li
              key={defectKey(defect, idx)}
              className={`rounded-control border transition-all ${
                checked
                  ? "sm:col-span-2 border-fail bg-carbon-800 ring-1 ring-fail/40 shadow-sm"
                  : "border-carbon-700 bg-carbon-900/75 hover:border-carbon-500 hover:bg-carbon-800/60"
              }`}
            >
              {/* Full-card 1-Tap Toggle Button */}
              <button
                type="button"
                aria-pressed={checked}
                onClick={() => handleToggleDefect(defect)}
                className="w-full text-left flex items-center justify-between gap-2.5 px-3 py-2.5 cursor-pointer select-none active:scale-[0.99] transition-transform"
              >
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <span
                    aria-hidden="true"
                    className={`shrink-0 flex items-center justify-center size-5 rounded-md border text-xs font-bold transition-colors ${
                      checked
                        ? "border-fail bg-fail text-white shadow-xs"
                        : "border-carbon-500 bg-carbon-900 text-transparent"
                    }`}
                  >
                    ✓
                  </span>
                  <div className="min-w-0 flex-1">
                    <span
                      className={`block text-xs sm:text-sm leading-snug truncate ${
                        checked ? "font-semibold text-ti-50" : "font-medium text-ti-100"
                      }`}
                    >
                      {defect.nameTh}
                    </span>
                    {defect.part && (
                      <span className="inline-block text-[10px] text-ti-400 leading-tight">
                        {defect.part}
                      </span>
                    )}
                  </div>
                </div>

                <span
                  className={`shrink-0 font-mono text-[10px] px-1.5 py-0.5 rounded border ${
                    isSeverityCritical
                      ? "border-fail/60 text-fail bg-fail/10"
                      : defect.severity === "MAJOR"
                      ? "border-ember-500/60 text-ember-400 bg-ember-950/20"
                      : "border-carbon-600 text-ti-400"
                  }`}
                >
                  {SEVERITY_LABELS[defect.severity]}
                </span>
              </button>

              {/* Sub-options when selected: Disposition + Quick Location Chips */}
              {checked && activeFinding && (
                <div className="px-3 pb-3 pt-2 border-t border-carbon-700/80 space-y-2.5 text-xs">
                  {/* Row 1: Disposition */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-ti-300">การจัดการ:</span>
                    {defect.disposition === "CHOOSE" ? (
                      <div className="inline-flex rounded-control border border-carbon-600 bg-carbon-900 p-0.5">
                        <button
                          type="button"
                          onClick={() => handleDispositionChange(defect, "REWORK")}
                          className={`px-2.5 py-1 rounded text-[11px] transition-colors ${
                            activeFinding.disposition === "REWORK"
                              ? "bg-ember-500 text-carbon-900 font-semibold"
                              : "text-ti-400 hover:text-ti-200"
                          }`}
                        >
                          ส่งซ่อม
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDispositionChange(defect, "REJECT")}
                          className={`px-2.5 py-1 rounded text-[11px] transition-colors ${
                            activeFinding.disposition === "REJECT"
                              ? "bg-fail text-carbon-900 font-semibold"
                              : "text-ti-400 hover:text-ti-200"
                          }`}
                        >
                          คัดออก
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-ti-300 font-medium px-2 py-0.5 rounded bg-carbon-900 border border-carbon-700/60">
                        ตามมาตรฐาน: {DISPOSITION_LABELS[activeFinding.disposition]}
                      </span>
                    )}
                  </div>

                  {/* Row 2: Quick Location Chips (1-Tap) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-ti-300">
                        จุดที่พบ <span className="text-ti-500">(แตะเลือกด่วน หรือพิมพ์เพิ่ม)</span>
                      </span>
                      {activeFinding.locationNote && (
                        <button
                          type="button"
                          onClick={() => handleLocationNoteChange(defect, "")}
                          className="text-[10px] text-ti-400 hover:text-ti-200 underline"
                        >
                          ล้างจุดที่พบ
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {QUICK_LOCATION_PRESETS.map((chip) => {
                        const active = isLocationChipActive(activeFinding.locationNote, chip);
                        return (
                          <button
                            key={chip}
                            type="button"
                            onClick={() => handleToggleLocationPreset(defect, chip)}
                            className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all active:scale-95 ${
                              active
                                ? "border-ember-500 bg-ember-500/20 text-ember-300 font-semibold shadow-2xs"
                                : "border-carbon-600 bg-carbon-900 text-ti-300 hover:border-carbon-500 hover:text-ti-100"
                            }`}
                          >
                            {active ? `✓ ${chip}` : `+ ${chip}`}
                          </button>
                        );
                      })}
                    </div>

                    <input
                      type="text"
                      placeholder="ระบุจุดที่พบ (ถ้ามี)"
                      value={activeFinding.locationNote ?? ""}
                      onChange={(e) => handleLocationNoteChange(defect, e.target.value)}
                      className="h-8.5 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100 placeholder:text-ti-500 focus:outline-none focus:ring-1 focus:ring-ember-500"
                    />
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>

      {/* Toggle Common Defects Pool when item has specific defects */}
      {availableDefects.length > 0 && (
        <div className="pt-0.5 text-right">
          <button
            type="button"
            onClick={() => setShowCommonPool((prev) => !prev)}
            className="text-[11px] font-medium text-ember-400 hover:text-ember-300 underline underline-offset-2"
          >
            {showCommonPool ? "ซ่อนอาการอื่น" : "+ อาการอื่น ๆ"}
          </button>
        </div>
      )}
    </div>
  );
}

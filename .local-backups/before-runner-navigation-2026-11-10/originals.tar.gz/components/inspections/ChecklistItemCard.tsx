"use client";

import { useState } from "react";
import { missingEvidenceForItem } from "@/lib/inspections/rules";
import type {
  InspectionItem,
  InspectionPhoto,
  InspectionVideo,
  ItemAnswer,
  SelectedDefect,
} from "@/lib/inspections/types";
import { DefectSelector } from "./DefectSelector";
import { EvidenceCapture } from "./EvidenceCapture";
import { StepMinimalAnimation } from "./StepMinimalAnimation";

type Props = {
  item: InspectionItem;
  totalSteps?: number;
  answer?: ItemAnswer;
  availableDefects: readonly SelectedDefect[];
  onAnswerChange: (answer: ItemAnswer) => void;
};

const QUICK_NUMBER_PRESETS = ["7.5", "8.0", "8.5", "9.0", "10.0", "12.0"] as const;

/**
 * Screen S06 Checklist Step Content inside the Unified Card:
 * Minimalist vector animation, step title, defect selector (when FAIL),
 * number/text inputs, and camera evidence capture.
 */
export function ChecklistItemCard({
  item,
  totalSteps = 6,
  answer = {},
  availableDefects,
  onAnswerChange,
}: Props) {
  const status = answer.status;
  const isFail = status === "FAIL";

  const missingNotes = missingEvidenceForItem(item, answer);
  const requiresPhoto = isFail || item.photoRule === "ALWAYS";
  const requiresVideo =
    item.videoRule === "ALWAYS" ||
    (isFail && item.videoRule === "ON_FAIL") ||
    (answer.defects ?? []).some((d) => d.requiresVideo);

  const hasExistingExtra =
    (answer.photos?.length ?? 0) > 0 ||
    Boolean(answer.video) ||
    Boolean(answer.remark && answer.remark.trim().length > 0);

  const [showOptionalExtra, setShowOptionalExtra] = useState(false);
  const showEvidenceAndNotes =
    isFail ||
    requiresPhoto ||
    requiresVideo ||
    hasExistingExtra ||
    showOptionalExtra ||
    item.inputType !== "PASS_FAIL";

  function handleDefectsChange(defects: SelectedDefect[]) {
    onAnswerChange({
      ...answer,
      defects,
    });
  }

  function handlePhotosChange(photos: InspectionPhoto[]) {
    onAnswerChange({
      ...answer,
      photos,
    });
  }

  function handleVideoChange(video: InspectionVideo | null) {
    onAnswerChange({
      ...answer,
      video,
    });
  }

  function handleValueChange(value: string) {
    onAnswerChange({
      ...answer,
      value,
    });
  }

  function handleRemarkChange(remark: string) {
    onAnswerChange({
      ...answer,
      remark,
    });
  }

  return (
    <div className="space-y-3.5">
      {/* 1. Minimalist Step Animation (Viewfinder + Vector Illustration) */}
      <StepMinimalAnimation
        item={item}
        status={status}
        totalSteps={totalSteps}
      />

      {/* 2. Step Title & Help Text */}
      <div className="space-y-1 text-center px-1">
        <h2 className="text-sm sm:text-base font-bold text-ti-50 leading-snug">
          {item.title}
        </h2>
        {item.helpText && (
          <p className="text-xs text-ti-300 leading-relaxed">
            {item.helpText}
          </p>
        )}
      </div>

      {/* 3. NUMBER Input + Quick Tap Presets */}
      {item.inputType === "NUMBER" && (
        <div className="space-y-2 pt-1">
          <label htmlFor={`input-num-${item.id}`} className="text-xs font-medium text-ti-200 block">
            ค่าที่วัดได้ <span className="text-ember-400">*</span>
          </label>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_NUMBER_PRESETS.map((preset) => {
              const active = answer.value === preset;
              return (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleValueChange(preset)}
                  className={`h-9 rounded-control border px-3 font-mono text-xs transition-colors ${
                    active
                      ? "border-ember-500 bg-ember-500 text-white font-bold"
                      : "border-carbon-600 bg-carbon-900 text-ti-200 hover:border-carbon-500"
                  }`}
                >
                  {preset}
                </button>
              );
            })}
          </div>
          <input
            id={`input-num-${item.id}`}
            type="number"
            step="any"
            value={answer.value ?? ""}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="0.0"
            className="h-12 w-full rounded-control border border-carbon-600 bg-carbon-900 px-3.5 font-mono text-base text-ti-50 focus:outline-none focus:ring-2 focus:ring-ember-500"
          />
        </div>
      )}

      {/* 4. TEXT Input */}
      {item.inputType === "TEXT" && (
        <div className="space-y-1.5 pt-1">
          <label htmlFor={`input-text-${item.id}`} className="text-xs font-medium text-ti-200">
            ข้อสังเกต / หมายเหตุ
          </label>
          <textarea
            id={`input-text-${item.id}`}
            rows={3}
            value={answer.value ?? ""}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="ระบุข้อสังเกต (ถ้ามี)..."
            className="w-full rounded-control border border-carbon-600 bg-carbon-900 p-3 text-sm text-ti-50 focus:outline-none focus:ring-2 focus:ring-ember-500"
          />
        </div>
      )}

      {/* 5. Defect Finding Selector when marked as FAIL */}
      {isFail && (
        <DefectSelector
          availableDefects={availableDefects}
          selectedDefects={answer.defects ?? []}
          onChange={handleDefectsChange}
        />
      )}

      {/* 6. Evidence Capture & Note Input */}
      {showEvidenceAndNotes ? (
        <div className="space-y-2.5 pt-1">
          <EvidenceCapture
            photos={answer.photos ?? []}
            video={answer.video}
            missingNotes={missingNotes}
            requiresPhoto={requiresPhoto}
            requiresVideo={requiresVideo}
            onPhotosChange={handlePhotosChange}
            onVideoChange={handleVideoChange}
          />
          <input
            id={`remark-${item.id}`}
            type="text"
            value={answer.remark ?? ""}
            onChange={(e) => handleRemarkChange(e.target.value)}
            placeholder="หมายเหตุ (ถ้ามี)..."
            className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900/80 px-3.5 text-xs sm:text-sm text-ti-100 placeholder:text-ti-500 focus:outline-none focus:ring-1 focus:ring-ember-500"
          />
        </div>
      ) : (
        <div className="pt-1 text-center">
          <button
            type="button"
            onClick={() => setShowOptionalExtra(true)}
            className="inline-flex items-center gap-1.5 rounded-full border border-carbon-600 bg-carbon-900/60 px-3.5 py-1.5 text-xs text-ti-300 hover:border-carbon-500 hover:text-ti-100 transition-colors"
          >
            <span>+ รูปถ่าย / หมายเหตุ</span>
          </button>
        </div>
      )}
    </div>
  );
}

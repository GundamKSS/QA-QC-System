"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  cancelClaimApi,
  fetchInspectionTemplate,
  submitInspectionApi,
} from "@/lib/inspections/client";
import { getOfflineInspection, useNetworkSync } from "@/lib/inspections/offline-sync";
import {
  evalUnitResult,
  isItemDone,
  stepAdvanceBlockReason,
} from "@/lib/inspections/rules";
import type {
  InspectionTemplateData,
  StoredInspection,
} from "@/lib/inspections/store";
import type { ItemAnswer, UnitAction } from "@/lib/inspections/types";
import { ChecklistItemCard } from "./ChecklistItemCard";
import { InspectionSummaryModal } from "./InspectionSummaryModal";
import { StepPillsTrack } from "./StepPillsTrack";

type Props = {
  id: string;
  initialInspection: StoredInspection | null;
  initialTemplate?: InspectionTemplateData | null;
};

function getEmptySnapshot(): string {
  return "{}";
}

function subscribeStorage(callback: () => void) {
  if (typeof window === "undefined") return () => {};
  window.addEventListener("storage", callback);
  return () => window.removeEventListener("storage", callback);
}

/**
 * Screen S06: Unified Mobile-First Inspection Runner & Checklist View.
 * Matches the single-card mobile layout with top `<` back / `ยกเลิกตรวจ` actions,
 * centered Serial & step progress, minimalist vector animation, and bottom sticky Pass/Fail buttons.
 */
export function InspectionRunnerView({
  id,
  initialInspection,
  initialTemplate,
}: Props) {
  useNetworkSync();
  const router = useRouter();

  const inspection = initialInspection ?? getOfflineInspection(id);
  const [template, setTemplate] = useState<InspectionTemplateData | null>(
    initialTemplate ?? null,
  );
  const [loadingTemplate, setLoadingTemplate] = useState(!initialTemplate);

  const draftKey = `qcheck_draft_${id}`;
  const rawDraft = useSyncExternalStore(
    subscribeStorage,
    () => (typeof window === "undefined" ? "{}" : (localStorage.getItem(draftKey) ?? "{}")),
    getEmptySnapshot,
  );
  const savedDraft = useMemo(() => {
    try {
      const parsed = JSON.parse(rawDraft);
      return parsed && typeof parsed === "object" ? (parsed as Record<number, ItemAnswer>) : {};
    } catch {
      return {};
    }
  }, [rawDraft]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [slideDir, setSlideDir] = useState<"next" | "prev">("next");
  const [userEdits, setUserEdits] = useState<Record<number, ItemAnswer>>({});
  const answers = useMemo(() => ({ ...savedDraft, ...userEdits }), [savedDraft, userEdits]);
  const [blockMessage, setBlockMessage] = useState<string | null>(null);
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  // 1. Load template if not provided server-side
  useEffect(() => {
    if (template || !inspection) return;
    let cancelled = false;

    async function load() {
      try {
        const data = await fetchInspectionTemplate(
          inspection!.planId,
          inspection!.role,
        );
        if (!cancelled) {
          setTemplate(data);
        }
      } catch {
        // Fallback handled below
      } finally {
        if (!cancelled) setLoadingTemplate(false);
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, [inspection, template]);

  // 2. Listen for TopAppBar `<` Back and `ยกเลิกตรวจ` actions
  useEffect(() => {
    function onBack() {
      setBlockMessage(null);
      setCurrentIndex((prev) => {
        if (prev > 0) {
          setSlideDir("prev");
          window.scrollTo({ top: 0, behavior: "smooth" });
          return prev - 1;
        }
        router.push("/jobs");
        return prev;
      });
    }

    function onCancel() {
      setConfirmCancel(true);
    }

    window.addEventListener("qcheck:runner-back", onBack);
    window.addEventListener("qcheck:runner-cancel", onCancel);
    return () => {
      window.removeEventListener("qcheck:runner-back", onBack);
      window.removeEventListener("qcheck:runner-cancel", onCancel);
    };
  }, [router]);

  function handleAnswerChange(itemId: number, answer: ItemAnswer) {
    const updated = {
      ...answers,
      [itemId]: answer,
    };
    setUserEdits((prev) => ({ ...prev, [itemId]: answer }));
    setBlockMessage(null);
    try {
      localStorage.setItem(draftKey, JSON.stringify(updated));
    } catch {
      // Ignore quota errors
    }
  }

  function handleClearDraft() {
    setUserEdits({});
    try {
      localStorage.removeItem(draftKey);
    } catch {
      // Ignore
    }
  }

  async function handleReleaseClaim() {
    if (!inspection) return;
    setCancelling(true);
    try {
      await cancelClaimApi(inspection.id);
      handleClearDraft();
      router.push("/jobs");
    } catch {
      setCancelling(false);
      setConfirmCancel(false);
    }
  }

  if (!inspection) {
    return (
      <div className="min-w-0 w-full space-y-5 p-4 sm:p-6 max-w-xl mx-auto">
        <div className="rounded-3xl border border-carbon-700 bg-carbon-800 p-6 space-y-3 text-center">
          <h1 className="text-base font-medium text-ti-100">ไม่พบรายการตรวจนี้</h1>
          <p className="text-xs text-ti-400">
            อาจถูกยกเลิกแล้ว หรือยังไม่ได้บันทึกลงในระบบ
          </p>
          <Link
            href="/jobs"
            className="inline-flex rounded-control border border-ti-600 bg-carbon-800 px-3 py-1.5 text-xs text-ti-200 hover:border-ti-400"
          >
            กลับหน้ารวมงาน
          </Link>
        </div>
      </div>
    );
  }

  if (loadingTemplate || !template) {
    return (
      <div className="min-w-0 w-full space-y-4 p-4 sm:p-6 max-w-xl mx-auto">
        <div className="rounded-3xl border border-carbon-700 bg-carbon-800 p-12 text-center text-ti-400 text-sm">
          กำลังโหลดแบบตรวจ…
        </div>
      </div>
    );
  }

  const items = template.items;
  const total = items.length;
  const currentItem = items[currentIndex] ?? items[0];
  const currentAnswer = currentItem ? answers[currentItem.id] : undefined;
  const isLast = currentIndex === total - 1;
  const isCurrentStepDone = currentItem ? isItemDone(currentItem, currentAnswer) : false;

  const answeredCount = items.filter((item) => isItemDone(item, answers[item.id])).length;
  const percent = total > 0 ? Math.round((answeredCount / total) * 100) : 0;

  const status = currentAnswer?.status;
  const isNormal = status === "NORMAL";
  const isFail = status === "FAIL";

  const evaluation = evalUnitResult(items, answers, { role: inspection.role });

  function handleSelectStep(targetIndex: number) {
    if (targetIndex === currentIndex) return;
    setBlockMessage(null);
    setSlideDir(targetIndex > currentIndex ? "next" : "prev");
    setCurrentIndex(targetIndex);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleNext() {
    if (!currentItem) return;

    const reason = stepAdvanceBlockReason(currentItem, currentAnswer);
    if (reason) {
      setBlockMessage(reason);
      return;
    }

    setBlockMessage(null);
    if (!isLast) {
      setSlideDir("next");
      setCurrentIndex((prev) => prev + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setIsSummaryOpen(true);
    }
  }

  function handleSelectPass() {
    if (!currentItem) return;
    const nextAnswer: ItemAnswer = {
      ...currentAnswer,
      status: "NORMAL",
      defects: [],
    };
    handleAnswerChange(currentItem.id, nextAnswer);

    // If no additional evidence (e.g. mandatory video/photo) blocks this step, advance smoothly
    const blockReason = stepAdvanceBlockReason(currentItem, nextAnswer);
    if (!blockReason) {
      if (!isLast) {
        setSlideDir("next");
        setCurrentIndex((prev) => prev + 1);
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        setIsSummaryOpen(true);
      }
    }
  }

  function handleSelectFail() {
    if (!currentItem) return;
    const nextAnswer: ItemAnswer = {
      ...currentAnswer,
      status: "FAIL",
    };
    handleAnswerChange(currentItem.id, nextAnswer);
  }

  async function handleSubmitInspection(decision: UnitAction | null) {
    if (!inspection) return;
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const res = await submitInspectionApi(inspection.id, {
        planId: inspection.planId,
        workOrderId: inspection.workOrderId ?? "",
        role: inspection.role,
        answers,
        decision,
      });

      if (res.status === "done") {
        handleClearDraft();
        setIsSummaryOpen(false);
        router.push("/jobs");
      } else {
        setSubmitError(res.message || "ไม่สามารถบันทึกผลการตรวจได้");
      }
    } catch {
      setSubmitError("เกิดข้อผิดพลาดในการเชื่อมต่อ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-w-0 w-full max-w-xl mx-auto flex flex-col justify-between min-h-[calc(100dvh-8.5rem)] p-3 sm:p-5 pb-28 md:pb-6 gap-3">
      {/* Main Unified Inspection Card */}
      <div className="rounded-3xl border border-carbon-700 bg-carbon-800 p-4 sm:p-6 space-y-3.5 shadow-sm">
        {/* 1. Work Order & Centered Serial Header */}
        <div className="space-y-1">
          <div className="text-xs font-mono font-bold text-ember-500 truncate">
            {inspection.workOrderId
              ? `ใบงาน ${inspection.workOrderId.slice(0, 18).toUpperCase()}`
              : `แผนตรวจ #${inspection.planId}`}
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-mono text-ti-50 text-center tracking-tight py-0.5">
            Serial {inspection.serialPump}
          </h1>
          <div className="text-xs sm:text-sm font-semibold text-ti-100 text-center">
            ขั้นตอน {currentIndex + 1} / {total}
          </div>
        </div>

        {/* 2. Progress Counter & Slim Gradient Bar */}
        <div className="space-y-1.5 px-1">
          <div className="flex items-center justify-between text-xs font-mono text-ti-300">
            <span>
              สำเร็จ {answeredCount}/{total} ({percent}%)
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-carbon-900">
            <div
              className="h-full rounded-full bg-gradient-to-r from-ember-500 to-pass transition-all duration-300"
              style={{ width: `${Math.max(4, percent)}%` }}
            />
          </div>
        </div>

        {/* Step Navigation Pills [ 1 ✓ ] - [ 2 ✓ ] - [ 3 ] - [ 4 ] - [ 5 ] */}
        <StepPillsTrack
          items={items}
          answers={answers}
          currentIndex={currentIndex}
          onSelectStep={handleSelectStep}
          onBlockedJump={(reason) => setBlockMessage(reason)}
        />

        {/* Step Guard / Leave Block Alert Banner */}
        {blockMessage && (
          <div
            role="alert"
            className="rounded-xl border border-fail/60 bg-fail/10 p-3 text-xs font-medium text-fail flex items-center justify-between gap-2"
          >
            <span>{blockMessage}</span>
            <button
              type="button"
              onClick={() => setBlockMessage(null)}
              className="shrink-0 text-fail/80 hover:text-fail px-1"
              aria-label="ปิดข้อความแจ้งเตือน"
            >
              ✕
            </button>
          </div>
        )}

        {/* 3. Step Animation + Question + Defect Selector / Evidence with Slide Animation */}
        {currentItem && (
          <div
            key={currentItem.id}
            className={slideDir === "next" ? "animate-slide-next" : "animate-slide-prev"}
          >
            <ChecklistItemCard
              item={currentItem}
              totalSteps={total}
              answer={currentAnswer}
              availableDefects={template.itemDefects[currentItem.id] ?? []}
              onAnswerChange={(ans) => handleAnswerChange(currentItem.id, ans)}
            />
          </div>
        )}
      </div>

      {/* Bottom Floating Pass / Fail Action Dock */}
      <div className="fixed bottom-[calc(3.75rem+env(safe-area-inset-bottom))] md:sticky md:bottom-2 z-30 inset-x-3 sm:inset-x-auto sm:w-full max-w-xl mx-auto bg-carbon-900/95 backdrop-blur-md p-2.5 sm:p-3 rounded-3xl border border-carbon-700/80 shadow-2xl transition-all duration-300 ease-out space-y-2">
        {currentItem?.inputType === "PASS_FAIL" ? (
          <>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleSelectPass}
                aria-pressed={isNormal}
                className={`h-14 rounded-2xl text-sm sm:text-base font-bold border-2 transition-all flex items-center justify-center gap-2 ${
                  isNormal
                    ? "border-pass bg-pass/20 text-pass ring-2 ring-pass/30 shadow-sm"
                    : "border-carbon-600 bg-carbon-800 text-ti-100 hover:border-carbon-500"
                }`}
              >
                <span aria-hidden="true" className="text-lg">✓</span>
                <span>ปกติ (Pass)</span>
              </button>

              <button
                type="button"
                onClick={handleSelectFail}
                aria-pressed={isFail}
                className={`h-14 rounded-2xl text-sm sm:text-base font-bold border-2 transition-all flex items-center justify-center gap-2 ${
                  isFail
                    ? "border-fail bg-fail/15 text-fail ring-2 ring-fail/30 shadow-sm"
                    : "border-fail/40 bg-fail/8 text-fail hover:border-fail/70"
                }`}
              >
                <span aria-hidden="true" className="text-lg">✕</span>
                <span>พบปัญหา (Fail)</span>
              </button>
            </div>

            {/* When all steps are done, display summary trigger button */}
            {answeredCount === total && (
              <button
                type="button"
                onClick={() => setIsSummaryOpen(true)}
                className="w-full h-12 rounded-2xl app-primary-action bg-ember-500 hover:bg-ember-400 text-sm font-bold text-white shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>สรุปผลตรวจ ✓</span>
              </button>
            )}
          </>
        ) : (
          <button
            type="button"
            onClick={handleNext}
            className={`w-full h-14 rounded-2xl text-sm sm:text-base font-bold transition-all shadow-sm ${
              isCurrentStepDone
                ? "app-primary-action bg-ember-500 hover:bg-ember-400 text-white"
                : "border-2 border-carbon-600 bg-carbon-800 text-ti-300"
            }`}
          >
            {isLast ? "สรุปผลตรวจ" : "ถัดไป ▶"}
          </button>
        )}
      </div>

      {/* Confirmation Dialog for Releasing Claim ("ยกเลิกตรวจ") */}
      {confirmCancel && (
        <div
          role="alertdialog"
          aria-labelledby="cancel-claim-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
        >
          <div className="w-full max-w-sm rounded-2xl border border-carbon-600 bg-carbon-800 p-5 space-y-4 shadow-xl">
            <h2 id="cancel-claim-title" className="text-base font-semibold text-ti-100">
              ยกเลิกการตรวจเครื่องนี้?
            </h2>
            <p className="text-xs text-ti-300 leading-relaxed">
              เครื่อง{" "}
              <span className="font-mono font-medium text-ember-400">
                {inspection.serialPump}
              </span>{" "}
              จะถูกคืนเข้าใบงาน
            </p>
            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setConfirmCancel(false)}
                disabled={cancelling}
                className="h-10 rounded-xl border border-ti-600 px-3.5 text-xs text-ti-200 hover:border-ti-400"
              >
                กลับไปตรวจ
              </button>
              <button
                type="button"
                onClick={handleReleaseClaim}
                disabled={cancelling}
                className="h-10 rounded-xl bg-fail px-4 text-xs font-semibold text-white hover:bg-fail/90 disabled:opacity-50"
              >
                {cancelling ? "กำลังคืนเครื่อง…" : "ยืนยันยกเลิก"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Screen S07 Summary & Decision Modal */}
      <InspectionSummaryModal
        isOpen={isSummaryOpen}
        evaluation={evaluation}
        items={items}
        answers={answers}
        role={inspection.role}
        isSubmitting={isSubmitting}
        errorMessage={submitError}
        onClose={() => setIsSummaryOpen(false)}
        onSubmit={handleSubmitInspection}
      />
    </div>
  );
}

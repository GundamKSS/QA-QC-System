"use client";

import { useEffect, useRef, useState } from "react";
import {
  canJumpToStep,
  isItemDone,
  maxUnlockedStepIndex,
} from "@/lib/inspections/rules";
import type { InspectionItem, ItemAnswer } from "@/lib/inspections/types";

type Props = {
  items: readonly InspectionItem[];
  answers: Record<number, ItemAnswer | undefined>;
  currentIndex: number;
  onSelectStep: (targetIndex: number) => void;
  onBlockedJump?: (reason: string) => void;
};

/**
 * Screen S06 Step Navigation Pills Track:
 * Displays a horizontally scrollable sequence of step badges [ 1 ✓ ] - [ 2 ✓ ] - [ 3 ] - [ 4 ] - [ 5 ].
 * Enforces strict step progression:
 * - Completed steps [ 1 ✓ ], [ 2 ✓ ] can be freely tapped anytime to review or edit.
 * - Future unreached steps [ 4 ], [ 5 ] remain locked until preceding steps are completed.
 * - Smooth auto-scrolling centers the active step pill in view.
 */
export function StepPillsTrack({
  items,
  answers,
  currentIndex,
  onSelectStep,
  onBlockedJump,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const pillRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const [shakingIndex, setShakingIndex] = useState<number | null>(null);

  const maxUnlocked = maxUnlockedStepIndex(items, answers);

  // Auto-scroll track to keep the current active step centered
  useEffect(() => {
    const activePill = pillRefs.current[currentIndex];
    if (activePill && containerRef.current) {
      activePill.scrollIntoView({
        behavior: "smooth",
        inline: "center",
        block: "nearest",
      });
    }
  }, [currentIndex]);

  function handlePillClick(targetIndex: number) {
    if (targetIndex === currentIndex) return;

    const check = canJumpToStep(items, answers, currentIndex, targetIndex);
    if (!check.allowed) {
      setShakingIndex(targetIndex);
      setTimeout(() => setShakingIndex(null), 400);
      onBlockedJump?.(check.reason);
      return;
    }

    onSelectStep(targetIndex);
  }

  return (
    <div className="w-full space-y-1.5 py-1">
      {/* Horizontal Scrollable Pills Track */}
      <div
        ref={containerRef}
        className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth px-1 py-1 -mx-1"
        role="tablist"
        aria-label="ขั้นตอนการตรวจ"
      >
        {items.map((item, idx) => {
          const stepNum = idx + 1;
          const isDone = isItemDone(item, answers[item.id]);
          const isActive = idx === currentIndex;
          const isUnlocked = idx <= maxUnlocked;
          const isShaking = shakingIndex === idx;

          return (
            <div key={item.id} className="flex items-center shrink-0">
              {/* Connector line between pills */}
              {idx > 0 && (
                <span
                  aria-hidden="true"
                  className={`px-1 font-mono text-xs select-none ${
                    idx <= maxUnlocked ? "text-ti-400" : "text-carbon-600"
                  }`}
                >
                  -
                </span>
              )}

              <button
                ref={(el) => {
                  pillRefs.current[idx] = el;
                }}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`ขั้นตอนที่ ${stepNum}: ${item.title}${
                  isDone ? " (เสร็จแล้ว)" : isUnlocked ? "" : " (ยังไม่ปลดล็อก)"
                }`}
                onClick={() => handlePillClick(idx)}
                className={`relative flex items-center justify-center min-w-11 h-11 px-2.5 rounded-2xl font-mono text-sm transition-all select-none ${
                  isShaking ? "animate-shake ring-2 ring-fail" : ""
                } ${
                  isActive
                    ? "border-2 border-ember-500 bg-ember-500/20 text-ember-300 font-bold ring-2 ring-ember-500/30 scale-105 shadow-md"
                    : isDone
                    ? "border border-pass/50 bg-pass/15 text-pass font-semibold hover:bg-pass/25 cursor-pointer shadow-xs"
                    : isUnlocked
                    ? "border border-carbon-600 bg-carbon-800 text-ti-100 hover:border-carbon-500 cursor-pointer"
                    : "border border-carbon-800 bg-carbon-900/60 text-ti-500 opacity-40 cursor-not-allowed"
                }`}
              >
                <span>{stepNum}</span>
                {isDone && (
                  <span
                    aria-hidden="true"
                    className="ml-1 text-[11px] font-bold text-pass leading-none"
                  >
                    ✓
                  </span>
                )}

                {/* Sleek active underline bar */}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute -bottom-1 h-0.5 w-5 rounded-full bg-ember-500"
                  />
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

import { describe, expect, it } from "vitest";
import {
  canJumpToStep,
  evalUnitResult,
  inferItemAnimationType,
  isItemDone,
  leaveBlockReason,
  maxUnlockedStepIndex,
  stepAdvanceBlockReason,
} from "@/lib/inspections/rules";
import type { InspectionItem, ItemAnswer } from "@/lib/inspections/types";

describe("Screen S06 & S07 - Checklist Runner & Summary Rules", () => {
  const normalItem: InspectionItem = {
    id: 1,
    seq: 1,
    topicCode: "CHK-01",
    title: "ระดับน้ำมันเครื่อง",
    inputType: "PASS_FAIL",
    isRequired: true,
    videoRule: "NONE",
  };

  const videoItem: InspectionItem = {
    id: 2,
    seq: 2,
    topicCode: "CHK-02",
    title: "การรั่วซึมและความดัน",
    inputType: "PASS_FAIL",
    isRequired: true,
    videoRule: "ON_FAIL",
  };

  it("leaveBlockReason enforces defect selection and photo evidence before leaving (AC FR-QC-04/05/06)", () => {
    // 1. Normal status -> no block
    expect(leaveBlockReason(normalItem, { status: "NORMAL" })).toBeNull();

    // 2. FAIL with no defect selected -> blocked
    const failNoDefect: ItemAnswer = { status: "FAIL", defects: [] };
    const reason1 = leaveBlockReason(normalItem, failNoDefect);
    expect(reason1).toContain("เลือกอาการอย่างน้อย 1 อาการ");

    // 3. FAIL with defect but no photo -> blocked
    const failWithDefect: ItemAnswer = {
      status: "FAIL",
      defects: [
        {
          defectId: 101,
          code: "DEF01",
          nameTh: "น้ำมันรั่ว",
          severity: "MAJOR",
          disposition: "REWORK",
        },
      ],
      photos: [],
    };
    const reason2 = leaveBlockReason(normalItem, failWithDefect);
    expect(reason2).toContain("ถ่ายรูปหลักฐานอย่างน้อย 1 รูป");

    // 4. FAIL with defect + photo -> can leave normal item
    const failSatisfied: ItemAnswer = {
      status: "FAIL",
      defects: [
        {
          defectId: 101,
          code: "DEF01",
          nameTh: "น้ำมันรั่ว",
          severity: "MAJOR",
          disposition: "REWORK",
        },
      ],
      photos: [{ uri: "photo.jpg", timestamp: new Date().toISOString() }],
    };
    expect(leaveBlockReason(normalItem, failSatisfied)).toBeNull();

    // 5. VideoItem when FAIL requires video as well
    const failMissingVideo: ItemAnswer = {
      status: "FAIL",
      defects: [
        {
          defectId: 101,
          code: "DEF01",
          nameTh: "รั่วซึมแรงดันสูง",
          severity: "MAJOR",
          disposition: "REWORK",
        },
      ],
      photos: [{ uri: "photo.jpg", timestamp: new Date().toISOString() }],
      video: null,
    };
    const reason3 = leaveBlockReason(videoItem, failMissingVideo);
    expect(reason3).toContain("ถ่ายวิดีโอ");
  });

  it("evalUnitResult computes outcomes for Screen S07 Summary Modal (BR-04)", () => {
    const items = [normalItem, videoItem];

    // Case A: All items Normal -> PASS
    const answersPass: Record<number, ItemAnswer> = {
      1: { status: "NORMAL" },
      2: { status: "NORMAL" },
    };
    const evalPass = evalUnitResult(items, answersPass);
    expect(evalPass.result).toBe("PASS");
    expect(evalPass.forcedAction).toBeNull();

    // Case B: Item 1 has CONCESSION defect -> CONCESSION
    const answersConcession: Record<number, ItemAnswer> = {
      1: {
        status: "FAIL",
        defects: [
          {
            defectId: 102,
            code: "DEF02",
            nameTh: "สีถลอกเล็กน้อย",
            severity: "MINOR",
            disposition: "CONCESSION",
          },
        ],
        photos: [{ uri: "p.jpg", timestamp: "..." }],
      },
      2: { status: "NORMAL" },
    };
    const evalConcession = evalUnitResult(items, answersConcession);
    expect(evalConcession.result).toBe("CONCESSION");

    // Case C: Critical defect with REJECT disposition -> NOT_PASSED and forcedAction = REJECT
    const answersCritical: Record<number, ItemAnswer> = {
      1: { status: "NORMAL" },
      2: {
        status: "FAIL",
        defects: [
          {
            defectId: 103,
            code: "DEF03",
            nameTh: "ถังลมบุบร้าว",
            severity: "CRITICAL",
            disposition: "REJECT",
          },
        ],
        photos: [{ uri: "p.jpg", timestamp: "..." }],
        video: { uri: "v.mp4", durationSeconds: 5 },
      },
    };
    const evalCritical = evalUnitResult(items, answersCritical);
    expect(evalCritical.result).toBe("NOT_PASSED");
    expect(evalCritical.forcedAction).toBe("REJECT");
    expect(evalCritical.suggestedAction).toBe("REJECT");
  });

  it("isItemDone accurately reflects item completion status", () => {
    expect(isItemDone(normalItem, null)).toBe(false);
    expect(isItemDone(normalItem, { status: null })).toBe(false);
    expect(isItemDone(normalItem, { status: "NORMAL" })).toBe(true);
    expect(isItemDone(normalItem, { status: "FAIL", defects: [] })).toBe(false);
  });

  it("enforces strict sequential 1-2-3 progression without skipping steps", () => {
    const step3: InspectionItem = {
      id: 3,
      seq: 3,
      topicCode: "CHK-03",
      title: "วัดแรงดันตัด (Bar)",
      inputType: "NUMBER",
      isRequired: true,
      videoRule: "NONE",
    };
    const steps = [normalItem, videoItem, step3];

    // Initially only step 0 (seq 1) is unlocked
    expect(maxUnlockedStepIndex(steps, {})).toBe(0);
    expect(stepAdvanceBlockReason(normalItem, {})).toContain("ห้ามข้ามขั้นตอน");

    // Trying to jump from step 0 to step 1 or 2 is blocked
    expect(canJumpToStep(steps, {}, 0, 1)).toEqual({
      allowed: false,
      reason: expect.stringContaining("ห้ามข้ามขั้นตอน"),
    });
    expect(canJumpToStep(steps, {}, 0, 2)).toEqual({
      allowed: false,
      reason: expect.stringContaining("ห้ามข้ามขั้นตอน"),
    });

    // After completing step 0, step 1 unlocks (but step 2 remains locked)
    const answersAfterStep1: Record<number, ItemAnswer> = {
      1: { status: "NORMAL" },
    };
    expect(maxUnlockedStepIndex(steps, answersAfterStep1)).toBe(1);
    expect(stepAdvanceBlockReason(normalItem, answersAfterStep1[1])).toBeNull();
    expect(canJumpToStep(steps, answersAfterStep1, 0, 1)).toEqual({ allowed: true });
    expect(canJumpToStep(steps, answersAfterStep1, 1, 2)).toEqual({
      allowed: false,
      reason: expect.stringContaining("ห้ามข้ามขั้นตอน"),
    });
    // Can always jump backward from step 1 to step 0
    expect(canJumpToStep(steps, answersAfterStep1, 1, 0)).toEqual({ allowed: true });
  });

  it("infers minimalist vector animation type for each step", () => {
    expect(inferItemAnimationType(normalItem)).toBe("AIR_TANK");
    expect(inferItemAnimationType(videoItem)).toBe("VALVE_LEAK");
    expect(
      inferItemAnimationType({
        ...normalItem,
        animationType: "SCAN_PUMP",
      }),
    ).toBe("SCAN_PUMP");
  });
});

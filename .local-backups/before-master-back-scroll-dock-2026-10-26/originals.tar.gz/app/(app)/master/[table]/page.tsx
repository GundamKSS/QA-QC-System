import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { requirePageAccess } from "@/lib/auth/dal";
import { canAccessPage } from "@/lib/auth/page-access";
import { dbConfigured } from "@/lib/db/config";
import { dbProblem, dbProblemMessages, isDbError } from "@/lib/db/errors";
import { defaultValues, displayValue } from "@/lib/master/form";
import { masterBySlug, type MasterDef } from "@/lib/master/registry";
import { getMaster, listMaster, poolDb, refOptions, type MasterRow } from "@/lib/master/repo";
import { MasterForm, type FieldOptions } from "./MasterForms";
import { MasterRecords } from "./MasterRecords";
import "./master-table.css";

export const metadata = { title: "ข้อมูลหลัก" };

type SearchParams = Record<string, string | string[] | undefined>;
const PAGE_SIZE = 50;
const one = (value: string | string[] | undefined) => (Array.isArray(value) ? value[0] : value) ?? "";

export default function MasterTablePage({ params, searchParams }: { params: Promise<{ table: string }>; searchParams: Promise<SearchParams> }) {
  return (
    <Suspense fallback={<p className="p-6 text-ti-400">กำลังโหลด…</p>}>
      <MasterTable params={params} searchParams={searchParams} />
    </Suspense>
  );
}

async function loadOptions(def: MasterDef): Promise<FieldOptions> {
  const options: FieldOptions = {};
  for (const field of def.fields) if (field.kind === "ref") options[field.key] = await refOptions(poolDb(), field.ref.table, field.ref.labelColumn);
  return options;
}

async function MasterTable({ params, searchParams }: { params: Promise<{ table: string }>; searchParams: Promise<SearchParams> }) {
  const { table } = await params;
  const def = masterBySlug(table);
  if (!def) notFound();
  const path = `/master/${def.slug}`;
  const user = await requirePageAccess("master", path);
  const canEdit = canAccessPage(user.roles, "master-edit");
  const query = await searchParams;
  const q = one(query.q).slice(0, 100);
  const statusParam = one(query.status);
  const status = statusParam === "active" || statusParam === "inactive" ? statusParam : "all";
  const page = Math.max(1, Number.parseInt(one(query.page), 10) || 1);
  const editId = /^\d{1,9}$/.test(one(query.edit)) ? Number(one(query.edit)) : null;
  const creating = one(query.new) === "1";
  const saved = /^\d{1,9}$/.test(one(query.saved)) ? Number(one(query.saved)) : null;

  if (!dbConfigured()) return <Shell def={def}><Alert>ยังไม่ได้ตั้งค่าฐานข้อมูล (DB_SERVER) — ข้อมูลหลักต้องใช้ SQL Server</Alert></Shell>;

  let data: { rows: MasterRow[]; total: number; editing: MasterRow | null; options: FieldOptions };
  try {
    const db = poolDb();
    const list = await listMaster(db, def, { q, status, page, pageSize: PAGE_SIZE });
    const editing = canEdit && editId !== null ? await getMaster(db, def, editId) : null;
    const options = canEdit && (creating || editing) ? await loadOptions(def) : {};
    data = { ...list, editing, options };
  } catch (error) {
    if (!isDbError(error)) throw error;
    console.error("[db] master list failed", error.message);
    return <Shell def={def}><Alert>{dbProblemMessages[dbProblem(error)]}</Alert></Shell>;
  }

  const pages = Math.max(1, Math.ceil(data.total / PAGE_SIZE));
  const link = (changes: Record<string, string | number | null>) => {
    const next = new URLSearchParams();
    const merged = { q, status: status === "all" ? "" : status, page: page > 1 ? String(page) : "", ...changes };
    for (const [key, value] of Object.entries(merged)) if (value !== null && value !== "") next.set(key, String(value));
    const text = next.toString();
    return text ? `${path}?${text}` : path;
  };
  const savedRow = saved !== null ? data.rows.find((row) => row.id === saved) : undefined;

  return (
    <Shell def={def} total={data.total} action={canEdit && !creating && !data.editing ? <Link href={link({ new: "1" })} className={`app-primary-action bg-ember-500 text-carbon-900 hover:bg-ember-400 master-add`}><span aria-hidden="true" className="text-xl font-normal">+</span>เพิ่ม{def.singular}</Link> : null}>
      {saved !== null && <p role="status" className="rounded-control border border-green-500/40 bg-carbon-800 px-3 py-2 text-sm text-green-300">บันทึกแล้ว{savedRow ? ` — ${displayValue(def.fields[0], savedRow.values[def.fields[0].key])}` : ""}</p>}

      {canEdit && creating && <MasterForm def={def} id={null} values={defaultValues(def)} options={data.options} cancelHref={link({})} />}
      {canEdit && data.editing && <MasterForm def={def} id={data.editing.id} values={data.editing.values} options={data.options} cancelHref={link({})} />}
      {canEdit && editId !== null && !data.editing && <Alert>ไม่พบรายการที่จะแก้ไข</Alert>}

      <form method="get" action={path} className="app-panel master-filters" role="search" aria-label={`ค้นหา${def.singular}`}>
        <label className={`master-filter-label master-search-field`}>
          <span>ค้นหา{def.singular}</span>
          <span className="master-input-wrap">
            <svg className="master-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4 4" /></svg>
            <input name="q" type="search" defaultValue={q} maxLength={100} placeholder="ค้นหาจากรหัสหรือชื่อ…" className="master-input" />
          </span>
        </label>
        <label className="master-filter-label">
          <span>สถานะ</span>
          <select name="status" defaultValue={status === "all" ? "" : status} className="master-select">
            <option value="">ทั้งหมด</option>
            <option value="active">ใช้งาน</option>
            <option value="inactive">ปิดใช้งาน</option>
          </select>
        </label>
        <button type="submit" className="master-filter-button">ค้นหา</button>
      </form>

      <div className="master-result-bar">
        <p>{data.rows.length > 0 ? <>แสดง <strong>{(page - 1) * PAGE_SIZE + 1}–{(page - 1) * PAGE_SIZE + data.rows.length}</strong> จาก <strong>{data.total.toLocaleString("th-TH")}</strong> รายการ</> : "0 รายการ"}</p>
        {(q || status !== "all") && <Link href={path} className="master-clear">ล้างตัวกรอง</Link>}
      </div>

      {data.rows.length === 0 ? (
        <div className="app-panel master-empty">
          <span className="master-empty-icon" aria-hidden="true"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 9h16M9 9v11" /></svg></span>
          <h2>{q || status !== "all" ? "ไม่พบรายการที่ตรงกับเงื่อนไข" : `ยังไม่มี${def.singular}`}</h2>
          <p>{q || status !== "all" ? "ลองค้นหาด้วยคำอื่น หรือเปลี่ยนตัวกรองสถานะ" : canEdit ? `กด “เพิ่ม${def.singular}” เพื่อเริ่มบันทึกข้อมูล` : "รายการจะแสดงที่นี่เมื่อมีการเพิ่มข้อมูล"}</p>
          {(q || status !== "all") && <Link href={path} className="master-clear">แสดงรายการทั้งหมด</Link>}
        </div>
      ) : <MasterRecords def={def} rows={data.rows} canEdit={canEdit} saved={saved} editHref={(id) => link({ edit: id })} />}

      {pages > 1 && (
        <nav aria-label="หน้ารายการข้อมูลหลัก" className="master-pagination">
          {page > 1 ? <Link href={link({ page: page - 1 })}>← ก่อนหน้า</Link> : <span />}
          <span>หน้า {page} / {pages}</span>
          {page < pages ? <Link href={link({ page: page + 1 })}>ถัดไป →</Link> : <span />}
        </nav>
      )}
    </Shell>
  );
}

function Alert({ children }: { children: React.ReactNode }) {
  return <p role="alert" className="rounded-control border border-red-500/50 bg-carbon-800 px-3 py-2 text-sm text-red-300">{children}</p>;
}

function Shell({ def, total, action, children }: { def: MasterDef; total?: number; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="master-page"><div className="master-content">
      <Link href="/master" className="master-back">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m12 5-7 7 7 7M5 12h14" /></svg>
        กลับไปข้อมูลหลัก
      </Link>
      <header className="master-header">
        <div className="master-title-block">
          <div className="master-title-line"><h1>{def.label}</h1>{total !== undefined && <span className="master-count">{total.toLocaleString("th-TH")} รายการ</span>}</div>
          <p className="master-description">{def.description}</p>
        </div>
        {action}
      </header>
      {children}
    </div></div>
  );
}

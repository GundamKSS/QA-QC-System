import { revalidatePath } from "next/cache";
import { readFields } from "@/lib/api/body";
import { dbFailure } from "@/lib/api/db";
import { guardApi } from "@/lib/api/guard";
import { readQuery } from "@/lib/api/query";
import { apiData, apiError, apiJson } from "@/lib/api/response";
import { audit, auditContext } from "@/lib/auth/audit";
import { canAccessPage } from "@/lib/auth/page-access";
import type { InspectionRole } from "@/lib/inspections/types";
import { parseSaveModelChecklistInput } from "@/lib/master/model-checklist-types";
import {
  loadModelChecklistPayload,
  saveModelChecklist,
} from "@/lib/master/model-checklists";

/**
 * GET /api/master/model-checklists
 * Load models, active checklist items for the selected model & role, and the common master checklist pool.
 */
export async function GET(request: Request) {
  const guard = await guardApi(request, {
    page: "master",
    returnTo: "/master/model-checklists",
  });
  if ("response" in guard) return guard.response;

  const query = readQuery(request);
  const rawModelId = typeof query.modelId === "string" ? Number(query.modelId) : undefined;
  const modelId = rawModelId && Number.isFinite(rawModelId) && rawModelId > 0 ? rawModelId : undefined;
  const role: InspectionRole = query.role === "QA" ? "QA" : "QC";

  try {
    const payload = await loadModelChecklistPayload({ modelId, role });
    return apiData(payload);
  } catch (error) {
    return dbFailure(error, "load model checklists");
  }
}

/**
 * POST /api/master/model-checklists
 * Save and publish a new checklist version for a model (add / remove / reorder checklist steps).
 */
export async function POST(request: Request) {
  const guard = await guardApi(request, {
    page: "master",
    returnTo: "/master/model-checklists",
  });
  if ("response" in guard) return guard.response;

  const { user } = guard;
  const canEdit =
    canAccessPage(user.roles, "master-edit") ||
    user.roles.includes("ADMIN") ||
    user.roles.includes("QC_HEAD") ||
    user.roles.includes("QA_HEAD");

  if (!canEdit) {
    return apiError(403, "ไม่มีสิทธิ์แก้ไขเช็คลิสต์รายรุ่น (เฉพาะ Admin / Master Admin / หัวหน้า QC-QA)");
  }

  const contentType = request.headers.get("content-type") ?? "";
  let rawBody: { modelId?: unknown; role?: unknown; items?: unknown } = {};
  if (contentType.includes("application/json")) {
    try {
      rawBody = (await request.json()) as typeof rawBody;
    } catch {
      return apiError(422, "รูปแบบข้อมูล JSON ไม่ถูกต้อง");
    }
  } else {
    const fields = await readFields(request);
    rawBody = {
      modelId: fields.get("modelId"),
      role: fields.get("role"),
      items: fields.get("items"),
    };
  }

  const parsed = parseSaveModelChecklistInput(rawBody);

  if (!parsed.ok) {
    return apiError(422, parsed.message);
  }

  try {
    const saved = await saveModelChecklist(user.id, parsed.data);
    if (!saved) {
      return apiError(404, "ไม่พบโมเดลที่ต้องการบันทึกเช็คลิสต์");
    }

    audit(
      {
        action: "master.update",
        employeeCode: user.employeeCode,
        userId: user.id,
        entity: {
          type: "model_checklist",
          id: `${parsed.data.modelId}:${parsed.data.role}`,
        },
        after: {
          modelCode: saved.modelCode,
          role: parsed.data.role,
          versionNo: saved.versionNo,
          itemCount: saved.itemCount,
        },
      },
      auditContext(request.headers),
    );

    revalidatePath("/master");
    revalidatePath("/master/model-checklists");

    return apiJson({
      status: "done",
      message: `บันทึกและเผยแพร่เช็คลิสต์รุ่น ${saved.modelCode} (${parsed.data.role}) เวอร์ชัน v${saved.versionNo} (${saved.itemCount} ขั้นตอน) เรียบร้อยแล้ว`,
      versionId: saved.versionId,
      versionNo: saved.versionNo,
      itemCount: saved.itemCount,
    });
  } catch (error) {
    return dbFailure(error, "save model checklist");
  }
}

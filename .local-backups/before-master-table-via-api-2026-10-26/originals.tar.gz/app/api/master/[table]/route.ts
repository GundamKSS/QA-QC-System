import { revalidatePath } from "next/cache";
import { readFields } from "@/lib/api/body";
import { apiError, apiJson } from "@/lib/api/response";
import { audit } from "@/lib/auth/audit";
import { resolveActorId } from "@/lib/db/actor";
import { masterContext, masterWriteFailure } from "@/lib/master/api";
import { parseMasterForm } from "@/lib/master/form";
import { createMaster, poolDb } from "@/lib/master/repo";

/** Add one master row (FR-MD-01…09). Master Admin only; audited. Answers `redirectTo` the list with `?saved=<id>`. */
export async function POST(request: Request, context: { params: Promise<{ table: string }> }) {
  const at = Date.now();
  const ctx = await masterContext(request, context);
  if ("response" in ctx) return ctx.response;
  const { def, actor, trail } = ctx;

  const parsed = parseMasterForm(def, (await readFields(request)).get);
  if (!parsed.ok) return apiError(422, "กรุณาแก้ช่องที่มีปัญหา", { fieldErrors: parsed.errors, values: parsed.values, at });

  let savedId: number;
  try {
    savedId = await createMaster(poolDb(), def, parsed.values, await resolveActorId(actor.id));
    audit({ action: "master.create", employeeCode: actor.employeeCode, userId: actor.id, entity: { type: def.table, id: String(savedId) }, after: parsed.values }, trail);
  } catch (error) {
    return masterWriteFailure(error, { values: parsed.values, at });
  }
  revalidatePath("/master");
  revalidatePath(`/master/${def.slug}`);
  return apiJson({ status: "done", redirectTo: `/master/${def.slug}?saved=${savedId}` }, 201);
}

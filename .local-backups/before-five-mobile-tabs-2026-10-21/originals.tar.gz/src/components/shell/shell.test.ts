import { describe, expect, it } from "vitest";
import { ROLES } from "@/lib/auth/types";
import { bottomTabs, canOpenPlan, canSeeMaster, isActive, isAvailable, primaryRole } from "./nav";

describe("app navigation", () => {
  it("keeps four mobile destinations and a selected home tab for every role", () => {
    for (const role of ROLES) {
      const tabs = bottomTabs([role]);
      expect(tabs).toHaveLength(4);
      expect(tabs.filter(tab => isActive("/home", tab))).toHaveLength(1);
    }
  });

  it("prioritizes the inspection role consistently across navigation and account labels", () => {
    expect(primaryRole(["ADMIN", "QA_HEAD", "QA_INSPECTOR", "QC_INSPECTOR"])).toBe("QC_INSPECTOR");
  });

  it("does not offer head-only actions or master data to ordinary inspectors", () => {
    for (const role of ["QC_INSPECTOR", "QA_INSPECTOR"] as const) {
      expect(canOpenPlan([role])).toBe(false);
      expect(canSeeMaster([role])).toBe(false);
    }
    expect(canOpenPlan(["QC_HEAD"])).toBe(true);
    expect(canOpenPlan(["QA_HEAD"])).toBe(true);
    expect(canOpenPlan(["ADMIN"])).toBe(true);
    for (const role of ["MASTER_ADMIN", "PURCHASING", "PM", "MANAGEMENT"] as const) expect(canOpenPlan([role])).toBe(false);
  });

  it("only enables destinations that have pages", () => {
    for (const path of ["/home", "/more", "/alerts", "/admin/users", "/master", "/plans", "/plans/new", "/plans/12", "/plans/12?tab=history", "/plans/12/work-orders/new", "/jobs"]) expect(isAvailable(path)).toBe(true);
    for (const path of ["/plans/plan-001", "/scan", "/settings"]) expect(isAvailable(path)).toBe(false);
  });

  it("sends the plan and job tabs to the real pages on mobile (docs/16 §0)", () => {
    expect(bottomTabs(["QC_HEAD"]).map((tab) => tab.href)).toEqual(["/plans", "/jobs", "/alerts", "/more"]);
    expect(bottomTabs(["QA_HEAD"])[0].href).toBe("/plans");
    expect(bottomTabs(["QC_INSPECTOR"])[0].href).toBe("/jobs");
  });
});

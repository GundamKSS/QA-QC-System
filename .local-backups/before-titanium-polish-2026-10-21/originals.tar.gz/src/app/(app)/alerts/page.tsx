import { Suspense } from "react";
import { requirePageAccess } from "@/lib/auth/dal";

export const metadata = { title: "แจ้งเตือน" };

export default function AlertsPage() {
  return <Suspense fallback={<p className="p-6 text-ti-400">กำลังโหลดแจ้งเตือน…</p>}><AlertsContent /></Suspense>;
}

async function AlertsContent() {
  await requirePageAccess("alerts", "/alerts");
  return <div className="mx-auto max-w-2xl space-y-4 p-4 sm:p-6">
    <h1 className="text-2xl text-ti-50">แจ้งเตือน</h1>
    <div className="rounded-xl border border-carbon-700 bg-carbon-800 p-6">
      <p className="text-ti-200">ยังไม่มีแจ้งเตือน</p>
      <p className="mt-2 text-sm text-ti-400">เมื่อมีงานหรือผลตรวจที่เกี่ยวข้อง รายการจะแสดงที่นี่</p>
    </div>
  </div>;
}


"use client";

import {
  isItemDone,
  maxUnlockedStepIndex,
  missingEvidenceForItem,
} from "@/lib/inspections/rules";
import type { InspectionItem, ItemAnswer } from "@/lib/inspections/types";

type Props = {
  items: readonly InspectionItem[];
  answers: Record<number, ItemAnswer | undefined>;
  currentIndex: number;
  onSelectIndex: (index: number) => void;
};

/**
 * Screen S06 Stepper: Strict sequential step-by-step progression bar (1-2-3-4-5-6).
 * Future steps beyond `maxUnlockedStepIndex` are locked (🔒) so inspectors cannot skip steps.
 */
export function RunnerStepper({
  items,
  answers,
  currentIndex,
  onSelectIndex,
}: Props) {
  const total = items.length;
  const answeredCount = items.filter((item) => isItemDone(item, answers[item.id])).length;
  const percent = total > 0 ? Math.round((answeredCount / total) * 100) : 0;
  const maxUnlocked = maxUnlockedStepIndex(items, answers);

  return (
    <div className="rounded-panel border border-carbon-700 bg-carbon-800/90 p-3.5 space-y-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-ti-100">
            ขั้นตอนที่ {currentIndex + 1} จาก {total}
          </span>
          <span className="rounded-full border border-ember-500/40 bg-ember-950/30 px-2 py-0.5 text-[10px] font-medium text-ember-300">
            ตรวจทีละขั้น ห้ามข้าม
          </span>
        </div>
        <span className="font-mono text-ti-300">
          สำเร็จ {answeredCount}/{total} ({percent}%)
        </span>
      </div>

      {/* Linear Progress Bar */}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-carbon-900">
        <div
          className="h-full rounded-full bg-gradient-to-r from-ember-500 to-pass transition-all duration-300"
          style={{ width: `${percent}%` }}
        />
      </div>

      {/* Horizontal Stepper Pills (1 - 2 - 3 - 4 - 5 - 6) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5 no-scrollbar">
        {items.map((item, idx) => {
          const answer = answers[item.id];
          const isCurrent = idx === currentIndex;
          const isLocked = idx > maxUnlocked;
          const isDone = isItemDone(item, answer);
          const isFail = answer?.status === "FAIL";
          const isNormal = answer?.status === "NORMAL";
          const hasMissingEvidence = isFail && missingEvidenceForItem(item, answer).length > 0;

          let toneClass = "border-carbon-700 bg-carbon-900 text-ti-400 hover:border-carbon-600";
          if (isCurrent) {
            toneClass =
              "border-ember-500 bg-ember-500/20 text-ti-50 font-bold ring-2 ring-ember-500/40 shadow-sm";
          } else if (isLocked) {
            toneClass =
              "border-carbon-700/60 bg-carbon-900/40 text-ti-500 opacity-60 cursor-not-allowed";
          } else if (hasMissingEvidence) {
            toneClass = "border-amber-500/70 bg-amber-950/30 text-amber-300";
          } else if (isFail) {
            toneClass = "border-fail/70 bg-fail/15 text-fail font-semibold";
          } else if (isNormal && isDone) {
            toneClass = "border-pass/70 bg-pass/15 text-pass font-semibold";
          } else if (isDone) {
            toneClass = "border-pass/60 bg-pass/10 text-pass font-semibold";
          }

          return (
            <div key={item.id} className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => onSelectIndex(idx)}
                aria-current={isCurrent ? "step" : undefined}
                aria-disabled={isLocked}
                className={`relative flex h-10 min-w-11 shrink-0 items-center justify-center gap-1 rounded-control border px-2.5 text-xs font-mono transition-all ${toneClass}`}
                title={
                  isLocked
                    ? `ล็อกอยู่ — กรุณาทำขั้นตอนที่ ${maxUnlocked + 1} ให้เสร็จก่อน`
                    : `${item.seq}. ${item.title}`
                }
              >
                <span>{item.seq}</span>
                {isLocked ? (
                  <span aria-hidden="true" className="text-[10px]">
                    🔒
                  </span>
                ) : isDone && !isCurrent ? (
                  <span aria-hidden="true" className="text-[10px]">
                    {isFail ? "!" : "✓"}
                  </span>
                ) : null}
                {hasMissingEvidence && (
                  <span
                    aria-hidden="true"
                    className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full bg-amber-400"
                  />
                )}
              </button>
              {idx < items.length - 1 && (
                <span
                  aria-hidden="true"
                  className={`h-0.5 w-2.5 rounded-full ${
                    idx < maxUnlocked ? "bg-pass/50" : "bg-carbon-700"
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

import { Suspense } from "react";
import { ModelChecklistConfiguratorView } from "@/components/master/ModelChecklistConfiguratorView";
import { requirePageAccess } from "@/lib/auth/dal";
import { canAccessPage } from "@/lib/auth/page-access";

export const metadata = {
  title: "จัดการเช็คลิสต์รายรุ่น | ข้อมูลหลัก",
};

export default function ModelChecklistsPage() {
  return (
    <Suspense fallback={<p className="p-6 text-ti-400">กำลังโหลด…</p>}>
      <ModelChecklistsContent />
    </Suspense>
  );
}

async function ModelChecklistsContent() {
  const user = await requirePageAccess("master", "/master/model-checklists");
  const canEdit =
    canAccessPage(user.roles, "master-edit") ||
    user.roles.includes("ADMIN") ||
    user.roles.includes("QC_HEAD") ||
    user.roles.includes("QA_HEAD");

  return <ModelChecklistConfiguratorView canEdit={canEdit} />;
}

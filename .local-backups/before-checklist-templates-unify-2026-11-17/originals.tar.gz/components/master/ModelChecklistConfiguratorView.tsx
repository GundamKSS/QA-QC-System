"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { CardsSkeleton } from "@/components/feedback/CardsSkeleton";
import { LoadError } from "@/components/feedback/LoadError";
import { StepMinimalAnimation } from "@/components/inspections/StepMinimalAnimation";
import { AppBack } from "@/components/ui/AppBack";
import { SearchSelect } from "@/components/ui/SearchSelect";
import { invalidateApiReads } from "@/lib/api/invalidate";
import { ANIMATION_TYPE_LABELS, inferItemAnimationType } from "@/lib/inspections/rules";
import {
  ANIMATION_TYPES,
  type AnimationType,
  type InputType,
  type InspectionRole,
  type PhotoRule,
  type VideoRule,
} from "@/lib/inspections/types";
import type {
  ChecklistTemplateSummary,
  ModelChecklistItemInput,
  ModelChecklistPayload,
} from "@/lib/master/model-checklist-types";
import { ModelChecklistHistoryDrawer } from "./ModelChecklistHistoryDrawer";
import { useModelChecklists } from "./useModelChecklists";

type Props = {
  canEdit: boolean;
  initialTemplateId?: number;
  initialModelId?: number;
  initialRole?: InspectionRole;
};

const INPUT_TYPE_OPTIONS: { value: InputType; label: string }[] = [
  { value: "PASS_FAIL", label: "ปกติ / พบปัญหา (Pass/Fail)" },
  { value: "NUMBER", label: "กรอกค่าตัวเลข (เช่น แรงดัน Bar / กระแส Amp)" },
  { value: "TEXT", label: "กรอกข้อความ / หมายเหตุ" },
];

const PHOTO_RULE_OPTIONS: { value: PhotoRule; label: string }[] = [
  { value: "ON_FAIL", label: "บังคับถ่ายเมื่อพบปัญหา (On Fail)" },
  { value: "ALWAYS", label: "บังคับถ่ายรูปทุกครั้ง (Always)" },
  { value: "NONE", label: "ถ่ายประกอบได้ ไม่บังคับ (Optional)" },
];

const VIDEO_RULE_OPTIONS: { value: VideoRule; label: string }[] = [
  { value: "NONE", label: "ไม่บังคับวิดีโอ" },
  { value: "ON_FAIL", label: "บังคับวิดีโอเมื่อพบปัญหา" },
  { value: "ALWAYS", label: "บังคับวิดีโอทุกครั้ง" },
];

export function ModelChecklistConfiguratorView({
  canEdit,
  initialTemplateId,
  initialModelId,
  initialRole = "QC",
}: Props) {
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | undefined>(
    initialTemplateId,
  );
  const [role, setRole] = useState<InspectionRole>(initialRole);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data, loading, error, reload } = useModelChecklists(
    selectedTemplateId,
    role,
    initialModelId,
  );

  const filteredTemplates = useMemo(() => {
    if (!data) return [];
    const q = searchQuery.trim().toLowerCase();
    if (!q) return data.templates;
    return data.templates.filter((t) => {
      const matchSelf =
        t.templateCode.toLowerCase().includes(q) ||
        t.templateName.toLowerCase().includes(q) ||
        (t.scope ?? "").toLowerCase().includes(q);
      const matchModel = t.linkedModels.some(
        (m) =>
          m.modelCode.toLowerCase().includes(q) ||
          (m.modelDescription ?? "").toLowerCase().includes(q),
      );
      return matchSelf || matchModel;
    });
  }, [data, searchQuery]);

  function handleSelectRole(nextRole: InspectionRole) {
    setRole(nextRole);
    setSelectedTemplateId(undefined);
    setIsCreatingNew(false);
  }

  function handleSelectTemplate(tplId: number) {
    setIsCreatingNew(false);
    setSelectedTemplateId(tplId);
  }

  function handleStartCreateNew() {
    setIsCreatingNew(true);
  }

  return (
    <div className="min-w-0 w-full space-y-6 p-4 sm:p-6 lg:p-8 2xl:p-10 max-w-full">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <AppBack href="/master">กลับไปข้อมูลหลัก</AppBack>
        <Link
          href="/master/models"
          className="inline-flex h-9 items-center gap-1.5 rounded-control border border-carbon-600 bg-carbon-800 px-3.5 text-xs font-semibold text-ti-100 hover:border-ember-500/60 hover:text-ember-300 transition-colors"
        >
          <span>ไปหน้ารุ่นปั๊ม (Master Model) เพื่อเลือก Template</span>
          <span>→</span>
        </Link>
      </div>

      {/* Header */}
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-xl sm:text-2xl 2xl:text-3xl font-bold text-ti-50">
            จัดการเทมเพลตเช็คลิสต์ (Checklist Template Builder)
          </h1>
          <p className="text-xs sm:text-sm 2xl:text-base text-ti-400">
            สร้างแม่แบบเช็คลิสต์ไว้เป็น Template 1, 2, 3… กำหนดขั้นตอนและอนิเมชั่นมินิมอล แล้วให้ Master Model เลือกใช้ผ่าน Dropdown List
          </p>
        </div>

        {/* Role Selector (QC / QA) */}
        <div className="inline-flex rounded-control border border-carbon-600 bg-carbon-800 p-1">
          {(["QC", "QA"] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => handleSelectRole(r)}
              className={`rounded px-4 py-1.5 text-xs sm:text-sm font-semibold transition-colors ${
                role === r
                  ? "bg-ember-500 text-carbon-900"
                  : "text-ti-300 hover:text-ti-100"
              }`}
            >
              Template ฝั่ง {r}
            </button>
          ))}
        </div>
      </header>

      {error && <LoadError message={error} onRetry={reload} />}

      {!data ? (
        !error && <CardsSkeleton label="กำลังโหลดรายการ Template เช็คลิสต์" />
      ) : (
        <div className="grid gap-6 lg:grid-cols-12 2xl:grid-cols-12">
          {/* Left Column: Template Selector List (Sticky on desktop) */}
          <aside className="lg:col-span-4 xl:col-span-4 2xl:col-span-3 space-y-3 lg:sticky lg:top-4 lg:self-start">
            <div className="rounded-panel border border-carbon-700 bg-carbon-800 p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm sm:text-base font-semibold text-ti-100">
                  รายการ Template ({role})
                </h2>
                <span className="text-[11px] font-mono text-ti-400">
                  {filteredTemplates.length}/{data.templates.length} ชุด
                </span>
              </div>

              {canEdit && (
                <button
                  type="button"
                  onClick={handleStartCreateNew}
                  className={`w-full h-10 rounded-control px-3 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                    isCreatingNew
                      ? "bg-ember-500 text-carbon-900 shadow-sm ring-2 ring-ember-400/50"
                      : "border border-ember-500/60 bg-ember-500/15 text-ember-300 hover:bg-ember-500 hover:text-carbon-900"
                  }`}
                >
                  <span className="text-sm font-bold">+</span>
                  <span>สร้าง Template ใหม่ (Template {data.templates.length + 1})</span>
                </button>
              )}

              {/* Search Box */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-ti-400">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ค้นหาชื่อ Template, รหัส, รุ่นปั๊ม..."
                  className="w-full pl-9 pr-8 py-2 bg-carbon-900 border border-carbon-700 rounded-control text-xs text-ti-100 placeholder:text-ti-400 focus:outline-none focus:border-ember-500 focus:ring-1 focus:ring-ember-500 transition-colors"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery("")}
                    className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-ti-400 hover:text-ti-100"
                    title="ล้างคำค้นหา"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>

              {/* Templates List */}
              {filteredTemplates.length === 0 ? (
                <div className="py-8 text-center space-y-2">
                  <p className="text-xs text-ti-400">ไม่พบ Template ที่ตรงกับคำค้นหา</p>
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery("")}
                      className="rounded bg-carbon-700 px-3 py-1 text-xs text-ti-200 hover:text-ti-50"
                    >
                      ล้างคำค้นหา
                    </button>
                  )}
                </div>
              ) : (
                <ul className="space-y-2 max-h-[55vh] sm:max-h-[62vh] lg:max-h-[calc(100vh-300px)] overflow-y-auto pr-1">
                  {filteredTemplates.map((tpl, idx) => {
                    const isSelected =
                      !isCreatingNew &&
                      tpl.templateId === (selectedTemplateId ?? data.selectedTemplateId);
                    return (
                      <li key={tpl.templateId}>
                        <button
                          type="button"
                          onClick={() => handleSelectTemplate(tpl.templateId)}
                          className={`w-full text-left rounded-control border p-3 transition-all ${
                            isSelected
                              ? "border-ember-500 bg-ember-500/15 ring-1 ring-ember-500/40"
                              : "border-carbon-700 bg-carbon-900/70 hover:border-carbon-500"
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span className="shrink-0 rounded bg-carbon-800 border border-carbon-600 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-ember-300">
                                #{idx + 1}
                              </span>
                              <span className="font-mono text-xs font-bold text-ti-50 truncate">
                                {tpl.templateCode}
                              </span>
                            </div>
                            <span className="shrink-0 rounded-full bg-carbon-700 px-2 py-0.5 font-mono text-[10px] text-ember-300">
                              v{tpl.versionNo} · {tpl.itemCount} ข้อ
                            </span>
                          </div>
                          <p className="mt-1 text-xs font-medium text-ti-100 line-clamp-1">
                            {tpl.templateName}
                          </p>
                          <div className="mt-1.5 flex flex-wrap items-center justify-between gap-2 text-[10px] text-ti-400">
                            <span>{tpl.scope ? `ขอบเขต: ${tpl.scope}` : `ฝั่ง ${tpl.role}`}</span>
                            <span
                              className={
                                tpl.linkedModels.length > 0
                                  ? "text-pass font-medium"
                                  : "text-ti-500"
                              }
                            >
                              {tpl.linkedModels.length > 0
                                ? `ใช้งาน ${tpl.linkedModels.length} รุ่น`
                                : "ยังไม่มีรุ่นเลือกใช้"}
                            </span>
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>

            {/* Workflow Explanation Box */}
            <div className="rounded-panel border border-carbon-700 bg-carbon-800/60 p-4 space-y-2 text-xs text-ti-300">
              <h3 className="font-semibold text-ti-100">
                💡 ขั้นตอนการใช้งานระบบ Template
              </h3>
              <ol className="list-decimal list-inside space-y-1 text-[11px] text-ti-400 leading-relaxed">
                <li>
                  สร้างแม่แบบไว้เป็น <strong className="text-ti-200">Template 1, 2, 3…</strong> ในหน้านี้
                </li>
                <li>
                  ไปที่เมนู <Link href="/master/models" className="text-ember-400 underline hover:text-ember-300">รุ่นปั๊ม (Master Model)</Link> แล้วเลือก Template จาก <strong className="text-ti-200">Dropdown List</strong> (หรือผูกด่วนในหน้านี้ก็ได้)
                </li>
                <li>
                  หลายรุ่นสามารถใช้ Template เดียวกันได้ เมื่ออัปเดต Template เป็นเวอร์ชันใหม่ ทุกรุ่นที่ผูกอยู่จะได้เวอร์ชันล่าสุดทันทีโดยไม่กระทบผลตรวจเก่า
                </li>
              </ol>
            </div>
          </aside>

          {/* Right Column: Template Steps Builder */}
          <div className="lg:col-span-8 xl:col-span-8 2xl:col-span-9 min-w-0">
            <TemplateChecklistEditor
              key={
                isCreatingNew
                  ? `new-${data.role}-${data.templates.length}`
                  : `tpl-${data.selectedTemplateId}-${data.role}-${data.activeVersionNo}`
              }
              data={data}
              isCreatingNew={isCreatingNew}
              canEdit={canEdit}
              loading={loading}
              onCancelCreate={() => setIsCreatingNew(false)}
              onSaved={(newTplId) => {
                setIsCreatingNew(false);
                if (newTplId) setSelectedTemplateId(newTplId);
                reload();
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

function TemplateChecklistEditor({
  data,
  isCreatingNew,
  canEdit,
  loading,
  onCancelCreate,
  onSaved,
}: {
  data: ModelChecklistPayload;
  isCreatingNew: boolean;
  canEdit: boolean;
  loading: boolean;
  onCancelCreate: () => void;
  onSaved: (savedTemplateId?: number) => void;
}) {
  const currentTemplate: ChecklistTemplateSummary | undefined = isCreatingNew
    ? undefined
    : data.templates.find((t) => t.templateId === data.selectedTemplateId) ??
      data.templates[0];

  const nextTemplateNumber = data.templates.length + 1;

  const [templateCode, setTemplateCode] = useState<string>(() =>
    isCreatingNew
      ? `TPL-${data.role}-${String(nextTemplateNumber).padStart(2, "0")}`
      : currentTemplate?.templateCode ?? `TPL-${data.role}-01`,
  );
  const [templateName, setTemplateName] = useState<string>(() =>
    isCreatingNew
      ? `Template ${nextTemplateNumber} — เช็คลิสต์มาตรฐาน (${data.role})`
      : currentTemplate?.templateName ?? "",
  );
  const [scope, setScope] = useState<string>(() =>
    isCreatingNew ? "" : currentTemplate?.scope ?? "",
  );

  const [items, setItems] = useState<ModelChecklistItemInput[]>(() => {
    const sourceItems: ModelChecklistItemInput[] = isCreatingNew
      ? data.masterPool.slice(0, 5)
      : data.items.map((it): ModelChecklistItemInput => ({
          topicCode: it.topicCode ?? `CHK-${String(it.seq).padStart(2, "0")}`,
          title: it.title,
          inputType: it.inputType,
          isRequired: it.isRequired,
          photoRule:
            it.photoRule === "ALWAYS" || it.photoRule === "NONE"
              ? it.photoRule
              : "ON_FAIL",
          videoRule: it.videoRule,
          animationType: inferItemAnimationType(it),
          helpText: it.helpText ?? null,
        }));
    return sourceItems.map((it, i) => ({
      ...it,
      topicCode: it.topicCode ?? `CHK-${String(i + 1).padStart(2, "0")}`,
    }));
  });

  const [quickModelId, setQuickModelId] = useState<string>("");
  const [isAssigningModel, setIsAssigningModel] = useState(false);

  const [previewStepIdx, setPreviewStepIdx] = useState<number | null>(0);
  const [isSaving, setIsSaving] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [saveBanner, setSaveBanner] = useState<{
    tone: "pass" | "fail";
    message: string;
  } | null>(null);

  function handleUpdateItem(index: number, patch: Partial<ModelChecklistItemInput>) {
    setItems((prev) =>
      prev.map((item, idx) => (idx === index ? { ...item, ...patch } : item)),
    );
    setSaveBanner(null);
  }

  function handleMoveItem(index: number, direction: -1 | 1) {
    const target = index + direction;
    if (target < 0 || target >= items.length) return;
    setItems((prev) => {
      const copy = [...prev];
      const [moved] = copy.splice(index, 1);
      copy.splice(target, 0, moved);
      return copy;
    });
    setPreviewStepIdx(target);
    setSaveBanner(null);
  }

  function handleRemoveItem(index: number) {
    if (items.length <= 1) {
      setSaveBanner({
        tone: "fail",
        message: "ต้องมีหัวข้อเช็คลิสต์อย่างน้อย 1 ขั้นตอนใน Template นี้",
      });
      return;
    }
    setItems((prev) => prev.filter((_, idx) => idx !== index));
    setPreviewStepIdx(null);
    setSaveBanner(null);
  }

  function handleAddFromMasterPool(poolItem: ModelChecklistItemInput) {
    setItems((prev) => [
      ...prev,
      {
        ...poolItem,
        topicCode: `CHK-${String(prev.length + 1).padStart(2, "0")}`,
      },
    ]);
    setPreviewStepIdx(items.length);
    setSaveBanner(null);
  }

  function handleAddCustomBlankItem() {
    setItems((prev) => [
      ...prev,
      {
        topicCode: `CHK-${String(prev.length + 1).padStart(2, "0")}`,
        title: "",
        inputType: "PASS_FAIL",
        isRequired: true,
        photoRule: "ON_FAIL",
        videoRule: "NONE",
        animationType: "GENERAL_CHECK",
        helpText: "",
      },
    ]);
    setPreviewStepIdx(items.length);
    setSaveBanner(null);
  }

  async function handlePublishVersion() {
    setIsSaving(true);
    setSaveBanner(null);

    try {
      const res = await fetch("/api/master/model-checklists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          isNewTemplate: isCreatingNew,
          templateId: isCreatingNew ? undefined : currentTemplate?.templateId,
          templateCode: templateCode.trim(),
          templateName: templateName.trim(),
          scope: scope.trim() || null,
          role: data.role,
          items,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        status?: string;
        message?: string;
        templateId?: number;
      };

      if (res.ok && json.status === "done") {
        setSaveBanner({
          tone: "pass",
          message:
            json.message ??
            "บันทึกและเผยแพร่เทมเพลตเช็คลิสต์เรียบร้อยแล้ว",
        });
        invalidateApiReads();
        onSaved(json.templateId);
      } else {
        setSaveBanner({
          tone: "fail",
          message: json.message ?? "ไม่สามารถบันทึกเทมเพลตเช็คลิสต์ได้ กรุณาตรวจสอบข้อมูล",
        });
      }
    } catch {
      setSaveBanner({
        tone: "fail",
        message: "เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์",
      });
    } finally {
      setIsSaving(false);
    }
  }

  async function handleAssignModelToTemplate(targetModelId: number, assignTplId: number | null) {
    setIsAssigningModel(true);
    setSaveBanner(null);
    try {
      const res = await fetch("/api/master/model-checklists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "assign_model_template",
          modelId: targetModelId,
          role: data.role,
          templateId: assignTplId,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        status?: string;
        message?: string;
      };
      if (res.ok && json.status === "done") {
        setSaveBanner({
          tone: "pass",
          message: json.message ?? "อัปเดตการผูก Template กับรุ่นปั๊มเรียบร้อยแล้ว",
        });
        setQuickModelId("");
        invalidateApiReads();
        onSaved(currentTemplate?.templateId);
      } else {
        setSaveBanner({
          tone: "fail",
          message: json.message ?? "ไม่สามารถผูก Template กับรุ่นปั๊มได้",
        });
      }
    } catch {
      setSaveBanner({
        tone: "fail",
        message: "เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์",
      });
    } finally {
      setIsAssigningModel(false);
    }
  }

  const unlinkedModels = useMemo(() => {
    if (!currentTemplate) return data.models;
    const linkedIds = new Set(currentTemplate.linkedModels.map((m) => m.modelId));
    return data.models.filter((m) => !linkedIds.has(m.modelId));
  }, [data.models, currentTemplate]);

  return (
    <div className="space-y-5" aria-busy={loading || isSaving || isAssigningModel}>
      {/* Active Template Metadata Banner */}
      <div className="rounded-panel border border-carbon-700 bg-carbon-800 p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded bg-ember-500/20 border border-ember-500/40 px-2 py-0.5 font-mono text-xs font-bold text-ember-300">
                {isCreatingNew ? "สร้าง Template ใหม่" : currentTemplate?.templateCode}
              </span>
              {!isCreatingNew && (
                <span className="rounded bg-carbon-700 px-2 py-0.5 font-mono text-xs text-ti-200">
                  เวอร์ชันปัจจุบัน v{data.activeVersionNo}
                </span>
              )}
              <span className="rounded bg-pass/15 border border-pass/30 px-2 py-0.5 font-mono text-xs text-pass">
                {items.length} ขั้นตอน
              </span>
              {!isCreatingNew && currentTemplate && (
                <button
                  type="button"
                  onClick={() => setIsHistoryOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-control border border-carbon-600 bg-carbon-700/80 hover:bg-carbon-700 hover:border-ember-500/50 px-2.5 py-1 text-xs font-semibold text-ti-200 hover:text-ti-50 transition-colors shadow-sm ml-1"
                  title="ดูประวัติการเผยแพร่แต่ละเวอร์ชันของ Template นี้ และ Audit Logs"
                >
                  <svg className="w-3.5 h-3.5 text-ember-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>ประวัติเวอร์ชัน</span>
                </button>
              )}
            </div>
            <h2 className="text-base font-semibold text-ti-50">
              {isCreatingNew
                ? `สร้างแม่แบบเช็คลิสต์ใหม่ (ฝั่ง ${data.role})`
                : currentTemplate?.templateName}
            </h2>
          </div>

          {canEdit && (
            <div className="flex items-center gap-2">
              {isCreatingNew && (
                <button
                  type="button"
                  onClick={onCancelCreate}
                  className="h-11 rounded-control border border-carbon-600 bg-carbon-900 hover:border-ti-400 px-4 text-xs sm:text-sm font-semibold text-ti-200"
                >
                  ยกเลิก
                </button>
              )}
              <button
                type="button"
                disabled={isSaving}
                onClick={handlePublishVersion}
                className="h-11 rounded-control app-primary-action bg-ember-500 hover:bg-ember-400 px-5 text-xs sm:text-sm font-semibold text-carbon-900 shadow-sm disabled:opacity-50"
              >
                {isSaving
                  ? "กำลังบันทึกและเผยแพร่..."
                  : isCreatingNew
                  ? "สร้างและเผยแพร่ Template (v1)"
                  : `บันทึกและเผยแพร่เป็น v${data.activeVersionNo + 1}`}
              </button>
            </div>
          )}
        </div>

        {/* Editable Template Code, Name, Scope */}
        <div className="grid gap-3 sm:grid-cols-12 border-t border-carbon-700/70 pt-3.5">
          <div className="sm:col-span-3 space-y-1">
            <label className="block text-[11px] text-ti-400">
              รหัส Template (Code) *
            </label>
            <input
              type="text"
              disabled={!canEdit || !isCreatingNew}
              value={templateCode}
              onChange={(e) => setTemplateCode(e.target.value)}
              placeholder="เช่น TPL-QC-01"
              className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900 px-3 font-mono text-xs sm:text-sm text-ti-50 focus:outline-none focus:ring-1 focus:ring-ember-500 disabled:opacity-60"
            />
          </div>

          <div className="sm:col-span-6 space-y-1">
            <label className="block text-[11px] text-ti-400">
              ชื่อ Template เช็คลิสต์ (แสดงใน Dropdown ของ Master Model) *
            </label>
            <input
              type="text"
              disabled={!canEdit}
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              placeholder="เช่น Template 1 — ปั๊มลมลูกสูบมาตรฐาน"
              className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900 px-3 text-xs sm:text-sm text-ti-50 focus:outline-none focus:ring-1 focus:ring-ember-500 disabled:opacity-60"
            />
          </div>

          <div className="sm:col-span-3 space-y-1">
            <label className="block text-[11px] text-ti-400">
              ขอบเขต / ประเภทปั๊ม (Scope)
            </label>
            <input
              type="text"
              disabled={!canEdit}
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              placeholder="เช่น Piston, Oil-Free, Rotary"
              className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900 px-3 text-xs sm:text-sm text-ti-50 focus:outline-none focus:ring-1 focus:ring-ember-500 disabled:opacity-60"
            />
          </div>
        </div>

        {/* Linked Master Models Section */}
        {!isCreatingNew && currentTemplate && (
          <div className="rounded-control border border-carbon-700 bg-carbon-900/60 p-3.5 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-ti-100">
                  รุ่นปั๊ม (Master Model) ที่เลือกใช้ Template นี้อยู่ ({currentTemplate.linkedModels.length} รุ่น)
                </span>
              </div>
              <Link
                href="/master/models"
                className="text-[11px] font-semibold text-ember-400 hover:text-ember-300 underline"
              >
                จัดการที่หน้า รุ่นปั๊ม (Master Model) →
              </Link>
            </div>

            {currentTemplate.linkedModels.length === 0 ? (
              <p className="text-xs text-ti-400">
                ยังไม่มีรุ่นปั๊มที่เลือกใช้ Template นี้ — สามารถเลือกผูกจาก Dropdown ด้านล่าง หรือไปเลือกที่เมนู{" "}
                <Link href="/master/models" className="text-ember-400 underline">
                  รุ่นปั๊ม (Model)
                </Link>
              </p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {currentTemplate.linkedModels.map((m) => (
                  <span
                    key={m.modelId}
                    className="inline-flex items-center gap-1.5 rounded bg-carbon-800 border border-carbon-600 px-2.5 py-1 text-xs text-ti-100"
                  >
                    <strong className="font-mono text-ember-300">{m.modelCode}</strong>
                    <span className="text-ti-400 text-[11px]">({m.brandName})</span>
                    {canEdit && (
                      <button
                        type="button"
                        disabled={isAssigningModel}
                        onClick={() => handleAssignModelToTemplate(m.modelId, null)}
                        className="ml-0.5 text-ti-400 hover:text-fail"
                        title={`ยกเลิกการผูก ${m.modelCode} กับ Template นี้`}
                      >
                        ✕
                      </button>
                    )}
                  </span>
                ))}
              </div>
            )}

            {canEdit && unlinkedModels.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <div className="min-w-56 flex-1 max-w-md">
                  <SearchSelect
                    value={quickModelId}
                    onChange={(v) => setQuickModelId(v)}
                    className="h-9 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100"
                    options={[
                      { value: "", label: "— เลือกรุ่นปั๊ม (Master Model) เพื่อผูกเข้ากับ Template นี้ —" },
                      ...unlinkedModels.map((m) => ({
                        value: String(m.modelId),
                        label: `${m.modelCode} — ${m.modelDescription ?? m.brandName} (${
                          m.templateId ? `ปัจจุบัน: ${m.templateCode}` : "ยังไม่ผูก Template"
                        })`,
                      })),
                    ]}
                  />
                </div>
                <button
                  type="button"
                  disabled={!quickModelId || isAssigningModel}
                  onClick={() =>
                    handleAssignModelToTemplate(
                      Number(quickModelId),
                      currentTemplate.templateId,
                    )
                  }
                  className="h-9 rounded-control border border-ember-500/60 bg-ember-500/20 hover:bg-ember-500 hover:text-carbon-900 px-3.5 text-xs font-semibold text-ember-300 transition-colors disabled:opacity-40"
                >
                  + ผูกรุ่นนี้เข้ากับ Template
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Feedback Banner */}
      {saveBanner && (
        <div
          role="alert"
          className={`rounded-control border p-3.5 text-xs font-medium ${
            saveBanner.tone === "pass"
              ? "border-pass/60 bg-pass/10 text-pass"
              : "border-fail/60 bg-fail/10 text-fail"
          }`}
        >
          {saveBanner.message}
        </div>
      )}

      {/* Step-by-Step Items List */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="space-y-0.5">
            <h3 className="text-sm font-semibold text-ti-100">
              ลำดับขั้นตอนการตรวจใน Template นี้ (1 → {items.length} ห้ามข้ามขั้นตอน)
            </h3>
            <p className="text-[11px] text-ti-400">
              จัดเรียงตามลำดับการตรวจจริงของช่าง QC/QA สำหรับทุกรุ่นที่เลือกใช้ Template นี้
            </p>
          </div>
          {canEdit && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsTemplateModalOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-control border border-carbon-600 bg-carbon-700/80 hover:bg-carbon-700 hover:border-ember-500/50 px-3 py-1.5 text-xs font-semibold text-ti-100 transition-colors shadow-sm"
                title="เปิดหน้าต่างเลือกข้อตรวจมาตรฐานกลาง"
              >
                <svg className="w-3.5 h-3.5 text-ember-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
                <span>ดึงจากคลังข้อตรวจมาตรฐาน ({data.masterPool.length})</span>
              </button>
            </div>
          )}
        </div>

        {items.map((item, idx) => {
          const isPreviewOpen = previewStepIdx === idx;
          return (
            <div
              key={idx}
              className="rounded-panel border border-carbon-700 bg-carbon-800 p-4 space-y-3 transition-colors hover:border-carbon-600"
            >
              {/* Step Row Header */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="inline-flex h-7 min-w-8 items-center justify-center rounded bg-ember-500/20 border border-ember-500/40 px-2 font-mono text-xs font-bold text-ember-300">
                    ขั้นตอนที่ {idx + 1}
                  </span>
                  <span className="font-mono text-xs text-ti-400">
                    {ANIMATION_TYPE_LABELS[item.animationType]}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setPreviewStepIdx(isPreviewOpen ? null : idx)}
                    className="rounded border border-carbon-600 bg-carbon-900 px-2.5 py-1 text-[11px] text-ti-200 hover:border-ember-400"
                  >
                    {isPreviewOpen ? "ซ่อนพรีวิวอนิเมชั่น" : "▶ ดูอนิเมชั่น"}
                  </button>

                  {canEdit && (
                    <>
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMoveItem(idx, -1)}
                        className="size-7 rounded border border-carbon-600 bg-carbon-900 text-xs text-ti-300 hover:text-ti-50 disabled:opacity-30"
                        title="เลื่อนขึ้น"
                      >
                        ▲
                      </button>
                      <button
                        type="button"
                        disabled={idx === items.length - 1}
                        onClick={() => handleMoveItem(idx, 1)}
                        className="size-7 rounded border border-carbon-600 bg-carbon-900 text-xs text-ti-300 hover:text-ti-50 disabled:opacity-30"
                        title="เลื่อนลง"
                      >
                        ▼
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="size-7 rounded border border-fail/40 bg-fail/10 text-xs text-fail hover:bg-fail hover:text-white"
                        title="ลบขั้นตอนนี้"
                      >
                        ✕
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Live Minimal Animation Preview */}
              {isPreviewOpen && (
                <StepMinimalAnimation
                  item={{
                    id: idx + 1,
                    seq: idx + 1,
                    topicCode: item.topicCode,
                    title: item.title || `ขั้นตอนที่ ${idx + 1}`,
                    inputType: item.inputType,
                    isRequired: item.isRequired,
                    photoRule: item.photoRule,
                    videoRule: item.videoRule,
                    animationType: item.animationType,
                    helpText: item.helpText,
                  }}
                  status={null}
                  totalSteps={items.length}
                />
              )}

              {/* Editable Fields */}
              <div className="grid gap-3 sm:grid-cols-12">
                <div className="sm:col-span-8 space-y-1">
                  <label className="block text-[11px] text-ti-400">
                    ชื่อหัวข้อตรวจ (แสดงในขั้นตอนที่ {idx + 1}) *
                  </label>
                  <input
                    type="text"
                    disabled={!canEdit}
                    value={item.title}
                    onChange={(e) => handleUpdateItem(idx, { title: e.target.value })}
                    placeholder="เช่น ตรวจสอบสภาพภายนอก ถังลม และสีเคลือบผิว"
                    className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900 px-3 text-xs sm:text-sm text-ti-50 focus:outline-none focus:ring-1 focus:ring-ember-500 disabled:opacity-60"
                  />
                </div>

                <div className="sm:col-span-4 space-y-1">
                  <label className="block text-[11px] text-ti-400">
                    อนิเมชั่นมินิมอลประจำขั้นตอน
                  </label>
                  <SearchSelect
                    disabled={!canEdit}
                    value={item.animationType}
                    onChange={(v) => handleUpdateItem(idx, { animationType: v as AnimationType })}
                    className="h-10 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100 focus:outline-none focus:ring-1 focus:ring-ember-500 disabled:opacity-60"
                    options={ANIMATION_TYPES.map((type) => ({ value: type, label: ANIMATION_TYPE_LABELS[type] }))}
                  />
                </div>

                <div className="sm:col-span-4 space-y-1">
                  <label className="block text-[11px] text-ti-400">รูปแบบการตอบผล</label>
                  <SearchSelect
                    disabled={!canEdit}
                    value={item.inputType}
                    onChange={(v) => handleUpdateItem(idx, { inputType: v as InputType })}
                    className="h-9 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100"
                    options={INPUT_TYPE_OPTIONS}
                  />
                </div>

                <div className="sm:col-span-4 space-y-1">
                  <label className="block text-[11px] text-ti-400">กติกาถ่ายรูป</label>
                  <SearchSelect
                    disabled={!canEdit}
                    value={item.photoRule}
                    onChange={(v) => handleUpdateItem(idx, { photoRule: v as PhotoRule })}
                    className="h-9 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100"
                    options={PHOTO_RULE_OPTIONS}
                  />
                </div>

                <div className="sm:col-span-4 space-y-1">
                  <label className="block text-[11px] text-ti-400">กติกาถ่ายวิดีโอ</label>
                  <SearchSelect
                    disabled={!canEdit}
                    value={item.videoRule}
                    onChange={(v) => handleUpdateItem(idx, { videoRule: v as VideoRule })}
                    className="h-9 w-full rounded-control border border-carbon-600 bg-carbon-900 px-2.5 text-xs text-ti-100"
                    options={VIDEO_RULE_OPTIONS}
                  />
                </div>

                <div className="sm:col-span-12 space-y-1">
                  <input
                    type="text"
                    disabled={!canEdit}
                    value={item.helpText ?? ""}
                    onChange={(e) =>
                      handleUpdateItem(idx, { helpText: e.target.value })
                    }
                    placeholder="คำแนะนำวิธีตรวจสำหรับขั้นตอนนี้ (เช่น ตรวจดูรอยถลอก รอยเชื่อม หรือระดับน้ำมันกึ่งกลางตาแมว)"
                    className="h-9 w-full rounded-control border border-carbon-700 bg-carbon-900/60 px-3 text-xs text-ti-200 placeholder:text-ti-500"
                  />
                </div>
              </div>
            </div>
          );
        })}

        {/* Bottom Add Step Card */}
        {canEdit && (
          <button
            type="button"
            onClick={handleAddCustomBlankItem}
            className="w-full py-3.5 px-4 rounded-panel border-2 border-dashed border-carbon-600 hover:border-ember-500/80 bg-carbon-800/40 hover:bg-carbon-800/80 text-ti-200 hover:text-ember-300 transition-all flex items-center justify-center gap-2 group font-semibold text-xs sm:text-sm shadow-sm"
          >
            <span className="w-6 h-6 rounded-full bg-carbon-700 group-hover:bg-ember-500 group-hover:text-carbon-900 flex items-center justify-center text-sm font-bold transition-colors">
              +
            </span>
            <span>สร้างขั้นตอนใหม่ต่อท้าย (ขั้นตอนที่ {items.length + 1})</span>
          </button>
        )}
      </div>

      {/* Common Master Checklist Pool Picker Modal */}
      {isTemplateModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 flex items-center justify-center"
          role="dialog"
          aria-modal="true"
          aria-labelledby="template-modal-title"
        >
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-carbon-950/80 backdrop-blur-sm transition-opacity"
            onClick={() => setIsTemplateModalOpen(false)}
            aria-hidden="true"
          />

          {/* Modal Container */}
          <div className="relative w-full max-w-2xl lg:max-w-4xl 2xl:max-w-5xl bg-carbon-850 border border-carbon-700 rounded-panel shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-carbon-700 bg-carbon-800 flex items-start justify-between gap-3">
              <div className="space-y-0.5 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="rounded bg-ember-500/20 border border-ember-500/40 px-2 py-0.5 font-mono text-xs font-bold text-ember-300">
                    Step Library
                  </span>
                  <span className="text-xs text-ti-400">
                    {data.masterPool.length} หัวข้อมาตรฐาน
                  </span>
                </div>
                <h3 id="template-modal-title" className="text-base sm:text-lg font-bold text-ti-50">
                  เลือกข้อตรวจจากคลังข้อตรวจมาตรฐานกลาง
                </h3>
                <p className="text-xs text-ti-400">
                  แตะเพื่อเพิ่มเข้า{" "}
                  <strong className="text-ti-200">{templateName || templateCode}</strong>
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsTemplateModalOpen(false)}
                className="w-9 h-9 flex items-center justify-center rounded-control hover:bg-carbon-700 text-ti-400 hover:text-ti-100 transition-colors"
                aria-label="ปิดหน้าต่างคลังข้อตรวจ"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2.5">
              <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                {data.masterPool.map((poolItem, idx) => {
                  const alreadyInList = items.some((it) => it.title === poolItem.title);
                  return (
                    <div
                      key={idx}
                      className={`flex flex-col justify-between gap-2.5 rounded-control border p-3 transition-colors ${
                        alreadyInList
                          ? "border-carbon-700 bg-carbon-900/50"
                          : "border-carbon-700/80 bg-carbon-900/90 hover:border-carbon-600"
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          {poolItem.topicCode && (
                            <span className="font-mono text-[10px] text-ember-400 bg-carbon-800 px-1.5 py-0.5 rounded border border-carbon-700">
                              {poolItem.topicCode}
                            </span>
                          )}
                          <span className="font-mono text-[10px] text-ti-400">
                            {ANIMATION_TYPE_LABELS[poolItem.animationType]}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-ti-100 line-clamp-2">
                          {poolItem.title}
                        </p>
                        {poolItem.helpText && (
                          <p className="text-[11px] text-ti-400 line-clamp-2">
                            {poolItem.helpText}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-carbon-800/80">
                        <span className="text-[10px] text-ti-400 font-mono">
                          {poolItem.inputType} · รูป: {poolItem.photoRule}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleAddFromMasterPool(poolItem)}
                          className={`rounded px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                            alreadyInList
                              ? "border border-carbon-600 bg-carbon-800 text-ti-300 hover:border-ember-400"
                              : "border border-ember-500/60 bg-ember-500/20 text-ember-300 hover:bg-ember-500 hover:text-carbon-900"
                          }`}
                        >
                          {alreadyInList ? "+ เพิ่มซ้ำ" : "+ เพิ่มเข้า Template"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-carbon-700 bg-carbon-800/90 flex items-center justify-between">
              <span className="text-xs text-ti-400">
                ปัจจุบันมี {items.length} ขั้นตอนใน Template นี้
              </span>
              <button
                type="button"
                onClick={() => setIsTemplateModalOpen(false)}
                className="h-9 px-4 rounded-control border border-carbon-600 bg-carbon-700 hover:bg-carbon-600 text-xs font-semibold text-ti-100 transition-colors"
              >
                เสร็จสิ้น
              </button>
            </div>
          </div>
        </div>
      )}

      {/* History and Audit Log Drawer */}
      {!isCreatingNew && currentTemplate && (
        <ModelChecklistHistoryDrawer
          isOpen={isHistoryOpen}
          onClose={() => setIsHistoryOpen(false)}
          templateId={currentTemplate.templateId}
          role={data.role}
          modelCode={currentTemplate.templateCode}
          modelDescription={currentTemplate.templateName}
          currentVersionNo={data.activeVersionNo}
        />
      )}
    </div>
  );
}

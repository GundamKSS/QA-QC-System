# 19 — แผนย้ายการเขียนข้อมูลจาก Server Actions ไปเป็น API routes (`app/api/...`)

> 26 ต.ค. 2026 · ผู้ใช้ขอให้โครงเหมือนโปรเจกต์ log-book (ทุกอย่างที่ต่อ DB อยู่ใน `app/api/<ฟีเจอร์>/<ย่อย>/route.ts`) และ OK แผนนี้ → **ครบทุกขั้น (0–7) แล้ว** (ทดสอบด้วยเทสต์, ยิงจริงทุก endpoint และลองในเบราว์เซอร์โหมดสาธิต — ดู §8; **ยังไม่ได้ลองกับ SQL Server/ระบบกลางจริง**) · ทำทีละขั้น หยุดรอผู้ใช้ confirm ก่อนทุกขั้น
> สำรองก่อนเริ่ม: `.local-backups/before-api-routes-2026-10-26/originals.tar.gz` (โปรเจกต์นี้ไม่มี git)
> ต่อมา 26 ต.ค. 2026: ผู้ใช้สั่งให้ย้ายหน้าเดิมที่อ่านผ่าน `lib/` ไปอ่านผ่าน `GET /api` **ทีละหน้า กด confirm ก่อนทุกหน้า** — ลำดับและความคืบหน้าอยู่ใน **§9** (ทำแล้ว: `/jobs`, `/history`, `/master`)

## 1. หลักการ

1. **`lib/` ไม่แตะ** — route แต่ละตัวเป็นตัวห่อบาง ๆ ที่เรียก service เดิม (`openPlan`, `createMaster`, `changeOwnPin` …) กติกาธุรกิจ audit SQL และเทสต์เดิมใช้ต่อ
2. **ตัวช่วยกลาง `lib/api/`** เขียนครั้งเดียว: ตรวจ same-origin + session + สิทธิ์ตามหน้า, อ่าน body, ตอบ JSON, แปลง DB error
3. **ฟอร์มแก้น้อย** — ยังใช้ `<form action>` กับ `useActionState` (ผ่าน `useApiAction`) จึงได้ปุ่ม pending และการล้างช่องหลังตอบเหมือนเดิม; รูปแบบ state (`error` / `fieldErrors` / `at` …) คงเดิม ข้อความที่ผู้ใช้เห็นไม่เปลี่ยน
4. **หลังบันทึก** route ส่ง `redirectTo` ให้เบราว์เซอร์พาไปหน้าที่ action เดิมเคย `redirect()` ไป; ถ้าอยู่หน้าเดิมจะ `router.refresh()` (`revalidatePath` ใน route ไม่ล้าง router cache ฝั่งเบราว์เซอร์เอง)
5. **การอ่าน** หน้าที่ย้ายแล้ว (§9) ให้ client component อ่านผ่าน `GET /api/<ฟีเจอร์>` (`useApiRead`) ตามแบบ log-book — `page.tsx` เหลือแค่ด่านสิทธิ์ที่ server · หน้าที่ยังไม่ย้ายยังอ่านผ่าน `lib/` ตรง ๆ ใน server component (ไม่ยิง API ของตัวเอง) จนกว่าจะถึงคิว

## 2. สัญญา API

| เรื่อง | กติกา |
|---|---|
| Body เข้า | JSON (ฟอร์มส่งเป็น JSON — ช่องชื่อซ้ำเป็น array) หรือ form ธรรมดา (`urlencoded` / `multipart`) ก็อ่านได้ → ทดสอบด้วย Postman/curl ได้ body ที่อ่านไม่ออกถือเป็นช่องว่าง ให้กติกา "ต้องกรอก" ตอบเอง |
| Body ออก | JSON ที่มี `status` เสมอ: `done` / `error` / สถานะเฉพาะฟอร์ม (เช่น `duplicate`) — ตรงกับ state ที่หน้าจอเดิมใช้; `error` มี `message` ภาษาไทยพร้อมแสดง; อาจมี `redirectTo` (เฉพาะ path ในเว็บเรา) |
| Body ออกของ `GET` (อ่านข้อมูล) | ข้อมูลตรง ๆ ไม่ห่อ `status` (`apiData`) เหมือน log-book · ล้มเหลวใช้รูป `{ status: "error", message, redirectTo? }` เหมือนฝั่งเขียน ฝั่งเบราว์เซอร์แยกสำเร็จ/ล้มเหลวด้วย HTTP status (`readApi`) · `GET` ไม่ตรวจ same-origin (ไม่เปลี่ยนข้อมูล) แต่ตรวจ session และสิทธิ์ตามหน้าเหมือนกัน |
| Header ออก | `Cache-Control: private, no-store` + `Vary: Cookie` ทุกคำตอบ |
| ไม่ได้ล็อกอิน | `401` + `redirectTo: /login?next=…` (ไม่ redirect เอง) |
| ค้างเปลี่ยน PIN | `403` + `redirectTo: /change-password` (ยกเว้น endpoint เปลี่ยน PIN เอง) |
| ไม่มีสิทธิ์ตามหน้า | `403` (ใช้ตาราง `PAGE_ACCESS` ตัวเดียวกับเมนูและหน้า) |
| ส่งข้ามเว็บ | `403` สำหรับ POST/PUT/PATCH/DELETE ที่ไม่ใช่ same-origin (แทนการตรวจ CSRF ที่ Server Actions เคยทำให้) |
| ข้อมูลผิดที่แก้ได้ | `422` (เช่น PIN รูปแบบผิด) · ไม่พบ `404` · ล็อก `423` · ซ้ำ/สถานะเปลี่ยน `409` |
| DB ล่ม | `503` + ข้อความเดิมจาก `dbProblemMessages` (ไม่โชว์ error ดิบ) |
| บั๊กจริง | โยนต่อเป็น `500` (ไม่กลืน) |

## 3. แผนที่ API และสถานะ

| ขั้น | Method และ path | แทน action เดิม | สถานะ |
|---|---|---|---|
| 1 | `POST /api/auth/change-pin` | `changePinAction` | ✅ |
| 2 | `POST /api/admin/users` (201) · `PATCH /api/admin/users/[id]` · `POST …/[id]/reset-pin` · `…/unlock-pin` · `…/active` | `create/update/resetPin/unlockPin/setActive` | ✅ |
| 3 | `POST /api/master/[table]` (201) · `PATCH /api/master/[table]/[id]` · `POST …/[id]/active` | `saveMasterAction` (สร้าง/แก้), `setMasterActiveAction` | ✅ |
| 4 | `POST /api/plans` (201) · `GET /api/plans/lookup-doc` · `POST /api/plans/[id]/cancel` · `…/waiting-goods` · `PATCH …/vendor` | `openPlanAction`, `lookupReceiptDocAction`, `cancelPlanAction`, `setWaitingGoodsAction`, `setPlanVendorAction` | ✅ |
| 5 | `POST /api/plans/[id]/work-orders` (201) · `PUT …/work-orders/[woId]/assignees` · `POST …/[woId]/cancel` | `openWorkOrderAction`, `setWorkOrderAssigneesAction`, `cancelWorkOrderAction` | ✅ (ลบ `plans/actions.ts` ทั้งไฟล์แล้ว) |
| 6 | `POST /api/auth/login` · `POST /api/auth/logout` (ย้ายจาก `/auth/logout`) | `login`, route ออกจากระบบเดิม | ✅ เลือกทาง A (รอ hydrate) — ดู §6 · ลบ `login/actions.ts` แล้ว: **ไม่เหลือ Server Action ในโปรเจกต์** |
| 7 | เก็บกวาด: README/docs/คอมเมนต์ให้ตรงกับของจริง, ตรวจลิงก์เอกสาร, ตรวจรวมสุดท้าย (§8) | | ✅ |

`/api/notifications` (GET) มีอยู่ก่อนแล้ว คงเดิม · ขั้น 0 = โครงกลาง `lib/api/` (✅)

**ฝั่งอ่าน (§9):** `GET /api/jobs` ✅ · `GET /api/history` ✅ · `GET /api/master` ✅ (3/10) — endpoint อ่านที่เหลือและลำดับอยู่ในตารางของ §9

## 4. ตัวช่วยกลาง `lib/api/`

| ไฟล์ | หน้าที่ |
|---|---|
| `guard.ts` | `guardApi(request, { page?, returnTo?, allowPasswordChange? })` → `{ user }` หรือ `{ response }` (ด่านแรกของทุก route) |
| `body.ts` | `readFields(request)` → `get` / `text` / `all` อ่านได้ทั้ง JSON และ form (ตัวแยกฟอร์มเดิมที่รับ `get(key)` ใช้ต่อได้เลย) |
| `response.ts` | `apiJson(body, status)` · `apiError(status, message, extra?)` · `apiData(body)` (คำตอบของ `GET`: ข้อมูลตรง ๆ) + header ไม่ cache |
| `db.ts` | `dbFailure(error, label)` ใน `catch` ของ route ที่แตะ DB: DB error → 503, อย่างอื่นโยนต่อ |
| `messages.ts` | ข้อความไทยกลาง (ไม่มีสิทธิ์ เซสชันหมด เครือข่ายล่ม ฯลฯ) |
| `call.ts` | `callApi(url, method, formData, failed)` ฝั่งเบราว์เซอร์: ส่งฟอร์มเป็น JSON, แยก `redirectTo` (ตัดที่ออกนอกเว็บทิ้ง) และ `refresh` ออกจาก state, ถ้าเครือข่ายล่ม/ตอบไม่ใช่ JSON ให้ใช้ error state ของหน้านั้น (ส่งฟอร์มที่ผู้ใช้พิมพ์ให้ด้วย จะได้เก็บค่าไว้) |
| `client.ts` | `useApiAction(url, initial, failed, method?)` แทน `useActionState(serverAction, initial)` · `useApiCall(url, failed)` สำหรับปุ่มที่ไม่ใช่ฟอร์ม (ช่องติ๊ก) — ทั้งคู่คง `pending` ไว้จนกว่าหน้าจะรีเฟรช/เปลี่ยนหน้าเสร็จ · `useApiRead<T>(url)` สำหรับหน้าที่อ่านข้อมูล → `{ data, loading, error, reload }`: ยิงตอน mount และเมื่อ `url` เปลี่ยนหรือสั่ง `reload()`, คงข้อมูลเดิมไว้ระหว่างโหลดใหม่, ยกเลิกคำขอที่ถูกคำขอใหม่แทนที่, 401 พาไปหน้า login ตาม `redirectTo` |
| `read.ts` | `readApi(url, { signal? })` ฝั่งเบราว์เซอร์: `GET` แล้วคืน `{ ok: true, data }` หรือ `{ ok: false, message, redirectTo }` ไม่ throw (เครือข่ายล่ม/ตอบไม่ใช่ JSON ใช้ข้อความกลางใน `messages.ts`, ตัด `redirectTo` ที่ออกนอกเว็บทิ้ง) + `settleRead`/`readView` ตรรกะ "คงข้อมูลเดิมไว้ระหว่างโหลดใหม่" ที่ `useApiRead` ใช้ (แยกไว้ให้เทสต์ได้) |
| `query.ts` | `readQuery(request)` ฝั่ง server: แอดเดรสของคำขอ → ออบเจ็กต์รูปเดียวกับ `searchParams` ของหน้า (ชื่อเดียว = string, ชื่อซ้ำ = array) เพื่อให้ route `GET` ใช้ parser ตัวเดียวกับหน้าที่มันแทน เช่น `parseHistoryQuery` |
| `lib/plans/api.ts` | ของกลางของ route แผน: `actorIdOf` (users.id สำหรับคอลัมน์ผู้ทำ), `planIdOf`, `revalidatePlan`, ข้อความ `CANCEL_MESSAGES` + `CANCEL_STATUS`, `NO_ACCOUNT` |
| `lib/plans/state.ts` | ชนิด state ของฟอร์มแผนและใบงาน (`OpenPlanFormState`, `PlanActionState`, `WorkOrderFormState`, `WorkOrderFormValues`) ที่เคยอยู่ใน `actions.ts` |
| `lib/plans/lookup-client.ts` | ฝั่งเบราว์เซอร์ของ `GET /api/plans/lookup-doc` (ไม่ throw: ล้มเหลวทุกแบบเป็น `{ kind: "error", message }` ให้กล่องสถานะเอกสาร) |
| `lib/plans/jobs.ts` | ของ `GET /api/jobs`: `loadJobs(user, view)` (งานที่กำลังทำก่อน แล้วงานที่จบล่าสุด ไม่ซ้ำ), `jobsView(roles, requested)` (หัวหน้า QC เห็นทั้งหมดถ้าไม่ขอ `mine`; คนอื่นเห็นของตัวเองเสมอ), ชนิด `JobsPayload`/`JobItem` (ส่งเฉพาะฟิลด์ที่หน้าวาด) — มี `import "server-only"` ฝั่ง client ใช้ได้เฉพาะ `import type` |
| `lib/plans/history.ts` | ของ `GET /api/history`: `loadHistory(user, query)` (หนึ่งหน้าของประวัติ อ่านตัวกรองด้วย `parseHistoryQuery`), `isHistoryHead(roles)` (QC Head/QA Head เห็นทุกคนและเปิดแผนจากการ์ดได้), ชนิด `HistoryPayload`/`HistoryItem` (มี `cancelReason`; ไม่มี `description` `remarks` `planNo` `createdAt` รหัสพนักงาน) — ฝั่ง client ใช้ได้เฉพาะ `import type` |
| `lib/master/counts.ts` | ของ `GET /api/master`: `loadMasterCounts()` นับแถวของทุกตารางใน registry ให้การ์ดของ `/master` → `{ kind: "counted", payload: { counts: { <slug>: { total, active } } } }` หรือ `{ kind: "no_database" }` (โหมดสาธิตไม่มี SQL Server) · `MASTER_NO_DATABASE` ข้อความของกรณีหลัง — ฝั่ง client ใช้ได้เฉพาะ `import type` |
| `lib/master/api.ts` | ของกลางของ route ข้อมูลหลัก: `masterContext` (ด่าน `master-edit` + หา table จาก registry; ยังไม่ล็อกอินได้ 401 ก่อนเสมอ จึงเดาชื่อ table ไม่ได้), `rowIdOf`, `masterWriteFailure` (ซ้ำ `409` · ผิดเงื่อนไข DB `422` · DB ล่ม `503` พร้อมค่าที่พิมพ์) |
| `lib/auth/admin-api.ts` | ของกลางของ route จัดการผู้ใช้ (และ PIN): `adminContext` (ด่าน `users` + pepper + store), `adminFailure(error)` แปลง `AdminError` เป็นข้อความไทย + status (`422` แก้แล้วส่งใหม่ได้ · `403` · `404` · `423` ล็อก), `profileFields`, `userIdOf` |

## 5. สูตรเพิ่ม endpoint (ใช้ทุกขั้นถัดไป)

```ts
// app/api/plans/route.ts
export async function POST(request: Request) {
  const guard = await guardApi(request, { page: "plan-open", returnTo: "/plans/new" });
  if ("response" in guard) return guard.response;
  const fields = await readFields(request);
  try {
    // … เรียก service ใน lib/ แล้ว audit เหมือนเดิม …
    return apiJson({ status: "done", redirectTo: "/plans/new?opened=12" });
  } catch (error) {
    return dbFailure(error, "open plan");
  }
}
```

ฟอร์ม: `const [state, action, pending] = useApiAction("/api/plans", idle, failed);` — `failed(message)` สร้าง error state ของฟอร์มนั้นเอง (ใช้เมื่อเครือข่ายล่มหรือตอบไม่ใช่ JSON) · ชนิดของ state ย้ายจาก `actions.ts` ไปไว้ที่ `lib/<โมดูล>/` ข้างบริการที่ใช้

## 6. สิ่งที่ต่างจากเดิม / ความเสี่ยง

- **ฟอร์มต้องรอหน้า hydrate ก่อน** — Server Action เดิมส่งฟอร์มได้แม้ JavaScript ยังไม่ทำงาน; แบบ `fetch` ไม่ได้ (React กันไม่ให้ฟอร์มถูกส่งแบบเปล่า ๆ: ตัวฟอร์มมี `action="javascript:throw …"` จึงไม่ส่งและไม่มีรหัสผ่านต่อท้าย URL)
- **ตัดสินใจ login (ขั้น 6): ทาง A — รอ hydrate + กันกดเร็วเกินไป** เทียบกับทาง B (route รับ form POST ธรรมดาตอบ `303`, ส่งสถานะผ่าน URL) และทาง C (คง Server Action): JS ที่ต้องโหลดเพื่อ hydrate `/login` ~184 KB gzip (framework ~168 + หน้า ~16) ส่วนฉาก 3D ~279 KB โหลดทีหลังตอนเบราว์เซอร์ว่าง ไม่ขวางฟอร์ม (ค่าประมาณจากไฟล์ build ยังไม่ได้วัดบนมือถือจริง) · หลังขั้น 1–5 ทุกการเขียนในแอปต้องใช้ JS อยู่แล้ว ประโยชน์ของ login ที่ไม่ต้องใช้ JS จึงน้อย แต่ทาง B เพิ่มพื้นผิวเสี่ยงที่ endpoint ละเอียดอ่อนสุด
  - ปุ่มเข้าสู่ระบบ `disabled` + "กำลังเตรียม…" จนหน้าพร้อม (ปุ่มหลักที่ปิดกัน Enter ส่งก่อนเวลา) · ข้อความที่พิมพ์ระหว่างรอไม่หาย (React ไม่เขียนทับ `value` ตอน hydrate — ดู `initInput` ใน react-dom) · `<noscript>` บอกให้เปิด JavaScript · แก้คำอธิบายใน docs/07 §9 แล้ว
  - **ตัด Referer fallback ของ `next` ออก**: เดิมมีไว้ให้การส่งก่อน hydrate (ช่อง `next` ยังว่าง) ย้อนไปอ่าน `?next=` จากหน้าเดิม ตอนนี้ฟอร์มส่งได้หลัง hydrate เท่านั้น ช่อง `next` จึงมีค่าเสมอ
  - **สถานะใหม่ `unreachable`** (สร้างโดยฟอร์มเอง ไม่ใช่เซิร์ฟเวอร์): เครือข่ายหลุด/เซิร์ฟเวอร์รีสตาร์ท/ได้หน้า crash กลับมา → แสดง "เชื่อมต่อเซิร์ฟเวอร์ไม่สำเร็จ ลองใหม่อีกครั้ง" ในฟอร์มแทนหน้า error เต็มจอ (เก็บรหัสพนักงานที่พิมพ์ไว้) · `login/error.tsx` เหลือเป็นตาข่ายสุดท้ายตอนหน้า login พังตอน render
  - สถานะ HTTP: ผิด `401` · ช่องว่าง/รหัสผ่านยาวเกิน `422` · ล็อก/PIN ล็อก `423` · ปิดใช้งาน/ไม่มีสิทธิ์/ส่งข้ามเว็บ `403` · ระบบกลางล่ม `503` · `busy` (ยิงขนานเป็นสคริปต์) ตอบเหมือน "ผิด" ทุกประการ (`401`) ผู้โจมตีจึงแยกไม่ออก · สำเร็จตอบ `status: "success"` + `next` **ไม่ใช้ `redirectTo`** เพราะฟอร์มต้องเล่นอนิเมชันต้อนรับก่อนแล้ว `window.location.replace(next)` (โหลดทั้งหน้าเพื่อล้างข้อมูลผู้ใช้คนก่อนบนเครื่องส่วนกลาง) เหมือนเดิม
  - ขนาด body จำกัด 16 KB ที่ login (Server Action เดิมถูก Next จำกัด 1 MB ให้เอง) และ `readFields` มีเพดานเริ่มต้น 1 MB กับทุก route (ดู Content-Length ที่ประกาศ — proxy ยังต้องจำกัด chunked upload เอง)
  - `/api` ถูกเพิ่มใน `authOnlyPaths` กัน `?next=/api/...` กลายเป็นหน้าปลายทางหลัง login
- **เปลี่ยน PIN ตอนนี้จับ DB ล่มเป็นข้อความได้** (เดิม action ไม่ดัก ทำให้หน้าพัง) — เป็นการปรับปรุงเล็ก ๆ ที่มากับการย้าย
- **`id` ของผู้ใช้ย้ายจากช่องซ่อนในฟอร์มไปอยู่ใน path** (`/api/admin/users/[id]/…`) และรับเฉพาะ `[A-Za-z0-9_-]` ยาวไม่เกิน 40 ตัว ไม่ตรงตอบ `404` · `active` รับ `"1"` หรือ `"true"` เพื่อเปิด ค่าอื่นคือปิด (ค่าเริ่มต้นปลอดภัย)
- **ข้อมูลหลัก:** `slug` และ `id` ย้ายจากช่องซ่อนในฟอร์มไปอยู่ใน path (`/api/master/brands/3`) · ฟอร์มสร้าง/แก้ยังได้ค่าที่พิมพ์คืนเมื่อถูกปฏิเสธ (`values` + `at`) และเมื่อเครือข่ายล่มก็อ่านค่าที่พิมพ์กลับจากฟอร์มที่ส่ง (`failed(message, formData)`) · บันทึกสำเร็จตอบ `redirectTo: /master/<slug>?saved=<id>` เหมือน `redirect()` เดิม · `active` ตีความเหมือนผู้ใช้หน้างาน
- **แผน:** `planId` ย้ายจากช่องซ่อนไปอยู่ใน path · เปิดแผนซ้ำ Invoice/PO + Model (BR-01) ตอบ `409` พร้อม `status: "duplicate"`, `planId`, `planNo` (ฟอร์มยังโชว์ลิงก์ไปแผนเดิม) · ยกเลิกแผนถูกปฏิเสธ: ไม่พบ `404` · ต้องกรอกเหตุผล/ยาวเกิน `422` · สถานะเปลี่ยน/ยกเลิกไม่ได้ในสถานะนี้ `409` · มีผลตรวจแล้วต้องให้ Head `403` · Vendor ไม่มี/ปิดใช้งาน `422`, แผนถูกยกเลิก `409`
- **`GET /api/plans/lookup-doc`** ตอบ `{ status: "done", result: DocLookup }` (ห่อไว้เพื่อให้ทุกคำตอบมี `status`) · DB ล่มเป็น `503` แทน `{kind:"error"}` เดิม ฝั่งเบราว์เซอร์แปลงกลับเอง
- **ช่อง "รอของ"** แสดงค่าใหม่ทันทีที่ติ๊กและคงไว้จนหน้ารีเฟรชเสร็จ ถ้าเซิร์ฟเวอร์ปฏิเสธจะกลับเป็นค่าเดิมพร้อมข้อความ · ปุ่มในทุกฟอร์มยังถูกล็อกจนกว่าหน้าใหม่จะแสดง (ก่อนหน้านี้ขั้น 1–3 รีเฟรชแต่ไม่ล็อกปุ่ม)
- **ใบงาน:** `planId` และ `woId` ย้ายจากช่องซ่อนไปอยู่ใน path · ผู้ตรวจยังส่งเป็นช่อง `assignee1…assignee5` ตามลำดับช่อง (ตัวเลือกลากวางไม่เปลี่ยน) · ใบงานใน path เป็นตัวตัดสินว่าแก้ใบงานไหน (เหมือนเดิม) ส่วนแผนใน path ใช้เป็นที่กลับไปหลังล็อกอินและตรวจสิทธิ์ · เปิดใบงานสำเร็จตอบ `redirectTo: /plans/<id>?tab=work&opened=<woNo>`
- **คำตอบมี `refresh: true` ได้** (เพิ่มในขั้น 5): ใช้เมื่อถูกปฏิเสธเพราะข้อมูลที่หน้าแสดงอยู่เก่าไปแล้ว — กรณีเดียวตอนนี้คือเปิดใบงานแล้วพบว่ามีผู้ตรวจถูกปิดใช้งานระหว่างนั้น (`unavailable`) เบราว์เซอร์จะโหลดหน้าใหม่ให้รายชื่อตัดคนนั้นออก (Server Action เดิมทำสิ่งนี้ผ่าน `revalidatePath` ซึ่ง route ทำแทนไม่ได้)
- **ผู้ตรวจที่ถูกปิดใช้งาน:** เปิดใบงาน `422` + `unavailable` + `refresh` · เปลี่ยนผู้ตรวจ `422` (เหมือนเดิม ไม่รีเฟรชอัตโนมัติ) · ใบงานล็อก (ส่งแล้ว/ปิด/ยกเลิก/มีผลตรวจแล้ว) `409`
- **PIN ชั่วคราวอยู่ในคำตอบครั้งเดียว** (`no-store`) ไม่เข้า audit/log — มีเทสต์ยืนยันทุก route ที่ออก PIN
- **ใช้ DB ตัวเดียวกับของเดิม** ไม่มีการเปลี่ยน schema ใด ๆ ในแผนนี้
- **ออกจากระบบย้ายเป็น `/api/auth/logout`** ตรรกะเหมือนเดิมทุกอย่าง (ฟอร์ม POST ธรรมดา ตอบ `303` ไป `/login` แบบ relative ไม่ต้องใช้ JS) แก้ `authPolicy.logoutPath` (ปุ่ม `SignOutButton` อ่านจากที่นี่) · ไม่มี Server Action เหลืออยู่ในโปรเจกต์แล้ว

## 7. การตรวจ

ทุกขั้นต้องผ่าน typecheck, lint, vitest และ `next build` · เทสต์ของ `lib/api/*` ครอบคลุม guard, body, response, DB error, ฝั่งเบราว์เซอร์ (`callApi`) · แต่ละกลุ่ม route มีไฟล์ `tests/api-*.test.ts` ของตัวเอง (ไม่ล็อกอิน / ข้ามเว็บ / ไม่มีสิทธิ์ / ข้อมูลผิด / DB ล่ม / สำเร็จ + audit)

**ลองมือขั้น 1** (ต้องใช้ผู้ใช้หน้างาน LOCAL ที่ถูกสร้างหรือรีเซ็ต PIN ไว้): เข้าด้วย PIN ชั่วคราวจนถึง `/change-password` → กรอก PIN ปัจจุบัน/ใหม่/ยืนยัน แล้วกดบันทึก ควรไป `/home` · ทดสอบกรณีผิด: PIN ปัจจุบันผิด, PIN ใหม่สองช่องไม่ตรง, PIN ใหม่ซ้ำเดิม, PIN ง่ายเกินไป (111111) ควรเห็นข้อความสีแดงเดิมและช่องถูกล้าง

**ตรวจขั้น 6 ในเบราว์เซอร์แล้ว (26 ต.ค. 2026)** ด้วยสำเนาโปรเจกต์ที่แยกต่างหาก (ไม่มี `.env.local` และไม่ต่อ DB) รันโหมดบัญชีสาธิต `QCHECK_AUTH=mock DB_SERVER=` — ผ่านทั้งหมด: HTML ก่อน JS (ปุ่ม `disabled` เขียน "กำลังเตรียม…", มี `<noscript>`, ไม่มีช่อง `enhanced`, `action="javascript:throw …"`) · เข้าสู่ระบบสำเร็จ (อนิเมชันต้อนรับแล้วไป `/home`) · รหัสผิด `401` พร้อมข้อความและโฟกัสช่องรหัสผ่าน · ผิด 5 ครั้งได้ `423` + นับถอยหลัง "ลองใหม่ได้ในอีก 14:59" · เครือข่ายหลุด (จำลองให้ `fetch` ล้มเหลว) ได้ข้อความในฟอร์มและรหัสพนักงานยังอยู่ · `?next=/more` ไปถูกหน้า, `?next=//evil.example` ถูกตีเป็น `/home` · ออกจากระบบแล้วเข้า `/home` ถูกส่งกลับ `/login?next=%2Fhome` · body ผิดรูป/ว่าง `422` ไม่มีการเรียกระบบกลาง

**ที่ยังต้องให้คนลองกด (เพราะต้องใช้บัญชีจริง):** เข้าด้วยบัญชีระบบกลางจริง (ตรวจว่า `syncUserOnLogin` เขียน DB ได้) · ผู้ใช้หน้างาน F-code + PIN ที่ค้างเปลี่ยน PIN ต้องถูกพาไป `/change-password` · มือถือจริงบน Wi-Fi โรงงาน (ช่วงที่ปุ่ม "กำลังเตรียม…" ค้างนานแค่ไหน) · password manager (Keychain/Chrome) ยังเสนอบันทึกรหัสผ่านหลังเข้าสำเร็จ

## 8. สรุปผลรวม (ขั้น 7 — จบแผน 26 ต.ค. 2026)

**ผลลัพธ์**
- ย้าย **19 endpoints** จาก Server Actions เป็น route handlers + `/api/notifications` ที่มีอยู่เดิม = **20 ไฟล์ `route.ts`** ใน `app/api/` · **ไม่เหลือ Server Action ในโปรเจกต์** (ค้น `"use server"` แล้วไม่พบ)
- `lib/` ส่วนกติกาธุรกิจ/SQL/audit ไม่ถูกแก้ — เพิ่มเฉพาะตัวช่วย: `lib/api/` · `lib/plans/{api,state,lookup-client}.ts` · `lib/master/api.ts` · `lib/auth/admin-api.ts` และชนิด state ที่ย้ายมาจาก `actions.ts`
- เทสต์ 456 → **858** (เพิ่มราว 400 ตัวของ API: ไม่ล็อกอิน · ข้ามเว็บ · สิทธิ์ · ข้อมูลผิด · DB ล่ม · audit · ไม่มีความลับรั่วใน audit/คำตอบ) · lint, `tsc`, `next build` ผ่าน · ลิงก์เอกสารสัมพัทธ์ทั้ง 22 ไฟล์ไม่เสีย (แก้ 2 ลิงก์ wireframe ที่เสียตอนย้ายโฟลเดอร์)
- ยิงจริงทุก handler (20 ตัว) บน dev server: ไม่ล็อกอิน `401` (login `422` เพราะส่งช่องว่าง, logout `303`) · ข้ามเว็บ `403` · method ที่ไม่รองรับ `405` ผ่านครบ

**ตรวจในเบราว์เซอร์ (โหมดสาธิต: สำเนาโปรเจกต์ที่ไม่มี `.env.local`/DB, `QCHECK_AUTH=mock`, store ในหน่วยความจำ)** — ผ่าน: login/logout · เปิดแผน (`201`) + ตรวจเอกสารตอนออกจากช่อง + แผนซ้ำ `409` + ข้อมูลผิด `422` · ติ๊ก "รอของ" (ค่าใหม่ขึ้นทันที ช่องล็อกจนหน้ารีเฟรชเสร็จ ค่าคงอยู่หลังโหลดใหม่) · แก้ Vendor (กล่องปิดเอง ชื่อใหม่ขึ้น) · เปิดใบงาน (ไปแท็บใบงานพร้อมแถบแจ้ง) · แก้ผู้ตรวจ (กล่องปิดเอง) · ยกเลิกใบงาน (ยอดเรียกเข้าคืนล็อต) · ยกเลิกแผน (หน้าเปลี่ยนเป็น "ยกเลิก" พร้อมเหตุผล) · สร้างผู้ใช้หน้างาน (PIN ชั่วคราวแสดงครั้งเดียว รายการอัปเดต) · ออก PIN ใหม่ · ปิด/เปิดใช้งาน · แก้ไขข้อมูล/บทบาท · ผู้ใช้หน้างานเข้าด้วย PIN ชั่วคราว → ถูกพาไป `/change-password` → ปฏิเสธ 3 แบบ (PIN เดิมผิด `403`, สองช่องไม่ตรง `422`, PIN อ่อน `422`) → สำเร็จ `200` ไป `/home` · PIN ผิด 5 ครั้งล็อก `423` → Admin ปลดล็อก `200` · audit ฝั่งเซิร์ฟเวอร์ครบทุกการกระทำและไม่มี PIN

**ยังไม่ได้ตรวจกับของจริง (ต้องใช้ระบบจริง)**
1. **Master data** ทั้ง 3 endpoints — หน้านี้ต้องใช้ SQL Server จริง (โหมดสาธิตไม่มี) ครอบคลุมด้วยเทสต์เท่านั้น
2. การเขียน SQL Server จริงของทุกฟีเจอร์ (เทสต์ใช้ store จำลอง/ในหน่วยความจำ) · `npm run db:migrate` ไม่ได้รันใหม่ ไม่มี migration ใหม่ในแผนนี้
3. Login ด้วยบัญชีระบบกลางจริง (รวมการบันทึกผู้ใช้ลง DB) และมือถือจริงบน Wi-Fi โรงงาน

**ข้อสังเกตจากการทดสอบ**
- ฟอร์มใน `<Suspense>` ของ `/change-password` (และหน้าอื่นที่ใช้โครงเดียวกัน) ยังไม่ hydrate จนกว่าจะมีการโต้ตอบ (คลิก/โฟกัส) ในเบราว์เซอร์ทดสอบที่ถูกซ่อนอยู่ — เป็นลำดับความสำคัญต่ำของ React ต่อ Suspense boundary ที่ยังไม่ hydrate และเป็นโครงหน้าเดิม ไม่ได้มาจากการย้าย API · ผู้ใช้จริงต้องแตะช่องก่อนพิมพ์อยู่แล้วจึงไม่น่ากระทบ แต่ถ้ารู้สึกว่าฟอร์ม PIN ตอบสนองช้าบนเครื่องจริงให้แจ้ง
- ข้อความ error ของช่อง Model ตอนเปิดแผนอ่านว่า "กรุณากรอกModel" (ไม่มีเว้นวรรค) — มาจาก `fieldErrorMessage` เดิม ไม่ได้แก้ในแผนนี้
- ช่อง `code` (รหัสพนักงานเป้าหมายของ audit ตอนแก้ผู้ใช้) ยังรับจากฟอร์มเหมือนเดิม — เปลี่ยนให้ดึงจาก DB ได้ถ้าต้องการ (ต้องแก้ `updateLocalUser` ให้คืนรหัสด้วย)

**ตอนขึ้น production ต้องจำ**
- ด่าน same-origin เทียบ `Origin` กับ `Host`/`X-Forwarded-Host` — reverse proxy ต้องส่ง header ให้ตรงกับ host ที่เบราว์เซอร์ใช้ ไม่งั้นทุกการเขียนจะได้ `403` · เพดานขนาด body ดูจาก `Content-Length` (login 16 KB, อื่น ๆ 1 MB) proxy ยังต้องจำกัด chunked upload เอง
- เพิ่ม endpoint ใหม่ตามสูตร §5 และเพิ่มแถวใน §3 ทุกครั้ง · ย้อนกลับ/เทียบ: `.local-backups/before-api-routes-2026-10-26/originals.tar.gz` (ก่อนย้าย API) และ `.local-backups/before-log-book-structure-2026-10-26/originals.tar.gz` (ก่อนย้ายโครงสร้าง)

**กติกาถาวรหลังจบแผน (26 ต.ค. 2026):** ผู้ใช้สั่งให้ทำตามสไตล์ log-book ตลอดไป — รวมกติกาไว้ใน [`CLAUDE.md`](../CLAUDE.md) ที่ root: หน้า/ฟีเจอร์ใหม่อ่านข้อมูลผ่าน `GET /api/<ฟีเจอร์>` (หน้าเดิมที่อ่านผ่าน `lib/` ผู้ใช้สั่งให้ย้ายทีละหน้า — ดู §9) และเทสต์ทั้งหมดย้ายไป `tests/` แล้ว (`tests/api-*.test.ts` ฯลฯ)

## 9. ย้ายหน้าเดิมไปอ่านผ่าน `GET /api` (ทีละหน้า)

> 26 ต.ค. 2026 · ผู้ใช้สั่งให้หน้าเดิมที่อ่านผ่าน `lib/` ใน server component ไปอ่านผ่าน `GET /api/<ฟีเจอร์>` แบบ log-book **ทีละหน้า และกด confirm ก่อนทุกหน้า** — เสนอหน้า (ไฟล์ · endpoint · ความเสี่ยง) → รอ OK → ทำหน้าเดียว → ตรวจ → หยุด · ก่อนแต่ละหน้าสำรองไฟล์ที่จะแก้ไว้ที่ `.local-backups/before-<หน้า>-via-api-<วันที่>/originals.tar.gz` · หน้าที่ยังไม่ถึงคิวใช้งานได้ตามเดิมตลอด

| # | หน้า | endpoint ที่เพิ่ม | ตรวจในเบราว์เซอร์ | สถานะ |
|---|---|---|---|---|
| 1 | `/jobs` | `GET /api/jobs` | โหมดสาธิต | ✅ 26 ต.ค. 2026 |
| 2 | `/history` | `GET /api/history` (ตัวกรอง + แบ่งหน้า) | โหมดสาธิต | ✅ 26 ต.ค. 2026 |
| 3 | `/master` | `GET /api/master` (จำนวนรายการของแต่ละตาราง) | เฉพาะกรณีไม่มี DB — เลขจริงต้องใช้ SQL Server | ✅ 26 ต.ค. 2026 |
| 4 | `/plans` | `GET /api/plans` (ตัวกรองหลายตัว) | โหมดสาธิต | รอ |
| 5 | `/home` | `GET /api/home` (ชื่อยืนยันตอนทำ) | โหมดสาธิต | รอ |
| 6 | `/admin/users` | `GET /api/admin/users` | โหมดสาธิต | รอ — มีฟอร์ม ต้องมีกลไกโหลดข้อมูลใหม่หลังบันทึกก่อน |
| 7 | `/master/[table]` | `GET /api/master/[table]` | ไม่ได้ — ต้องใช้ SQL Server | รอ — มีฟอร์ม |
| 8 | `/plans/new` | `GET /api/plans/options` | โหมดสาธิต | รอ — ฟอร์ม |
| 9 | `/plans/[id]/work-orders/new` | `GET /api/plans/[id]/work-orders` | โหมดสาธิต | รอ — ฟอร์ม |
| 10 | `/plans/[id]` | `GET /api/plans/[id]` | โหมดสาธิต | รอ — ใหญ่สุด (3 แท็บ + ฟอร์มหลายชุด) อาจแบ่งหลายรอบ |

เรียงจากหน้าที่อ่านอย่างเดียวไปหน้าที่มีฟอร์ม: ฟอร์มใช้ `router.refresh()` หลังบันทึก ซึ่งไม่ทำให้ข้อมูลที่โหลดฝั่ง client อัปเดตเอง จึงต้องเพิ่มกลไก "โหลดข้อมูลใหม่หลังบันทึก" ก่อนหน้า 6 (เป็นขั้นที่ขอ OK แยก)

**สูตรต่อหน้า** (ตัวอย่างครบชุด = `/jobs`)
1. `lib/<โมดูล>/<เรื่อง>.ts` — `loadXxx(user, query)` + ชนิดคำตอบ ส่งเฉพาะฟิลด์ที่หน้าวาด · มี `import "server-only"` ฝั่ง client จึงใช้ `import type` ได้อย่างเดียว
2. `app/api/<ฟีเจอร์>/route.ts` — `GET` = `guardApi(request, { page, returnTo })` → `loadXxx` → `apiData(...)` · DB error → `dbFailure`
3. `components/<ฟีเจอร์>/` — `useXxxData.ts` (ห่อ `useApiRead`) + `XxxView.tsx`: โครงกำลังโหลด · ข้อความ error + ปุ่ม "ลองอีกครั้ง" · หรี่รายการระหว่างโหลดใหม่ · ย้าย UI เดิมของหน้ามาไว้ที่นี่
4. `page.tsx` — `requirePageAccess` แล้วส่ง prop ที่คำนวณจาก role และ `searchParams` (อ่านที่ server ตามที่ Next docs แนะนำสำหรับ page ที่เป็น Server Component — client ไม่ต้องใช้ `useSearchParams`)
5. เทสต์ `tests/api-<ฟีเจอร์>.test.ts` (401 · 403 · 503 · สำเร็จ · header no-store) + `tests/<โมดูล>-<เรื่อง>.test.ts` (service) → lint · typecheck · test · build → ลองในเบราว์เซอร์โหมดสาธิต (สำเนาโปรเจกต์ที่ไม่มี `.env.local` ตาม §8)

**หน้า 1 — `/jobs` (✅ 26 ต.ค. 2026)**
- ไฟล์ใหม่: `lib/api/read.ts` · `app/api/jobs/route.ts` · `lib/plans/jobs.ts` · `components/jobs/{JobsView.tsx,useJobsData.ts}` · `tests/{lib-api-read,plans-jobs,api-jobs}.test.ts` — แก้: `lib/api/{client,response,call}.ts` (`useApiRead` · `apiData` · export `isSitePath`) · `app/(app)/jobs/page.tsx` (เหลือด่านสิทธิ์ + ส่ง `isHead`/`view`/`notification`) · ย้าย `PlanBits.tsx` ไป `components/plans/` (แก้ import ของ `home` `history` `plans` `plans/[id]`) · สำรอง: `.local-backups/before-jobs-via-api-2026-10-26/originals.tar.gz`
- ส่งเฉพาะฟิลด์ที่หน้าวาด: ไม่มี `remarks` `planNo` `createdAt` `seq` และรหัสพนักงานของผู้ตรวจ
- `?view=mine` ของหัวหน้า QC: server ตัดสินซ้ำเอง — ผู้ตรวจขอ `view=all` ก็ได้ของตัวเอง · หัวข้อของหน้าตามรายการที่แสดงอยู่ ส่วนปุ่มสลับ ทั้งหมด/ของฉัน ขึ้นตามที่กดทันที
- **ลิงก์จากแจ้งเตือน** `/jobs?view=mine&notification=<id>:<status>#work-order-<id>`: (ก) เปลี่ยนค่า `notification` → โหลดรายการใหม่ (เดิมใช้ query ที่เปลี่ยนเพื่อให้ server component render ใหม่) (ข) พอรายการใหม่ขึ้นก็เลื่อนไปที่การ์ดครั้งเดียวต่อแจ้งเตือน เพราะเบราว์เซอร์เลื่อนตาม `#hash` เองไม่ได้เมื่อการ์ดยังไม่อยู่ในหน้า (ค) ไฮไลต์ขอบการ์ดด้วย prop แทน `:target` (CSS `:target` ใช้ไม่ได้เมื่อการ์ดโผล่ทีหลัง) (ง) ถ้าใบงานนั้นจบไปแล้ว กล่อง "ส่งแล้ว / ปิดแล้ว" เปิดให้
- **สิ่งที่ผู้ใช้จะเห็นต่างจากเดิม:** เปิดหน้าแล้วเห็นโครงกำลังโหลดก่อนข้อมูลตามมา (เดิมข้อมูลมาพร้อมหน้า) · กดสลับมุมมองแล้วรายการเดิมหรี่ลงจนรายการใหม่มา · เครือข่ายหลุด/DB ล่มได้แถบแจ้งพร้อมปุ่ม "ลองอีกครั้ง" · เซสชันหมดอายุระหว่างอยู่หน้านี้พาไป login อัตโนมัติ
- **เทสต์:** 858 → **905** (+47: `lib-api-read` 18 · `plans-jobs` 13 · `api-jobs` 16) · ลองแก้โค้ดให้ผิด 11 จุด (ใครก็ขอดูทั้งหมดได้, ผู้ตรวจเห็นงานของคนอื่น, ฟิลด์รั่ว, รายการซ้ำ, ไม่เช็กสิทธิ์, DB ล่มไม่ถูกตอบ, redirect ออกนอกเว็บ, ข้อมูลเดิมหายเมื่อโหลดใหม่ล้มเหลว ฯลฯ) เทสต์จับได้ทุกจุด · lint · `tsc` · `next build` ผ่าน (`/api/jobs` เป็น `ƒ` ส่วน `/jobs` ยังเป็น `◐`)
- **ตรวจในเบราว์เซอร์แล้ว (26 ต.ค. 2026)** ด้วยสำเนาโหมดสาธิตตาม §8 — เพิ่มผู้ใช้หัวหน้า QC ในสำเนาเท่านั้น (บัญชีสาธิตเดิมไม่มี QC Head) และเปิดสองเซสชันพร้อมกันผ่าน `localhost` กับ `127.0.0.1`: `GET /api/jobs` ตอบ 200 `private, no-store` มีเฉพาะฟิลด์ที่กำหนด ไม่มี `remarks`/`createdAt`/`planNo`/รหัสพนักงานรั่ว · หัวหน้า QC สลับ ทั้งหมด → ของฉัน (ปุ่มเปลี่ยนทันที รายการเดิมหรี่และ `aria-busy` ระหว่างโหลด แล้วหัวข้อกับรายการเปลี่ยนพร้อมกัน) · ผู้ตรวจขอ `?view=all` ได้เฉพาะของตัวเอง ไม่มีปุ่มสลับ และการ์ดมี "ร่วมกับ: …" · กดลิงก์จาก `/alerts` ในหน้าจอ 760×420 → เลื่อนไปการ์ดท้ายรายการและไฮไลต์เฉพาะการ์ดนั้น · มีใบงานใหม่ระหว่างอยู่หน้านี้ → toast "ดูงาน" → กดแล้วรายการโหลดใหม่ 5 → 6 ใบ การ์ดใหม่ขึ้นบนสุด ไฮไลต์ และเลื่อนขึ้นมาหา · จำลองให้ API ตอบ 503 / เครือข่ายล้ม → แถบแจ้งข้อความเดิม + ปุ่ม "ลองอีกครั้ง" (รายการเดิมยังอยู่ใต้แถบ) กดแล้วโหลดสำเร็จและแถบหาย · จำลอง 401 → พาไป `/login?next=%2Fjobs` · ไม่มี error ในคอนโซลที่เกี่ยวกับหน้านี้ (เหลือแค่ WebSocket HMR ของ dev) และไม่มี error ฝั่งเซิร์ฟเวอร์
- **ตรวจเพิ่มตอนทำหน้า 2** (กล่อง "ส่งแล้ว / ปิดแล้ว" ต้องมีใบงานที่ส่งแล้ว ซึ่งต้องรอโมดูลตรวจ จึงตั้งสถานะผ่าน route ชั่วคราวที่มีเฉพาะในสำเนา): กล่องปิดอยู่และนับถูก (8) · ลิงก์แจ้งเตือนไปใบงานที่ส่งแล้วเปิดกล่องให้และไฮไลต์การ์ด
- **ยังไม่ได้ตรวจกับของจริง:** SQL Server จริง (`resolveActorId` และคำสั่งดึงใบงานผ่านเทสต์ store จำลองเท่านั้น) · มือถือจริง

**หน้า 2 — `/history` (✅ 26 ต.ค. 2026)**
- ไฟล์ใหม่: `app/api/history/route.ts` · `lib/plans/history.ts` · `lib/api/query.ts` · `components/history/{HistoryView.tsx,useHistoryData.ts}` · `components/feedback/{LoadError,CardsSkeleton}.tsx` (แยกออกจาก `JobsView` ให้หน้าอื่นใช้ร่วม) · `tests/{lib-api-query,plans-history-load,api-history}.test.ts` — แก้: `lib/plans/history-query.ts` (เพิ่ม `historyQuery` ที่ `historyHref` ใช้ต่อ + export ชนิด `HistoryQuery`) · `app/(app)/history/page.tsx` (เหลือด่านสิทธิ์ + parse แอดเดรส + ส่ง `values`/`isHead`) · `components/jobs/JobsView.tsx` (ใช้ส่วนที่แยกแล้ว) · `tests/plans-history.test.ts` (+1) · สำรอง: `.local-backups/before-history-via-api-2026-10-26/originals.tar.gz`
- ตัวกรอง (สถานะ · ช่วงเวลา · มุมมอง) และปุ่ม ก่อนหน้า/ถัดไป ยังเป็น `<Link>` เหมือนเดิม — กดแล้วแอดเดรสเปลี่ยน, page parse ใหม่แล้วส่ง `values` ใหม่ให้ `HistoryView`, `useHistoryData` ยิง `GET /api/history` ใหม่ · ปุ่มกลุ่มตัวกรองขึ้นตามที่กดทันที ส่วนรายการ จำนวนรวมและ "หน้า x / y" เป็นของข้อมูลที่แสดงอยู่ (หรี่ระหว่างโหลด) — API ส่ง `page` กลับมาด้วยเพื่อไม่ให้ขึ้นเลขหน้าใหม่คู่กับรายการของหน้าเก่า
- `GET /api/history` อ่านแอดเดรสด้วย `parseHistoryQuery` ตัวเดิม (ค่าแปลกถอยเป็นค่าเริ่มต้น) · QC Head/QA Head เห็นทุกคนเว้นแต่ `view=mine`, คนอื่นได้ของตัวเองเสมอ · "30/90 วัน" คิดจากวันนี้เวลาไทยที่ server ตอนยิง (เหมือนเดิม)
- **เทสต์:** 905 → **938** (+33: `lib-api-query` 4 · `plans-history-load` 12 · `api-history` 16 · `plans-history` +1) · ลองแก้โค้ดให้ผิด 14 จุด (ใครก็เห็นทั้งหมดได้, "ของฉัน" อ่านของทุกคน, ฟิลด์/รหัสพนักงานรั่ว, เลขหน้าผิด, ไม่เช็กสิทธิ์, ไม่อ่านแอดเดรส, DB ล่มไม่ถูกตอบ ฯลฯ) เทสต์จับได้ทุกจุด · lint · `tsc` · `next build` ผ่าน (`/api/history` เป็น `ƒ` ส่วน `/history` ยังเป็น `◐`)
- **ตรวจในเบราว์เซอร์แล้ว (26 ต.ค. 2026)** ด้วยสำเนาโหมดสาธิตตาม §8 — เฉพาะในสำเนา: เพิ่มผู้ใช้หัวหน้า QC, ตั้ง `HISTORY_PAGE_SIZE` = 4 ให้เห็นการแบ่งหน้าโดยไม่ต้องสร้างข้อมูลเป็นร้อย, และมี route ชั่วคราวตั้งสถานะใบงานเป็นส่งแล้ว/ปิดแล้ว (โมดูลตรวจยังไม่มี) · ข้อมูลทดสอบ 12 ใบงานใน 2 แผน (ยกเลิก 3 · ส่งแล้ว 4 · ปิดแล้ว 4 · กำลังทำ 1 ซึ่งไม่ขึ้นประวัติ): หัวหน้า QC เห็น 9 ใบใน 30 วัน แบ่ง 3 หน้า · 90 วัน 10 ใบ · ทั้งหมด 11 ใบ · "ยกเลิก" 3 ใบพร้อมเหตุผล · "ส่งแล้ว" ทุกช่วง 8 ใบ · "ของฉัน" 0 ใบขึ้น "ยังไม่มีประวัติในช่วงนี้" · กดหน้าถัดไป: URL เปลี่ยนทันทีแต่รายการ "หน้า 1 / 3" และจำนวนรวมยังเป็นของหน้าเดิมแบบหรี่ + `aria-busy` จนข้อมูลมา แล้วเปลี่ยนเป็น "หน้า 2 / 3" พร้อมกัน · ผู้ตรวจ: ไม่มีปุ่มมุมมอง การ์ดไม่ใช่ลิงก์ มี "ร่วมกับ: …" · QA Head: เห็นทุกคน มีปุ่มมุมมอง การ์ดลิงก์ไปแผน · จำลอง 503 / เครือข่ายล้ม → แถบแจ้ง + "ลองอีกครั้ง" (รายการเดิมอยู่ใต้แถบ) กดแล้วหาย · ไม่มี error ในคอนโซลและฝั่งเซิร์ฟเวอร์ (เหลือแค่ข้อความเตือนของ dev เรื่อง prefetch `/home` ตอนยังไม่ล็อกอิน ซึ่งมีมาก่อนแล้ว)
- **ยังไม่ได้ตรวจกับของจริง:** SQL Server จริง (`jobHistory` ผ่านเทสต์ store จำลองเท่านั้น) · มือถือจริง

**หน้า 3 — `/master` (✅ 26 ต.ค. 2026)** — เฉพาะหน้าแรกของข้อมูลหลัก (รายการตาราง + จำนวนแถว) · `/master/[table]` ยังเป็นหน้าเดิม (ข้อ 7)
- ไฟล์ใหม่: `app/api/master/route.ts` · `lib/master/counts.ts` (`loadMasterCounts`, ชนิด `MasterCountsPayload`, ข้อความ `MASTER_NO_DATABASE`) · `components/master/{MasterIndex.tsx,useMasterCounts.ts}` · `tests/{master-counts,api-master-counts}.test.ts` — แก้: `app/(app)/master/page.tsx` (เหลือด่านสิทธิ์ + ส่ง `canEdit` กับรายการตารางจาก registry) · สำรอง: `.local-backups/before-master-via-api-2026-10-26/originals.tar.gz`
- การ์ดของทุกตารางขึ้นทันทีจากรายการที่ server ส่งมาเป็น prop (เฉพาะ `slug` `label` `description` — registry ทั้งก้อนไม่ถูกส่งไปเบราว์เซอร์) ส่วนเลข "ใช้งานอยู่/ทั้งหมด" ตามมาทีหลัง (ช่องเลขเป็นแถบหรี่ระหว่างโหลด) · ถ้าอ่านเลขไม่ได้ (ไม่มี DB / DB ล่ม) การ์ดยังอยู่ครบ มีแถบแจ้ง + "ลองอีกครั้ง" · ถ้าเคยได้เลขแล้วโหลดใหม่ล้มเหลว เลขเดิมยังอยู่ใต้แถบ
- `GET /api/master` ใช้สิทธิ์หน้า `master` (Master Admin, QC Head, QA Head, PM, Management อ่านได้ — แก้ได้เฉพาะ Master Admin ซึ่งเป็นสิทธิ์ของ route เขียน) · โหมดสาธิตไม่มี SQL Server → `503` พร้อมข้อความเดิม "ยังไม่ได้ตั้งค่าฐานข้อมูล (DB_SERVER) — ข้อมูลหลักต้องใช้ SQL Server" · ผลนับเป็นออบเจ็กต์ตาม slug (ไม่ใช่ลำดับในอาร์เรย์เหมือนหน้าเดิม) ตารางที่เพิ่มใน registry จึงขึ้นเองโดยไม่ต้องแก้หน้าจอ
- **เทสต์:** 938 → **956** (+18: `master-counts` 4 · `api-master-counts` 14) · ลองแก้โค้ดให้ผิด 8 จุด (แตะ DB ในโหมดสาธิต, เลขผิดตาราง, นับไม่ครบ, ไม่เช็กสิทธิ์, จำกัดให้ Master Admin อย่างเดียว, โหมดสาธิตตอบว่างแทน 503, DB ล่มไม่ถูกตอบ ฯลฯ) เทสต์จับได้ทุกจุด · lint · `tsc` · `next build` ผ่าน (`/api/master` เป็น `ƒ` ส่วน `/master` ยังเป็น `◐`)
- **ตรวจในเบราว์เซอร์แล้ว (26 ต.ค. 2026)** ด้วยสำเนาโหมดสาธิตตาม §8 — เฉพาะในสำเนา: เพิ่มผู้ใช้หัวหน้า QC และ route ชั่วคราวเปิด/ปิด "เลขจำลอง" ของ `loadMasterCounts` (โหมดสาธิตไม่มี SQL Server จึงไม่มีเลขจริงให้เห็น) · ตอนไม่มี DB (สภาพจริงของสำเนา): การ์ดทั้ง 6 ตารางขึ้นพร้อมช่องเลขเป็นแถบหรี่ แล้วเปลี่ยนเป็นแถบแจ้ง "ยังไม่ได้ตั้งค่าฐานข้อมูล (DB_SERVER) — ข้อมูลหลักต้องใช้ SQL Server" + "ลองอีกครั้ง" การ์ดยังอยู่ครบแต่ไม่มีเลข (เซิร์ฟเวอร์ตอบ `503`) · เปิดเลขจำลองแล้วกด "ลองอีกครั้ง": แถบหาย เลข "ใช้งานอยู่/ทั้งหมด" ขึ้นทุกการ์ด (15/20 … 20/25) · HTML ที่ server ส่งมาก่อน JS มีการ์ดครบ ข้อความ "ดูได้อย่างเดียว…" และช่องเลขแบบหรี่ · หัวหน้า QC ได้ข้อความ "ดูได้อย่างเดียว" ส่วน Master Admin ได้ "เพิ่ม แก้ไข และปิดใช้งานได้" · ผู้ตรวจ: `GET /api/master` ตอบ `403` และหน้า `/master` ไม่ส่งการ์ดมาเลย · ไปหน้าตารางแล้วกดย้อนกลับ: เลขเดิมขึ้นทันทีและอ่านใหม่เงียบ ๆ (Next เก็บหน้าเดิมไว้ด้วย `<Activity>` — effect ถูกปิดตอนซ่อนและเปิดใหม่ตอนกลับมา) · ไม่มี error ฝั่งเซิร์ฟเวอร์ และไม่มี error ในคอนโซลนอกจากที่ตั้งใจ (503/403) กับ WebSocket HMR ของ dev
- **ยังไม่ได้ตรวจกับของจริง:** เลขจริงจาก SQL Server (`masterCounts` ในเทสต์ของ route เป็นตัวจำลอง; ตัวมันเองมีเทสต์กับ DB จริงอยู่แล้วใน `tests/master-db.test.ts` ซึ่งรันเมื่อตั้ง `QCHECK_DB_TESTS=on`) · มือถือจริง

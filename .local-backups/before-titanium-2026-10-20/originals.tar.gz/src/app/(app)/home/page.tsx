import type { Metadata } from "next";
import { ShellLink } from "@/components/shell/ShellLink";
import { canOpenPlan, canSeeMaster, primaryRole } from "@/components/shell/nav";
import { Suspense } from "react";
import {
  CheckCircleIcon,
  ChevronRightIcon,
  JobsIcon,
  PlansIcon,
  PlusIcon,
  SearchIcon,
  WarningIcon,
} from "@/components/dom/Icons";
import { authPolicy } from "@/config/auth";
import { roleLabels } from "@/config/experience";
import { requirePageAccess } from "@/lib/auth/dal";
import { MOCK_DEFECT_ALERTS, MOCK_INSPECTION_PLANS } from "@/lib/data/mock-plans";

export const metadata: Metadata = {
  title: "ภาพรวมระบบการตรวจรับคุณภาพ",
};

type HomeSearch = Promise<{ q?: string | string[] }>;

export default function HomePage({ searchParams }: { searchParams: HomeSearch }) {
  return (
    <Suspense fallback={<HomeSkeleton />}>
      <HomeContent searchParams={searchParams} />
    </Suspense>
  );
}

async function HomeContent({ searchParams }: { searchParams: HomeSearch }) {
  const user = await requirePageAccess("home", authPolicy.homePath);
  const params = await searchParams;
  const query = typeof params.q === "string" ? params.q.trim().slice(0, 200) : "";
  const plans = MOCK_INSPECTION_PLANS.filter(plan =>
    [plan.planNo, plan.docNo, plan.modelCode, plan.modelName, plan.brand].some(value => value.toLowerCase().includes(query.toLowerCase())),
  );
  const role = primaryRole(user.roles);
  const roleDisplay = role ? roleLabels[role] : "ผู้ใช้งาน";
  const inspected = MOCK_INSPECTION_PLANS.reduce((sum, plan) => sum + plan.inspectedQty, 0);
  const sample = MOCK_INSPECTION_PLANS.reduce((sum, plan) => sum + plan.sampleQty, 0);
  const passed = MOCK_INSPECTION_PLANS.reduce((sum, plan) => sum + plan.passedQty, 0);
  const progress = sample ? Math.round(inspected / sample * 100) : 0;
  const active = MOCK_INSPECTION_PLANS.filter(plan => plan.status !== "COMPLETED").length;
  const openDefects = MOCK_DEFECT_ALERTS.filter(alert => alert.status !== "RESOLVED");

  return (
    <div className="home-enter p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      <p className="rounded-lg border border-ember-500/25 bg-ember-500/5 px-4 py-3 text-sm text-ti-200">
        ข้อมูลตัวอย่างสำหรับทดลองหน้าจอ ยังไม่ใช่ผลตรวจจริง · เมนูสีจางยังไม่เปิดใช้งาน
      </p>
      {/* 1. Header & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-carbon-700/50">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span
              lang="en"
              className="font-mono text-[11px] font-medium tracking-[0.14em] text-ember-400 uppercase"
            >
              Inspection Management Dashboard
            </span>
            <span className="text-ti-600 text-xs">·</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-carbon-800 border border-carbon-700 text-ti-200 font-mono">
              {roleDisplay}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-light text-ti-50 tracking-tight">
            สวัสดี, <span className="font-medium text-ti-50">{user.fullName}</span>
          </h1>
          <p className="text-xs sm:text-sm text-ti-400 mt-1">
            รหัสพนักงาน: <span className="font-mono text-ti-200">{user.employeeCode}</span> ·
            พร้อมดำเนินงานตรวจสอบคุณภาพสินค้าล็อตประจำวัน
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {canOpenPlan(user.roles) && (
          <ShellLink
            href="/plans/new"
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-ember-500 hover:bg-ember-400 active:bg-ember-600 text-carbon-950 font-medium text-sm transition-all duration-150 shadow-xs shadow-ember-500/20"
          >
            <PlusIcon className="size-4" />
            <span>เปิดแผนตรวจใหม่</span>
          </ShellLink>
          )}
          {canSeeMaster(user.roles) && (
          <ShellLink
            href="/master"
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-lg border border-carbon-600 hover:border-ti-400 bg-carbon-800/80 hover:bg-carbon-700/80 text-ti-200 hover:text-ti-50 text-sm transition-colors"
          >
            <span>ข้อมูลหลัก</span>
          </ShellLink>
          )}
        </div>
      </div>

      {/* 2. KPI Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active Plans */}
        <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/60 p-4.5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs text-ti-400 font-medium">แผนตรวจที่เปิดอยู่</span>
            <div className="size-8 rounded-lg bg-carbon-700 border border-carbon-600 grid place-items-center text-ember-400">
              <PlansIcon className="size-4.5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-3xl font-semibold text-ti-50">{active}</span>
              <span className="text-xs text-ti-400">แผนงาน</span>
            </div>
            <p className="text-[11px] text-ti-400 mt-1">จากแผนตัวอย่างทั้งหมด {MOCK_INSPECTION_PLANS.length} แผน</p>
          </div>
        </div>

        {/* Card 2: Today Inspected */}
        <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/60 p-4.5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs text-ti-400 font-medium">ความคืบหน้าการสุ่มตรวจ</span>
            <div className="size-8 rounded-lg bg-carbon-700 border border-carbon-600 grid place-items-center text-ti-200">
              <JobsIcon className="size-4.5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-3xl font-semibold text-ti-50">{inspected}</span>
              <span className="text-xs text-ti-400">/ {sample} เครื่อง ({progress}%)</span>
            </div>
            <div className="w-full h-1.5 bg-carbon-700 rounded-full mt-2 overflow-hidden">
              <div className="h-full bg-ember-500 rounded-full" style={{ width: `${progress}%` }} />
            </div>
          </div>
        </div>

        {/* Card 3: Pass Rate */}
        <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/60 p-4.5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs text-ti-400 font-medium">อัตราผ่านรอบแรก (Pass Rate)</span>
            <div className="size-8 rounded-lg bg-carbon-700 border border-carbon-600 grid place-items-center text-pass">
              <CheckCircleIcon className="size-4.5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-3xl font-semibold text-pass">{inspected ? (passed / inspected * 100).toFixed(1) : "0.0"}%</span>
            </div>
            <p className="text-[11px] text-ti-400 mt-1">คำนวณจากผลผ่านในข้อมูลตัวอย่าง</p>
          </div>
        </div>

        {/* Card 4: Open Defects / Rework */}
        <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/60 p-4.5 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs text-ti-400 font-medium">ข้อบกพร่อง / รอ Rework</span>
            <div className="size-8 rounded-lg bg-carbon-700 border border-carbon-600 grid place-items-center text-fail">
              <WarningIcon className="size-4.5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-3xl font-semibold text-fail">{openDefects.length}</span>
              <span className="text-xs text-ti-400">เครื่อง</span>
              <span className="text-[10px] font-mono text-fail bg-fail/10 px-1.5 py-0.5 rounded border border-fail/20 ml-auto">
                Action Req.
              </span>
            </div>
            <p className="text-[11px] text-ti-400 mt-1">ส่งแก้ไข {openDefects.filter(alert => alert.status === "REWORK_SENT").length} · รอดำเนินการ {openDefects.filter(alert => alert.status === "OPEN").length}</p>
          </div>
        </div>
      </div>

      {/* 3. Main Content: Plans Table & Defect Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Active Plans Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-medium text-ti-50">แผนการตรวจคุณภาพล่าสุด</h2>
              <p className="text-xs text-ti-400">รายการแผนตรวจที่เปิดจากใบส่งสินค้า (Invoice / PO)</p>
            </div>

            <form action="/home" method="get" role="search" className="flex items-center gap-2">
              <div className="relative">
                <button type="submit" aria-label="ค้นหาแผน" className="absolute left-0 top-0 grid size-9 place-items-center text-ti-400 hover:text-ember-400"><SearchIcon className="size-4" /></button>
                <input
                  type="text"
                  name="q"
                  aria-label="ค้นหาแผน Invoice หรือรุ่นสินค้า"
                  defaultValue={query}
                  maxLength={200}
                  placeholder="ค้นหาแผน, Invoice, รุ่น..."
                  className="h-9 pl-9 pr-3 rounded-lg bg-carbon-800 border border-carbon-600 text-xs text-ti-50 placeholder:text-ti-500 focus:outline-hidden focus:border-ember-500 focus:ring-1 focus:ring-ember-500 w-48 sm:w-56"
                />
              </div>
            </form>
          </div>

          <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/40 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-xs">
                <thead>
                  <tr className="border-b border-carbon-700/80 bg-carbon-900/60 font-mono text-ti-400 text-[11px]">
                    <th className="py-3 px-4 font-medium">แผน / เอกสารอ้างอิง</th>
                    <th className="py-3 px-4 font-medium">รุ่นสินค้า (Model)</th>
                    <th className="py-3 px-4 font-medium text-center">ขนาดล็อต / สุ่ม AQL</th>
                    <th className="py-3 px-4 font-medium">ความคืบหน้า</th>
                    <th className="py-3 px-4 font-medium text-center">สถานะ</th>
                    <th className="py-3 px-4 font-medium text-right">ดำเนินการ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-carbon-700/50">
                  {plans.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-ti-400">ไม่พบแผนที่ตรงกับคำค้น</td></tr>}
                  {plans.map((plan) => {
                    const percent = Math.round((plan.inspectedQty / plan.sampleQty) * 100);
                    return (
                      <tr key={plan.id} className="hover:bg-carbon-800/80 transition-colors">
                        <td className="whitespace-nowrap py-3.5 px-4 font-mono">
                          <div className="font-semibold text-ti-50">{plan.planNo}</div>
                          <div className="text-[11px] text-ti-500 mt-0.5">{plan.docNo}</div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-carbon-700 text-ember-400 border border-carbon-600 font-semibold">
                              {plan.brand}
                            </span>
                            <span className="font-medium text-ti-50">{plan.modelCode}</span>
                          </div>
                          <div className="text-[11px] text-ti-400 truncate max-w-[200px] mt-0.5">
                            {plan.modelName}
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-center font-mono">
                          <div className="text-ti-50 font-medium">Lot {plan.lotQty}</div>
                          <div className="text-[11px] text-ti-400 mt-0.5">สุ่ม {plan.sampleQty} ตัว</div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex items-center justify-between text-[11px] mb-1 font-mono">
                            <span className="text-ti-200">
                              {plan.inspectedQty}/{plan.sampleQty}
                            </span>
                            <span className="text-ti-400">{percent}%</span>
                          </div>
                          <div className="w-28 sm:w-32 h-1.5 bg-carbon-700 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                percent === 100 ? "bg-pass" : "bg-ember-500"
                              }`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          {plan.status === "IN_PROGRESS" && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-ember-500/10 text-ember-400 border border-ember-500/20">
                              กำลังตรวจ
                            </span>
                          )}
                          {plan.status === "QC_COMPLETED" && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-pass/10 text-pass border border-pass/20">
                              QC ผ่านครบ
                            </span>
                          )}
                          {plan.status === "WAITING" && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-carbon-700 text-ti-400 border border-carbon-600">
                              รอเริ่มตรวจ
                            </span>
                          )}
                          {plan.status === "COMPLETED" && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-carbon-700 text-ti-200 border border-carbon-600">
                              เสร็จสิ้น
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <ShellLink
                            href={`/plans/${plan.id}`}
                            className="inline-flex items-center gap-1 text-[11px] text-ti-200 hover:text-ember-400 font-medium transition-colors"
                          >
                            <span>ดูรายละเอียด</span>
                            <ChevronRightIcon className="size-3" />
                          </ShellLink>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-3 border-t border-carbon-700/60 bg-carbon-900/40 text-center">
              <ShellLink
                href="/plans"
                className="text-xs text-ti-400 hover:text-ember-400 transition-colors font-medium"
              >
                แผนตัวอย่างทั้งหมด {MOCK_INSPECTION_PLANS.length} แผน · รายละเอียดจะเปิดใช้ในรอบถัดไป
              </ShellLink>
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Defect Alerts & Quick Tools */}
        <div className="space-y-6">
          {/* Defect Alerts Widget */}
          <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/40 p-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <WarningIcon className="size-4 text-fail" />
                <h3 className="text-sm font-medium text-ti-50">ข้อบกพร่องที่พบล่าสุด</h3>
              </div>
              <span className="font-mono text-[10px] text-fail bg-fail/10 px-2 py-0.5 rounded border border-fail/20">
                Demo
              </span>
            </div>

            <div className="space-y-2.5">
              {MOCK_DEFECT_ALERTS.map((alert) => (
                <div
                  key={alert.id}
                  className="p-3 rounded-lg border border-carbon-700 bg-carbon-800/90 space-y-1.5"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono text-ti-200 font-semibold">{alert.serialNumber}</span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${
                        alert.severity === "CRITICAL"
                          ? "bg-fail/20 text-fail border border-fail/30"
                          : alert.severity === "MAJOR"
                            ? "bg-ember-500/20 text-ember-400 border border-ember-500/30"
                            : "bg-carbon-700 text-ti-200 border border-carbon-600"
                      }`}
                    >
                      {alert.severity}
                    </span>
                  </div>

                  <p className="text-xs text-ti-50 font-medium">{alert.defectName}</p>

                  <div className="flex items-center justify-between text-[10px] text-ti-400 pt-1 border-t border-carbon-700/50">
                    <span>จุดตรวจ: {alert.checkpoint}</span>
                    <span className="font-mono">{alert.reportedAt}</span>
                  </div>
                </div>
              ))}
            </div>

            <ShellLink
              href="/defects"
              className="block text-center text-xs text-ti-400 hover:text-ember-400 transition-colors pt-1"
            >
              ดูสถิติและข้อบกพร่องทั้งหมด →
            </ShellLink>
          </div>

          {/* Quick System Tools */}
          <div className="rounded-xl border border-carbon-700/80 bg-carbon-800/40 p-4 space-y-3">
            <h3 className="text-sm font-medium text-ti-50">แนวทางการตรวจ & มาตรฐาน</h3>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg border border-carbon-700 bg-carbon-900/40 flex items-center justify-between">
                <div>
                  <div className="font-medium text-ti-200">AQL Table Level II</div>
                  <div className="text-[11px] text-ti-400">ระดับการสุ่มตรวจมาตรฐาน (Normal Inspection)</div>
                </div>
                <span className="font-mono text-xs text-ember-400 font-bold">100%</span>
              </div>

              <div className="p-2.5 rounded-lg border border-carbon-700 bg-carbon-900/40 flex items-center justify-between">
                <div>
                  <div className="font-medium text-ti-200">เกณฑ์รับ-ตีกลับ (Accept/Reject)</div>
                  <div className="text-[11px] text-ti-400">Critical: 0 / Major: Ac 1, Re 2</div>
                </div>
                <span className="font-mono text-xs text-pass font-bold">MIL-STD</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HomeSkeleton() {
  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      <div className="space-y-2">
        <div className="h-4 w-32 rounded bg-carbon-800 animate-pulse" />
        <div className="h-8 w-64 rounded-md bg-carbon-800 animate-pulse" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-28 rounded-xl border border-carbon-700/80 bg-carbon-800/60 p-4 animate-pulse" />
        ))}
      </div>
    </div>
  );
}

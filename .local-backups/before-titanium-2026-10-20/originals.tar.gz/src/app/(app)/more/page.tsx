import { Suspense } from "react";
import { SignOutButton } from "@/components/dom/SignOutButton";
import { roleLabels, loginCopy } from "@/config/experience";
import Link from "next/link";
import { requirePageAccess } from "@/lib/auth/dal";
import { canAccessPage } from "@/lib/auth/page-access";

export const metadata = { title: "เพิ่มเติม" };

export default function MorePage() {
  return <Suspense fallback={<p className="p-6 text-ti-400">กำลังโหลดบัญชี…</p>}><Account /></Suspense>;
}

async function Account() {
  const user = await requirePageAccess("account", "/more");
  return <div className="mx-auto max-w-2xl space-y-6 p-4 sm:p-6">
    <h1 className="text-2xl text-ti-50">บัญชีของฉัน</h1>
    <section className="space-y-3 rounded-xl border border-carbon-700 bg-carbon-800 p-5">
      <h2 className="text-lg font-medium">{user.fullName}</h2>
      <p className="font-mono text-ti-200">{user.employeeCode}</p>
      <p className="text-sm text-ti-400">บทบาท: {user.roles.map(role => roleLabels[role] ?? role).join(" · ")}</p>
      <SignOutButton />
    </section>
    {/* Places that have no tab on mobile (docs/09 §2): shown only to roles that may open them. */}
    {(canAccessPage(user.roles, "master") || canAccessPage(user.roles, "users")) && (
      <nav aria-label="เมนูอื่น" className="space-y-2">
        <h2 className="text-sm font-medium text-ti-400">เมนูอื่น</h2>
        <ul className="divide-y divide-carbon-700 rounded-xl border border-carbon-700 bg-carbon-800">
          {canAccessPage(user.roles, "master") && <li><Link href="/master" className="flex h-12 items-center px-5 text-ti-100 hover:text-ti-50">ข้อมูลหลัก</Link></li>}
          {canAccessPage(user.roles, "users") && <li><Link href="/admin/users" className="flex h-12 items-center px-5 text-ti-100 hover:text-ti-50">ผู้ใช้หน้างาน</Link></li>}
        </ul>
      </nav>
    )}
    <p lang="en" className="font-mono text-xs text-ti-500">{loginCopy.footer}</p>
  </div>;
}

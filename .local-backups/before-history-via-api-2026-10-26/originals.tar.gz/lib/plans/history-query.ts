import { thaiToday } from "./rules";
import type { JobHistoryFilter } from "./store";

export const HISTORY_PAGE_SIZE = 50;
export const HISTORY_RANGES = { "30": "30 วันล่าสุด", "90": "90 วันล่าสุด", all: "ทั้งหมด" } as const;
export const HISTORY_KINDS = { all: "ทั้งหมด", done: "ส่งแล้ว", cancelled: "ยกเลิก" } as const;

type Query = Record<string, string | string[] | undefined>;
const one = (value: string | string[] | undefined) => (Array.isArray(value) ? value[0] : value) ?? "";

export type HistoryValues = { kind: keyof typeof HISTORY_KINDS; range: keyof typeof HISTORY_RANGES; mine: boolean; page: number };

/** URL → filter for /history (docs/18). Unknown values fall back to the defaults instead of failing. */
export function parseHistoryQuery(query: Query, today: string): { values: HistoryValues; filter: Omit<JobHistoryFilter, "userId"> } {
  const kind = one(query.kind);
  const range = one(query.range);
  const values: HistoryValues = {
    kind: Object.hasOwn(HISTORY_KINDS, kind) ? (kind as HistoryValues["kind"]) : "all",
    range: Object.hasOwn(HISTORY_RANGES, range) ? (range as HistoryValues["range"]) : "30",
    mine: one(query.view) === "mine",
    page: Math.min(10_000, Math.max(1, Number.parseInt(one(query.page), 10) || 1)),
  };
  return { values, filter: { kind: values.kind, fromDate: values.range === "all" ? null : daysBefore(today, Number(values.range)), page: values.page, pageSize: HISTORY_PAGE_SIZE } };
}

function daysBefore(isoDate: string, days: number): string {
  return new Date(Date.parse(`${isoDate}T00:00:00Z`) - days * 86_400_000).toISOString().slice(0, 10);
}

/** Link to /history with some values changed; defaults are left out. */
export function historyHref(values: HistoryValues, changes: Partial<HistoryValues> = {}): string {
  const merged = { ...values, ...changes };
  const params = new URLSearchParams();
  if (merged.kind !== "all") params.set("kind", merged.kind);
  if (merged.range !== "30") params.set("range", merged.range);
  if (merged.mine) params.set("view", "mine");
  if (merged.page > 1) params.set("page", String(merged.page));
  const text = params.toString();
  return text ? `/history?${text}` : "/history";
}

export const historyToday = () => thaiToday(new Date());

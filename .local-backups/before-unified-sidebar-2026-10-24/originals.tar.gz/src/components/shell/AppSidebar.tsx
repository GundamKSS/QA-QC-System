"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { SignOutButton } from "@/components/dom/SignOutButton";
import { QMark } from "@/components/dom/Wordmark";
import { roleLabels } from "@/config/experience";
import type { SessionUser } from "@/lib/auth/types";
import { isActive, primaryRole, sidebarSections } from "./nav";
import { NavIcon } from "./NavIcon";
import { ShellLink } from "./ShellLink";
import { NotificationBadge } from "@/components/notifications/NotificationBadge";

/**
 * Icon rail on ≥ 768 px — same destinations as the bottom tabs (docs/09 §5). It floats over the page on
 * frosted glass like the top bar, so the content area runs the full width underneath. Hovering (or
 * focusing) an icon grows it into a frosted card: a large icon, the page name and one line about it.
 */
export function AppSidebar({ user }: { user: SessionUser }) {
  const pathname = usePathname();
  const role = primaryRole(user.roles);
  const initials = user.fullName.trim().slice(0, 1) || user.employeeCode.slice(0, 1);

  return (
    <aside aria-label="เมนูหลัก" className="app-rail hidden md:flex select-none">
      <Link href="/home" aria-label="QCheck หน้าหลัก" className="app-rail-brand">
        <QMark className="h-6 w-auto" />
      </Link>

      <div className="app-rail-sections">
        {sidebarSections(user.roles).map((section) => (
          <nav key={section.title} aria-label={section.title}>
            <ul>
              {section.items.map((item) => {
                const active = isActive(pathname, item);
                return (
                  <li key={item.href}>
                    <ShellLink href={item.href} aria-current={active ? "page" : undefined} className="app-rail-link">
                      <span className="app-rail-icon">
                        <NavIcon name={item.icon} className="size-5" />
                        {item.href === "/alerts" && <NotificationBadge className="app-rail-badge" />}
                      </span>
                      <span className="app-rail-label">
                        <span className="app-rail-label-icon"><NavIcon name={item.icon} className="size-6" /></span>
                        <span className="min-w-0">
                          <span className="app-rail-label-title">{item.label}</span>
                          {item.hint && <span className="app-rail-label-hint">{item.hint}</span>}
                        </span>
                      </span>
                    </ShellLink>
                  </li>
                );
              })}
            </ul>
          </nav>
        ))}
      </div>

      <div className="app-rail-account">
        <button type="button" aria-label={`บัญชี ${user.fullName}`} className="app-rail-avatar">{initials}</button>
        <div className="app-rail-card">
          <p className="text-sm font-medium text-ti-50 truncate">{user.fullName}</p>
          <p className="mt-0.5 text-xs text-ti-400 truncate">
            <span className="font-mono tracking-wider">{user.employeeCode}</span>
            {role && <> · {roleLabels[role]}</>}
          </p>
          <SignOutButton className="mt-3 w-full !h-9 text-xs" />
        </div>
      </div>
    </aside>
  );
}

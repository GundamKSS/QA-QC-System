# QCheck

ระบบตรวจรับคุณภาพปั๊มลม ธีรวัฒน์ (TRW) × PUMA — เว็บแอป mobile-first (Next.js 16 App Router)
เอกสาร scope/spec อยู่ที่ [docs/](docs/README.md) · Art direction หน้า Login อยู่ที่ [docs/07-login-art-direction.md](docs/07-login-art-direction.md)

## เริ่มใช้งาน

ต้องใช้ Node.js ≥ 22.12

```bash
npm install
cp .env.example .env.local   # แล้วใส่ SESSION_SECRET (คำสั่งสร้างอยู่ในไฟล์)
npm run dev                  # http://localhost:3000
```

| คำสั่ง | ใช้ทำอะไร |
|---|---|
| `npm run dev` | dev server (Turbopack) |
| `npm run build` / `npm start` | production build / รัน build |
| `npm test` | unit test (Vitest) — auth, PIN/ผู้ใช้หน้างาน, CSRF, audit, ตรวจไฟล์ migration (คอลัมน์ วันที่เพิ่ม/แก้ไข/สถานะ), สี CSS ↔ TS, geometry, scan timeline และ shader integration |
| `npm run typecheck` · `npm run lint` | TypeScript · ESLint |
| `npm run db:migrate` | สร้างฐานข้อมูล (ถ้ายังไม่มี) แล้วรันไฟล์ `db/NNN_*.sql` ที่ยังไม่เคยรัน — ดูหัวข้อ “ฐานข้อมูล” |

## โหมด Login

- `QCHECK_AUTH=central` (ค่าตั้งต้น): เรียก API กลางฝั่ง server ผ่าน `API_DATACENTER` (รองรับชื่อเดิม `API_Datacenter`) ตรวจสิทธิ์ `PROGRAM_CODE=PRG003` และอ่านบทบาทจาก `role_prog`
- `QCHECK_AUTH=mock`: ใช้บัญชี demo ด้านล่างโดยไม่เรียกระบบกลาง · ไม่มีการสลับเป็น demo อัตโนมัติเมื่อ API ล่ม
- `CENTRAL_AUTH_TIMEOUT_MS=5000`: API ผิดรูปแบบ/ล่ม/timeout แสดงสถานะระบบไม่พร้อม และไม่นับเป็นรหัสผิด
- บทบาทกลาง `dev` ต้องเปิด `QCHECK_ALLOW_DEV_ROLE=on` เอง และใช้ได้เฉพาะนอก production; บทบาท QCheck ปกติไม่ต้องใช้สวิตช์นี้
- สิทธิ์หน้า/เมนูใช้กติกาเดียวใน `src/lib/auth/page-access.ts`; หน้าใหม่ต้องเรียก `requirePageAccess` ใน server data loader และตรวจสิทธิ์รายข้อมูล/การกระทำเพิ่มเติม · ตารางสิทธิ์ใน [docs/09-app-shell.md](docs/09-app-shell.md#8-กติกาสิทธิ์หน้าจอที่ใช้ร่วมกัน)
- ตัวอย่างตัวแปรทั้งหมดอยู่ใน [.env.example](.env.example); การเปลี่ยนค่า env ต้อง restart server · รายละเอียดใน [docs/08-central-auth-plan.md](docs/08-central-auth-plan.md)

## ฐานข้อมูล (SQL Server)

- ตั้งค่าใน `.env.local`: `DB_SERVER`, `DB_PORT`, `DB_NAME` (ค่าตั้งต้น `QCheck`), `DB_USER`, `DB_PASSWORD`, `DB_ENCRYPT`, `DB_TRUST_CERT` — เว้น `DB_SERVER` ว่างเพื่อรันแบบไม่มี DB (ข้อมูลผู้ใช้หน้างานอยู่ในหน่วยความจำและหายเมื่อรีสตาร์ท)
- `npm run db:migrate` สร้างฐานข้อมูลถ้ายังไม่มี แล้วรัน `db/*.sql` ตามเลขลำดับ แต่ละไฟล์เป็น transaction เดียวและบันทึกใน `dbo.schema_migrations` พร้อม checksum — **ห้ามแก้ไฟล์ที่รันไปแล้ว** ให้เพิ่มไฟล์ใหม่ · ไฟล์เขียนให้รันซ้ำได้
- ไฟล์ปัจจุบัน: `008_users_schema_repair` เติมคอลัมน์ผู้ใช้ที่ขาดใน schema รุ่นเดิม; `001` users/user_roles · `002_audit_logs` · `002_brands` · `003` ผู้ใช้หน้างาน (LOCAL) + PIN · `004` pump_types/vendors/models · `005` checklist templates/versions/items/header_fields · `006` defects/dispositions/fix_methods · `007` AQL/ค่าแรง/settings — ตรวจเชื่อม SQL Server จริงจากเครื่องพัฒนาได้แล้วหลังตั้ง `DB_ENCRYPT=on` และ `DB_TRUST_CERT=on` ใน `.env.local` (เหมือน DATACENTER เดิมที่ใช้ `TrustServerCertificate=yes`); พบตารางแอป 20 ตาราง แต่ยังไม่มี `schema_migrations` จึงยังไม่ยืนยันประวัติการรันผ่าน runner รอบแก้ TLS รันเฉพาะ `008_users_schema_repair.sql` แบบ transaction เพื่อเติม `nickname`/`pin_must_change`/`updated_by` และ FK ที่ขาด; ทดสอบรันซ้ำแล้วจำนวนแถวเดิมไม่เปลี่ยน และ Chrome อ่านหน้าผู้ใช้หน้างานจาก SQL จริงได้ (LOCAL 0 คน) · Production ใช้ใบรับรองที่เครื่องเชื่อถือได้และตรวจใบรับรองตามปกติ
- ทุกตาราง Master ต้องมี สถานะ + วันที่เพิ่ม + วันที่แก้ไข (+ ผู้ทำ) และ **แอปต้องตั้ง `updated_at`/`updated_by` เองทุกครั้งที่แก้** (ไม่ใช้ trigger — ดู [docs/03 §3.0](docs/03-spec-business-rules-data.md)); test `src/lib/db/master-columns.test.ts` ตรวจให้อัตโนมัติ
- ข้อควรระวังตอนพัฒนา: `mssql`/`tedious` ถูกตั้งเป็น `serverExternalPackages` ใน `next.config.ts` (โหลดเป็น Node ปกติ ไม่ bundle) เพราะเคยเกิด `type.validate is not a function` กับพารามิเตอร์ DateTime2 · เวลาใน `audit_logs.at` จึงให้ฐานข้อมูลตั้งเอง · อย่าเก็บอ็อบเจกต์ store ที่เป็น closure ไว้ใน `globalThis` (ค้างโค้ดเก่าหลัง hot reload) — เก็บเฉพาะ pool/ข้อมูล · `created_by`/`updated_by` ต้องเป็น `users.id` (ผู้ใช้ออฟฟิศมี session id เป็นรหัสพนักงาน → store ค้น id จาก `employee_code` ให้)
- ข้อมูลตั้งต้นที่มีข้อมูลส่วนบุคคลอยู่ใน `db/seed/` (อยู่ใน `.gitignore`) — เช่น `field-users.sql` รันมือหลัง migration 001 + 003
- Login ของพนักงานออฟฟิศบันทึกผู้ใช้/บทบาทลง `users`/`user_roles` ถ้า DB ใช้ได้; **ถ้า DB ล้ม login ยังเข้าได้** (แค่ไม่บันทึก) · `audit_logs` เป็น append-only (trigger ปฏิเสธ UPDATE/DELETE) — ควรให้บัญชีที่แอปใช้เป็น `db_datawriter` + `db_datareader` ไม่ใช่ `db_owner`

## ข้อมูลหลัก (Master data)

- หน้า **`/master`** (เมนู “ข้อมูลหลัก”): ยี่ห้อ, ประเภทปั๊ม, Vendor, รุ่นปั๊ม, Defect, วิธีแก้ไข — รายการพร้อม สถานะ / วันที่เพิ่ม / วันที่แก้ไข (+ ผู้ทำ), ค้นหา, กรองสถานะ, แบ่งหน้า 50 แถว
- Master Admin เพิ่ม/แก้ไข/ปิด-เปิดใช้งาน (ไม่มีลบ) · QC/QA Head, PM, ผู้บริหารดูอย่างเดียว · ทุกการแก้บันทึก audit ค่าก่อน→หลัง
- เพิ่มตาราง Master ใหม่: เขียน migration (มีคอลัมน์มาตรฐาน) + เพิ่ม 1 รายการใน `src/lib/master/registry.ts` — `master.test.ts` ตรวจว่าทุกช่องตรงกับ `db/*.sql` (ชื่อคอลัมน์, NOT NULL, ความยาว, ค่า CHECK)
- ทดสอบกับ SQL Server จริงแบบไม่ทิ้งข้อมูล (ทุกเคสอยู่ใน transaction ที่ rollback):

```bash
QCHECK_DB_TESTS=on node --env-file=.env.local node_modules/.bin/vitest run src/lib/master/master.db.test.ts
```

## ผู้ใช้หน้างาน (PIN) — DEC-12

พนักงานหน้างานไม่มีบัญชีระบบกลาง จึงเข้าด้วย **รหัส `F0001…` + PIN 6 หลัก** ที่ QCheck ตรวจเอง (รหัสขึ้นต้น `F` ไม่ถูกส่งไประบบกลาง) รายละเอียด/ความเสี่ยงอยู่ใน [docs/12](docs/12-field-users-pin-plan.md)

- ตั้ง `PIN_PEPPER` ใน `.env.local` (≥ 32 ตัวอักษรสุ่ม; คำสั่งสร้างอยู่ใน `.env.example`) — ไม่ตั้ง = เข้าด้วย PIN ไม่ได้; เปลี่ยนค่านี้แล้ว PIN เดิมทั้งหมดใช้ไม่ได้
- Admin เปิด **`/admin/users`** (เมนู “ผู้ใช้หน้างาน”) เพื่อสร้างผู้ใช้ (ระบบออกรหัส F… + PIN ชั่วคราว **แสดงครั้งเดียว**), แก้ข้อมูล/บทบาท (เลือกได้เฉพาะ QC/QA Inspector), ออก PIN ใหม่, ปิด/เปิดบัญชี · QC Head ปลดล็อก PIN ของ QC Inspector ได้
- ผู้ใช้เข้าด้วย PIN ชั่วคราวครั้งแรก → ถูกพาไป `/change-password` เพื่อตั้ง PIN ของตัวเอง (ห้ามเลขซ้ำ/เรียง)
- PIN ผิด 5 ครั้ง → ล็อกจนกว่า Admin/QC Head ปลดล็อก (ไม่ปลดตามเวลา) + จำกัดต่อ IP · สถานะ/บทบาทของผู้ใช้หน้างานถูกอ่านจาก DB ทุกคำขอ ปิดบัญชีแล้วมีผลทันที
- ยังไม่มี “ลืม PIN” ด้วยตัวเอง (ให้ Admin ออก PIN ใหม่) และยังไม่มีสลับผู้ใช้บนเครื่องส่วนกลาง

## บัญชีทดสอบ (`QCHECK_AUTH=mock`)

ผู้ใช้และรหัสผ่านทดสอบอยู่ใน [src/lib/auth/mock-users.ts](src/lib/auth/mock-users.ts) (ชื่อสมมติทั้งหมด)

| รหัสพนักงาน | ใช้ทดสอบ |
|---|---|
| `TRW1001` | QC Inspector — เข้าสู่ระบบปกติ |
| `TRW2001` | QA Head + Master Admin — หลายบทบาท |
| `PUMA3001` | ผู้ใช้ใหม่ → ถูกพาไปหน้าตั้งรหัสผ่านใหม่ (FR-AUTH-02) |
| `TRW9001` | ผู้ใช้ที่ถูกปิดการใช้งาน (FR-AUTH-06) |
| `ADM0001` | Admin |

- ผิด 5 ครั้งติดกัน → ล็อกรหัสนั้น 15 นาที · ความผิดที่เก่ากว่า 15 นาทีไม่นับ · ยิงคำขอพร้อมกันก็ตรวจรหัสได้ไม่เกิน 5 ครั้ง (สถานะเก็บในหน่วยความจำ — restart dev server = ล้าง)
- Production demo ต้องตั้งทั้ง `QCHECK_AUTH=mock` และ `QCHECK_MOCK_AUTH=on`
- Audit log ของ login/logout และการจัดการผู้ใช้พิมพ์ลง server console เป็นบรรทัด `[audit] {...}` พร้อม IP/User-Agent และบันทึกลงตาราง `audit_logs` เมื่อมี DB — action: `login.success` · `login.failure` · `login.lockout` (ครั้งที่ทำให้ล็อก) · `login.locked` (ลองขณะล็อกอยู่) · `login.throttled` · `login.disabled` · `login.pin_*` · `user.*` · `logout` · รหัสที่ไม่มีในระบบถูกบันทึกเป็น `<unknown:…>` (HMAC) ไม่ใช่ข้อความที่พิมพ์
- ทดสอบบนมือถือผ่าน LAN ตอน `npm run dev`: เพิ่ม IP เครื่องใน `allowedDevOrigins` ของ `next.config.ts` ก่อน (Next 16 บล็อก asset ของ dev server จาก origin อื่น)

## โครงสร้าง

```
src/
├─ app/
│  ├─ layout.tsx              ฟอนต์ IBM Plex Sans Thai + Mono, metadata (noindex), viewport, BfcacheGuard
│  ├─ globals.css             design tokens (Tailwind v4 @theme)
│  ├─ (auth)/                 กลุ่มหน้า auth — ฉาก 3D, scan-reveal และ interaction (Pass 4)
│  │  ├─ login/               page · actions.ts (Server Action) · error.tsx
│  │  └─ change-password/     ตั้ง PIN ใหม่ของผู้ใช้หน้างาน (ผู้ใช้ระบบกลางยังเป็นข้อความรอ — รหัสผ่านอยู่ที่ระบบกลาง)
│  ├─ (app)/                 layout + Home ข้อมูลตัวอย่าง + alerts + more + admin/users + master — ไม่มี WebGL
│  └─ auth/logout/route.ts    ออกจากระบบ (POST → 303 /login)
├─ components/dom/            LoginForm, Wordmark, StaticStage, SignOutButton, BfcacheGuard
├─ components/canvas/         กระบอกสูบ, แสง, CameraRig, ModelInteraction, Checkpoints, ScanRing และ scan shader/timeline
├─ components/shell/          Sidebar, BottomTabBar, TopAppBar และ nav ตามบทบาท
├─ hooks/useBrowserState.ts   hydrated / online / reduced-motion / countdown
├─ hooks/useStageTier.ts      เครื่องนี้ได้ 3D ไหม (WebGL2, Save-Data, RAM) + รอ idle ก่อนโหลดฉาก
├─ lib/auth-stage.ts          สถานะฟอร์ม → ฉาก 3D (เฉพาะ phase ไม่มีค่าที่กรอก)
├─ config/                    auth.ts (นโยบาย) · experience.ts (สี, copy, timing — จูนที่นี่)
├─ lib/auth/                  authenticate · datacenter-adapter · roles · session (A256GCM) · dal · mock-adapter · attempts · audit · pin · local-auth · local-admin · idle
├─ lib/master/                registry (นิยามตาราง) · form (ตรวจข้อมูล) · sql (สร้างคำสั่ง) · repo (รันกับ DB)
└─ lib/db/                    pool/config (mssql) · actor (ผู้ทำ → users.id) · users · local-users (SQL store) · audit-log · migrate helper tests
db/                           migration SQL (001–008) · seed/ (ข้อมูลส่วนบุคคล — .gitignore)
scripts/migrate.mjs           ตัวรัน `npm run db:migrate`
```

## หลักที่ควรรู้ก่อนแก้

- **Next.js 16 ไม่เหมือนเวอร์ชันเก่า** — อ่าน `node_modules/next/dist/docs/` ก่อน (ดู [AGENTS.md](AGENTS.md))
- เปิด `cacheComponents`: โค้ดที่อ่าน cookie ต้องอยู่ใน `<Suspense>` และอ่านผ่าน `src/lib/auth/dal.ts` เท่านั้น
- หน้า `/login` ไม่อ่าน session โดยตั้งใจ (เป็น static และไม่ redirect ซ้อนตอน action ตั้ง cookie)
- Login สำเร็จ / Logout ใช้ full page navigation เพื่อล้าง state ของผู้ใช้คนก่อนที่ Next เก็บไว้ด้วย `<Activity>` (สำคัญกับเครื่องส่วนกลาง)
- ใน route handler ห้ามใช้ `request.url` / `request.nextUrl` สร้าง URL หรือเช็ค origin — Next สร้างจาก address ที่ server bind (`localhost:3000`) ไม่ใช่ host ที่เบราว์เซอร์ใช้ → ใช้ `isSameOriginRequest()` และ `Location` แบบ relative (ดู `auth/logout/route.ts`)
- Cookie session เข้ารหัสเก็บ id/รหัส/ชื่อ/บทบาทจาก Login กลาง โดยไม่เก็บ `access_token` · DAL ตรวจรหัสบทบาทซ้ำ; โปรไฟล์กลางเป็น snapshot จนหมด session 12 ชม. ส่วน mock อ่าน local record ซ้ำ
- สีอยู่ 2 ที่: `globals.css` (CSS) และ `config/experience.ts` (WebGL) — แก้ให้ตรงกันทั้งคู่ (`palette.test.ts` จะ fail ถ้าไม่ตรง) · `src/app/icon.svg` ใส่ค่าสีตรง ๆ ต้องแก้มือ
- ข้อความบนหน้าจอ, ป้ายบทบาท และเวลาของ animation อยู่ใน `config/experience.ts` · path ของหน้า auth อยู่ใน `config/auth.ts`
- Login Pass 2: กระบอกสูบสร้างจากโค้ดทั้งหมด (`compressorGeometry.ts`) · สีไทเทเนียมใน 3D (`stage.titanium.color`) ตั้งใจให้ต่างจาก token `ti-metal` เพราะเป็นค่าสะท้อนของโลหะ · ตำแหน่ง/ขนาดวัตถุต่อ layout อยู่ `stage.framing` · `window.__qcheckStage` (dev เท่านั้น) ใช้ดู draw calls ผ่าน `gl.info`
- Login Pass 3: เลเซอร์เผยผิวจากพิมพ์เขียวเป็นไทเทเนียมตอน intro และสแกนวนทุก 6 วินาที โดยเหนือเลเซอร์เป็นเส้นพิมพ์เขียวโปร่ง ใต้เลเซอร์เป็นโลหะ · intro ครั้งแรกของวัน 1.4 วินาที/ครั้งถัดไป 0.45 วินาที (ตามเวลาโรงงาน) · คลิกหรือกดคีย์เพื่อข้าม intro
- ฉากรับเฉพาะสถานะจากฟอร์มผ่าน `lib/auth-stage.ts`: focus หยุดสแกน, ส่งฟอร์มเร่งสแกน, สำเร็จเปลี่ยนเป็นสีเขียว, ล็อกดับเลเซอร์ · ไม่ส่งค่ารหัสพนักงานหรือรหัสผ่านเข้าฉาก
- Login Pass 4: เมาส์ขยับกล้อง ≤ 2.5°, ลากหมุน ±35° แล้วค่อย ๆ กลับ, hover ครีบ และจุดตรวจ 5 จุด · focus ดันกล้องเข้า 6%; success เปลี่ยนเลเซอร์เป็นตราถูกพร้อมเคลื่อนกล้องและ fade ภายในช่วงรอเดิม 650 ms
- Review Pass 3–4: เส้นพิมพ์เขียวติดกับโมเดล, แสงสแกนจำกัดตามขอบผิว, เปลี่ยนสถานะเลเซอร์ต่อเนื่องใน 180 ms · เครื่องหมายถูกแสดงหน้าวัตถุ และจุดตรวจหันเข้ากล้อง · รายละเอียด/ผลตรวจอยู่ `docs/login-progress.md`
- โฟกัสช่องรหัสพนักงาน: ขยาย/จัดโมเดลเป็นพื้นหลังกลางจอและหรี่ภาพอย่างต่อเนื่อง; Tab ไปช่องรหัสผ่านหรือคลิกออกย่อกลับ · ค่าจูนอยู่ `stage.interaction.usernameBackdrop` · reduced motion ไม่ซูม
- Canvas รับ pointer จาก parent ร่วมกับฟอร์ม โดยกัน panel/control ออกจาก raycast; มือถือแยกท่าลากแนวนอนจากการเลื่อนหน้าแนวตั้ง · reduced motion ปิด parallax/drag/fly-through และแสดงเครื่องหมายถูกทันที
- Environment และ contact shadow bake ครั้งเดียว ไม่สร้างใหม่ตามสถานะฟอร์ม; bake ใหม่เมื่อ WebGL context ฟื้น · reduced motion ขอ frame เองเมื่อเริ่ม/หยุดพิมพ์
- Reduced motion แสดงผิวโลหะเต็มและวงเลเซอร์นิ่ง; ซ่อนแท็บแล้วพัก render · `?stage=static` ทดสอบฉากสำรอง · เปิด dev ผ่าน `http://localhost:3000/login`

## หน้า Home และโครงแอป

- มือถือมี 4 แท็บ; แท็บเล็ต/คอมมี Sidebar โดยใช้เมนูตามบทบาท · เปิดได้แล้ว `/home`, `/alerts`, `/more`
- Home แสดงข้อมูลตัวอย่าง, ค้นหาแผน/Invoice/รุ่นด้วยช่องค้นหาแล้วกด Enter; KPI คำนวณจากชุดข้อมูลเดียวกับตาราง
- เมนูที่ยังไม่สร้างแสดงสีจางและไม่ส่งไป 404; `/more` แสดงบัญชี/บทบาทและออกจากระบบด้วย POST ได้ทั้งมือถือและคอม
- ข้อมูลตรวจจริง, หน้ารายละเอียด/สร้างแผน, scanner และ backend ของโมดูลต่าง ๆ ยังไม่เปิดใช้ · ดู [docs/09-app-shell.md](docs/09-app-shell.md)

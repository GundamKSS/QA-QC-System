"use client";

import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import { Color, DoubleSide, MeshPhysicalMaterial, type Mesh } from "three";
import { buildInspectionGeometry, type DetailFinish } from "./inspectionGeometry";
import { inspectionPart, type InspectionId } from "./inspectionParts";

const finishes: Record<DetailFinish,string> = {blue:"#285db9",steel:"#bdc7d3",dark:"#394653",copper:"#c3884d",red:"#ef713a",ivory:"#e1e7e5",glass:"#99d8ec"};

export function ExplodedPart({ selected, highlighted, still }: { selected: InspectionId; highlighted: string | null; still: boolean }) {
  const definition = inspectionPart(selected);
  const invalidate = useThree((state) => state.invalidate);
  useEffect(() => {invalidate();}, [invalidate, highlighted, selected]);
  const resources = useMemo(() => buildInspectionGeometry(selected).map((piece) => ({...piece,material:new MeshPhysicalMaterial({
    color:finishes[piece.finish], metalness:piece.finish === "glass" ? 0 : 0.55, roughness:0.32,
    transparent:true, opacity:piece.finish === "glass" ? 0.16 : 1, depthWrite:piece.finish !== "glass", side:DoubleSide,
  })})), [selected]);
  const nodes=useRef<(Mesh|null)[]>([]);
  const progress=useRef(0);
  const orange=useMemo(()=>new Color("#ff7628"),[]);
  useEffect(()=>()=>{resources.forEach(({geometry,material})=>{geometry.dispose();material.dispose();});},[resources]);
  useFrame((_,delta)=>{
    progress.current += (1-progress.current)*(still ? 1 : 1-Math.exp(-5*Math.min(delta,0.05)));
    resources.forEach((piece,index)=>{
      const node=nodes.current[index];
      if(node) node.position.set(
        piece.assembled[0] + (piece.exploded[0] - piece.assembled[0]) * progress.current,
        piece.assembled[1] + (piece.exploded[1] - piece.assembled[1]) * progress.current,
        piece.assembled[2] + (piece.exploded[2] - piece.assembled[2]) * progress.current,
      );
      const match=highlighted===piece.id;
      piece.material.emissive.copy(orange).multiplyScalar(match ? 0.45 : 0);
      piece.material.opacity=piece.finish === "glass" ? match ? 0.28 : 0.16 : highlighted && !match ? 0.45 : 1;
    });
  });
  return <group name="inspection-exploded-part" position={[definition.anchor[0],definition.anchor[1],definition.anchor[2]+0.16]} scale={0.75}>
    {resources.map((piece,index)=><mesh key={`${piece.id}-${index}`} name={`detail-${piece.id}`} ref={(node)=>{nodes.current[index]=node;}} geometry={piece.geometry} material={piece.material} />)}
  </group>;
}
